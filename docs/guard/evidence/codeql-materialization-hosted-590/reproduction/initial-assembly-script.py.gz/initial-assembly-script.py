"""Verify fresh artifacts, compare full results, and retain the existing source review."""
from collections import Counter, defaultdict, deque
import gzip
import hashlib
import json
from pathlib import Path
import re
import subprocess
import zipfile

ROOT = Path('/workspace/scratch/c25672eb4c10/hosted-codeql-590')
PRIOR = ROOT.with_name('hosted-codeql-54c0')
MAIN = ROOT.with_name('hosted-main-590')
REPO = ROOT.with_name('hol-guard')
OUT = ROOT / 'evidence-overlay/docs/guard/evidence/codeql-materialization-hosted-590'
RUN = 35330471687
HEAD = '590ce01334a7724f3f1349b2ab252110a5a268f5'
EVENT_SHA = '6981551052e75dfee9f372513177caed76df53a8'
PRIOR_MANIFEST_SHA = '2592f645c9a3c952b7da20c46fd5ae97a42c7898c3871ffd6ac5a3fe5e505fa1'
OUT.mkdir(parents=True, exist_ok=False)

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':')).encode()

def retain(path, raw, *, compress=False):
    dest = OUT / (str(path) + ('.gz' if compress else ''))
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(gzip.compress(raw, mtime=0) if compress else raw)
    assert (gzip.decompress(dest.read_bytes()) if compress else dest.read_bytes()) == raw

def retain_json(path, value, *, compress=False):
    retain(path, json.dumps(value, indent=2).encode() + b'\n', compress=compress)

prior_overlay = PRIOR / 'evidence-overlay/docs/guard/evidence/codeql-materialization-hosted-54c0'
prior_manifest_raw = (prior_overlay / 'manifest.json').read_bytes()
assert sha(prior_manifest_raw) == PRIOR_MANIFEST_SHA
prior_manifest = json.loads(prior_manifest_raw)
for row in prior_manifest['records']:
    raw = (prior_overlay / row['path']).read_bytes()
    assert len(raw) == row['bytes'] and sha(raw) == row['sha256']
    if row['path'].endswith('.gz'):
        decoded = gzip.decompress(raw)
        assert len(decoded) == row['decoded_bytes'] and sha(decoded) == row['decoded_sha256']
retain('prior-review/manifest.json', prior_manifest_raw, compress=True)
prior_assessment_raw = gzip.decompress((prior_overlay / 'source-review.json.gz').read_bytes())
prior_assessments = json.loads(prior_assessment_raw)
assert len(prior_assessments['assessments']) == prior_assessments['findings_reviewed'] == 54
assessments = {(r['profile'], r['language'], r['result_index']): r for r in prior_assessments['assessments']}
retain('prior-review/source-review.json', prior_assessment_raw, compress=True)
for name in ['finding-summary.json.gz', 'actions-source-review.json.gz']:
    retain('prior-review/' + name, (prior_overlay / name).read_bytes())

run = json.loads((ROOT / 'raw/terminal-run.json').read_bytes())
jobs = json.loads((ROOT / 'raw/terminal-jobs.json').read_bytes())
artifacts = json.loads((ROOT / 'raw/terminal-artifacts.json').read_bytes())
inspection = json.loads((ROOT / 'inspection.json').read_bytes())
previous = json.loads((PRIOR / 'inspection.json').read_bytes())
merge = json.loads((ROOT / 'raw/workflow-event-git-commit.json').read_bytes())
assert run['id'] == RUN and run['head_sha'] == HEAD and run['event'] == 'pull_request'
assert run['run_attempt'] == 1 and run['status'] == 'completed' and run['conclusion'] == 'success'
assert run['pull_requests'][0]['number'] == 2954 and run['pull_requests'][0]['head']['sha'] == HEAD
assert merge['sha'] == EVENT_SHA
assert [p['sha'] for p in merge['parents']] == ['4b89e0d2d496a85f04922b2e019a4aea15326bb9', HEAD]
assert jobs['total_count'] == len(jobs['jobs']) == artifacts['total_count'] == len(artifacts['artifacts']) == len(inspection['records']) == 6
assert all(j['head_sha'] == HEAD and j['run_attempt'] == 1 and j['status'] == 'completed' and j['conclusion'] == 'success' for j in jobs['jobs'])
prior_records = {(r['diagnostic']['profile'], r['diagnostic']['language']): r for r in previous['records']}
observations, comparisons, review_reuse = [], [], []

for path in sorted((ROOT / 'raw').glob('*.json')):
    retain('raw/' + path.name, path.read_bytes(), compress=True)
for name in ['final-runs-p1', 'final-jobs-35330471687-p1', 'final-artifacts-35330471687-p1']:
    retain('capture-receipts/' + name + '.json', (MAIN / 'capture-receipts' / (name + '.json')).read_bytes())

for record in inspection['records']:
    artifact = record['artifact']
    diagnostic = record['diagnostic']
    key = (diagnostic['profile'], diagnostic['language'])
    old = prior_records[key]
    prior_diagnostic = old['diagnostic']
    zip_bytes = (ROOT / 'raw' / f'artifact-{artifact["id"]}.zip').read_bytes()
    assert len(zip_bytes) == artifact['size_in_bytes'] and 'sha256:' + sha(zip_bytes) == artifact['digest']
    assert artifact['workflow_run']['id'] == RUN and artifact['workflow_run']['head_sha'] == HEAD
    with zipfile.ZipFile(ROOT / 'raw' / f'artifact-{artifact["id"]}.zip') as archive:
        assert archive.testzip() is None and len(archive.infolist()) == 2
    retain('raw/' + f'artifact-{artifact["id"]}.zip', zip_bytes)
    assert diagnostic['source'] == prior_diagnostic['source']
    assert diagnostic['extraction_layout'] == prior_diagnostic['extraction_layout']
    for field in ['query_selection', 'diagnostic_paths_ignore', 'codeql_action', 'expected_cli_version', 'diff_filter', 'security_result_upload', 'database_upload']:
        assert diagnostic[field] == prior_diagnostic[field]
    assert diagnostic['workflow_commit'] == EVENT_SHA and diagnostic['workflow_run'] == str(RUN)
    assert diagnostic['workflow_attempt'] == '1' and diagnostic['diagnostic_analysis_complete'] and not diagnostic['errors']
    assert diagnostic['source']['tracked_clean'] and diagnostic['source']['matches_pin']
    assert diagnostic['source']['materialization']['verified']
    assert diagnostic['query_selection'] == 'bundle_default_queries'
    assert diagnostic['security_result_upload'] == 'never' and diagnostic['database_upload'] is False and diagnostic['diff_filter'] is False

    name = ('Foundation cdd' if key[0] == 'foundation-cdd' else 'Prepared implementation d8') + ' SARIF (' + key[1] + ')'
    job = next(j for j in jobs['jobs'] if j['name'] == name)
    log_name = 'diagnostic-' + ('cdd' if key[0] == 'foundation-cdd' else 'd8') + '-' + {'actions': 'actions', 'javascript-typescript': 'js', 'python': 'python'}[key[1]] + '-log.log'
    log_raw = (MAIN / 'raw' / log_name).read_bytes()
    log = log_raw.decode()
    receipt = json.loads((MAIN / 'capture-receipts' / (log_name.removesuffix('.log') + '.json')).read_bytes())
    assert sha(log_raw) == receipt['decoded_sha256'] and len(log_raw) == receipt['decoded_bytes']
    assert str(job['id']) in receipt['source']
    retain('raw/' + log_name, log_raw, compress=True)
    retain('capture-receipts/' + log_name + '.json', json.dumps(receipt, indent=2).encode() + b'\n')

    versions = set()
    checkout_commits = []
    lines = log.splitlines()
    for index, line in enumerate(lines):
        if 'CODEQL_ACTION_CLI_VERSION_INFO: ' in line:
            value = json.loads(line.split('CODEQL_ACTION_CLI_VERSION_INFO: ', 1)[1])['version']
            versions.add((value['version'], value['sha']))
        if '[command]/usr/bin/git log -1 --format=%H' in line:
            checkout_commits.append(lines[index + 1].split('Z ', 1)[1].strip())
    assert versions == {('2.27.0', 'b47b3e59262c95aff4eeb84ac72d09e25a9c37e9')}
    assert checkout_commits == [HEAD, diagnostic['source']['commit']]
    init_lines = [line for line in lines if '[command]' in line and 'codeql database init ' in line]
    assert len(init_lines) == 1
    assert '--source-root=/home/runner/work/hol-guard/hol-guard ' in init_lines[0]
    pack = {'actions': ('actions', '0.6.35'), 'javascript-typescript': ('javascript', '2.4.5'), 'python': ('python', '1.8.10')}[key[1]]
    assert set(re.findall(r'qlpacks/codeql/(actions|javascript|python)-queries/(\d+\.\d+\.\d+)', log)) == {pack}

    assert len(record['sarifs']) == len(old['sarifs']) == 1
    member = record['sarifs'][0]['identity']
    payload_bytes = (ROOT / 'members' / str(artifact['id']) / member['path']).read_bytes()
    payload = json.loads(payload_bytes)
    old_payload = json.loads((PRIOR / 'members' / str(old['artifact']['id']) / old['sarifs'][0]['identity']['path']).read_bytes())
    assert sha(payload_bytes) == diagnostic['sarif']['sha256'] and len(payload_bytes) == diagnostic['sarif']['bytes']
    assert payload['version'] == '2.1.0' and len(payload['runs']) == diagnostic['sarif']['runs'] == 1
    assert all(not r.get('externalPropertyFileReferences') for r in payload['runs'])
    assert all(i['executionSuccessful'] for r in payload['runs'] for i in r['invocations'])
    notices = [n for r in payload['runs'] for i in r['invocations'] for field in ['toolExecutionNotifications', 'toolConfigurationNotifications'] for n in i.get(field, [])]
    assert all(n.get('level') in (None, 'none') for n in notices)
    extracted = [n for n in notices if n.get('descriptor', {}).get('id', '').endswith('/diagnostics/successfully-extracted-files')]
    old_notices = [n for r in old_payload['runs'] for i in r['invocations'] for field in ['toolExecutionNotifications', 'toolConfigurationNotifications'] for n in i.get(field, [])]
    old_extracted = [n for n in old_notices if n.get('descriptor', {}).get('id', '').endswith('/diagnostics/successfully-extracted-files')]
    assert extracted and Counter(map(canonical, extracted)) == Counter(map(canonical, old_extracted))
    if key[1] == 'python':
        assert any(loc.get('physicalLocation', {}).get('artifactLocation', {}).get('uri', '').startswith('src/') for n in extracted for loc in n.get('locations', []))
    assert payload['runs'][0]['tool'] == old_payload['runs'][0]['tool']
    results = payload['runs'][0]['results']
    old_results = old_payload['runs'][0]['results']
    assert len(results) == diagnostic['sarif']['results']
    assert Counter(map(canonical, results)) == Counter(map(canonical, old_results))
    buckets = defaultdict(deque)
    for index, result in enumerate(old_results):
        buckets[canonical(result)].append(index)
    indices = []
    for index, result in enumerate(results):
        before_index = buckets[canonical(result)].popleft()
        assert result == old_results[before_index]
        prior_assessment = assessments[(key[0], key[1], before_index)]
        indices.append({'current_result_index': index, 'prior_result_index': before_index, 'canonical_full_result_sha256': sha(canonical(result))})
        review_reuse.append({'profile': key[0], 'language': key[1], 'current_artifact_id': artifact['id'], 'current_result_index': index, 'prior_run': 35326220494, 'prior_artifact_id': old['artifact']['id'], 'prior_result_index': before_index, 'complete_raw_result_equal': True, 'canonical_full_result_sha256': sha(canonical(result)), 'prior_source_assessment': prior_assessment, 'new_independent_source_review_performed': False, 'github_alert_mapping_verified': False, 'alert_disposition_changed': False})
    assert all(not bucket for bucket in buckets.values())
    comparisons.append({'profile': key[0], 'language': key[1], 'current_artifact_id': artifact['id'], 'prior_artifact_id': old['artifact']['id'], 'current_source': diagnostic['source'], 'source_and_materialization_identical': True, 'query_configuration_identical': True, 'sarif_tool_and_rule_definitions_identical': True, 'extraction_notices_identical_as_multiset': True, 'full_raw_results_identical_as_multiset': True, 'result_order_identical': results == old_results, 'result_index_mapping': indices})
    for path in sorted((ROOT / 'members' / str(artifact['id'])).iterdir()):
        retain('members/' + str(artifact['id']) + '/' + path.name, path.read_bytes(), compress=True)
    observations.append({'profile': key[0], 'language': key[1], 'job_id': job['id'], 'job_started_at': job['started_at'], 'job_completed_at': job['completed_at'], 'artifact_id': artifact['id'], 'artifact_zip_bytes': len(zip_bytes), 'artifact_zip_sha256': sha(zip_bytes), 'artifact_zip_api_digest_verified': True, 'zip_crc_passed': True, 'pr_head': HEAD, 'workflow_event_sha': EVENT_SHA, 'staged_definition_checkout': HEAD, 'actual_checkout_sequence_from_log': checkout_commits, 'source': diagnostic['source'], 'extraction_layout': diagnostic['extraction_layout'], 'database_init_source_root_from_log': '/home/runner/work/hol-guard/hol-guard', 'database_init_command': init_lines[0], 'cli_version': '2.27.0', 'cli_build': 'b47b3e59262c95aff4eeb84ac72d09e25a9c37e9', 'query_pack': f'codeql/{pack[0]}-queries', 'query_pack_version': pack[1], 'extracted_files': len(extracted), 'sarif': member, 'sarif_artifact_count': sum(len(r['artifacts']) for r in payload['runs']), 'sarif_external_result_files': False, 'sarif_execution_successful': True, 'sarif_warning_error_notifications': 0, 'sarif_results_match_collector_count': True, 'raw_findings': len(results), 'findings_by_rule': dict(Counter(r['ruleId'] for r in results)), 'github_alert_ids_mapped': False, 'security_alerts_resolved': False})

source_rows = json.loads((prior_overlay / 'source-blobs.json').read_bytes())
assert len(source_rows) == 84
for row in source_rows:
    encoded = (prior_overlay / row['retained_path']).read_bytes()
    raw = gzip.decompress(encoded)
    fresh = subprocess.check_output(['git', 'show', row['commit'] + ':' + row['path']], cwd=REPO)
    assert fresh == raw and len(raw) == row['bytes'] and sha(raw) == row['sha256']
    retain(row['retained_path'], encoded)
retain_json('source-blobs.json', source_rows)
assert len(review_reuse) == sum(o['raw_findings'] for o in observations) == 54
retain_json('result-comparison.json', {'prior_run': 35326220494, 'prior_manifest_sha256': PRIOR_MANIFEST_SHA, 'current_run': RUN, 'comparisons': comparisons}, compress=True)
retain_json('source-review-reuse.json', {'schema': 'guard.codeql-identical-result-review-reuse.v1', 'current_run': RUN, 'prior_run': 35326220494, 'prior_manifest_sha256': PRIOR_MANIFEST_SHA, 'source_blobs_verified_against_immutable_git': 84, 'new_findings': 0, 'prior_findings_removed': 0, 'mappings': review_reuse}, compress=True)
retain('inspection.json', (ROOT / 'inspection.json').read_bytes(), compress=True)
retain('initial-full-result-comparison.json', (ROOT / 'initial-full-result-comparison.json').read_bytes(), compress=True)
for path in [ROOT / 'inspect-artifacts.py', Path(__file__)]:
    retain('reproduction/' + path.name + '.txt', path.read_bytes(), compress=True)
summary = {'schema': 'guard.codeql-repeated-materialized-diagnostic.v1', 'run_id': RUN, 'attempt': 1, 'pr_number': 2954, 'head': HEAD, 'workflow_event_sha': EVENT_SHA, 'staged_definition_checkout': HEAD, 'event': run['event'], 'created_at': run['created_at'], 'completed_at': run['updated_at'], 'jobs': observations, 'all_six_jobs_completed': True, 'all_six_artifact_digests_verified': True, 'raw_findings': 54, 'raw_findings_by_profile': {p: sum(o['raw_findings'] for o in observations if o['profile'] == p) for p in ['foundation-cdd', 'implementation-d8']}, 'prior_run': 35326220494, 'prior_manifest_sha256': PRIOR_MANIFEST_SHA, 'all_full_results_match_prior_run_as_multisets': True, 'source_review_reused_with_exact_result_index_mapping': True, 'source_blobs_verified_against_immutable_git': 84, 'analyzes_current_pr_runtime': False, 'github_new_alert_counts_equivalent': False, 'security_alerts_resolved': False, 'qualification_complete': False}
retain_json('hosted-summary.json', summary)
print(json.dumps({'overlay': str(OUT), 'jobs': [{k: o[k] for k in ['profile', 'language', 'job_id', 'artifact_id', 'artifact_zip_bytes', 'extracted_files', 'raw_findings']} for o in observations], 'all_raw_results_equal_as_multisets': True, 'source_blobs_verified': 84}, indent=2))
