"""Guard configuration loading and resolution."""

from __future__ import annotations

import importlib
import json
import re
import shutil
import sqlite3
import sys
import tempfile
import time
from collections.abc import Callable, Mapping
from dataclasses import dataclass, replace
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    import tomllib
else:  # pragma: no cover - runtime compatibility
    tomllib = importlib.import_module("tomllib" if sys.version_info >= (3, 11) else "tomli")

from .action_lattice import coerce_guard_action, normalize_guard_action
from .approval_gate import ApprovalGateGrant, public_config, require_settings_write
from .config_mutation import notify_native_policy_mutation, record_posture_change_if_needed
from .config_preset_support import apply_named_posture_harness_policy
from .config_source_io import GuardConfigParentValidator, capture_guard_config
from .guard_home_state import database_has_custom_extension_state
from .mdm.contracts import ManagedPolicy, ManagedPolicyState
from .mdm.policy import apply_managed_policy, fail_closed_managed_policy, load_managed_policy
from .models import GUARD_ACTION_VALUES, GuardAction, GuardMode
from .presentation_mode import (
    PRESENTATION_SCHEMA_VERSION,
    UNSUPPORTED_PRESENTATION_SCHEMA_DIAGNOSTIC,
    coerce_persisted_presentation_mode,
    coerce_presentation_mode_write,
)
from .presentation_settings import (
    PRESENTATION_SETTING_INPUT_KEYS,
    apply_presentation_settings_update,
    next_presentation_revision,
    resolve_presentation_settings_update,
)
from .protection_posture import (
    DEFAULT_PROTECTION_POSTURE,
    DEFAULT_WATCH_AUTO_REVERT_HOURS,
    coerce_loaded_protection_posture,
    coerce_protection_posture,
    coerce_watch_auto_revert_hours,
    derive_protection_posture,
    dual_write_from_posture,
    resolve_posture_defaults,
)
from .settings_write_lock import atomic_write_settings, serialize_guard_settings

DEFAULT_GUARD_DIRNAME = ".hol-guard"
VALID_UPDATE_CHANNELS = frozenset({"stable", "alpha"})


def _utc_now_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def _coerce_watch_entered_at(value: object) -> str | None:
    if not isinstance(value, str) or not value.strip():
        return None
    try:
        datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return None
    return value.strip()


def watch_should_auto_revert(config: GuardConfig, *, now: datetime | None = None) -> bool:
    if config.protection_posture != "watch" or config.watch_auto_revert_hours <= 0:
        return False
    if config.watch_entered_at is None:
        return False
    try:
        entered = datetime.fromisoformat(config.watch_entered_at.replace("Z", "+00:00"))
    except ValueError:
        return False
    if entered.tzinfo is None:
        entered = entered.replace(tzinfo=timezone.utc)
    current = now or datetime.now(timezone.utc)
    return current - entered >= timedelta(hours=config.watch_auto_revert_hours)


def maybe_auto_revert_watch(guard_home: Path, *, now: datetime | None = None) -> GuardConfig:
    config = load_guard_config(guard_home)
    if not watch_should_auto_revert(config, now=now):
        return config
    return update_guard_settings(
        guard_home,
        {"protection_posture": "protected"},
        event_source="auto-revert",
        skip_approval_gate=True,
    )


LEGACY_GUARD_DIRNAMES = (".config/.ai-plugin-scanner-guard", ".ai-plugin-scanner-guard", ".holguard")
NON_MIGRATED_GUARD_RUNTIME_FILES = frozenset(
    {
        "daemon-state.json",
        "guard.db-journal",
        "guard.db-shm",
        "guard.db-wal",
        "schema-migration.lock",
        "storage-access.lock",
    }
)
GUARD_HOME_METADATA_FILES = frozenset(
    {
        "oauth-keychain-access.json",
        "schema-migration.lock",
        "storage-access.lock",
        "system-keyring-availability.json",
    }
)
GUARD_DB_BACKUP_TIMEOUT_SECONDS = 5.0
GUARD_DB_BACKUP_SLEEP_SECONDS = 0.05
WORKSPACE_CONFIG_FILENAMES = (".ai-plugin-scanner-guard.toml", ".hol-guard.toml")
MAX_APPROVAL_WAIT_TIMEOUT_SECONDS = 600

# Hook review controls. The resident worker is the safe production default;
# operators can explicitly disable it for emergency rollback.
# These are read from os.environ at call time so tests/daemon can toggle without restart.
HOOK_FAST_PATH_ENV = "HOL_GUARD_HOOK_FAST_PATH"
HOOK_SOURCE_REF_ENV = "HOL_GUARD_HOOK_SOURCE_REF"
HOOK_FAST_PATH_SHADOW_ENV = "HOL_GUARD_HOOK_FAST_PATH_SHADOW"


def hook_fast_path_enabled() -> bool:
    """Whether the daemon should use the resident hook worker for fast-path review."""
    import os

    return os.environ.get(HOOK_FAST_PATH_ENV, "1") == "1"


def hook_source_ref_enabled() -> bool:
    """Whether the Pi managed extension should generate guard_source_ref."""
    import os

    return os.environ.get(HOOK_SOURCE_REF_ENV, "0") == "1"


def hook_fast_path_shadow_enabled() -> bool:
    """Whether to evaluate fast path but return legacy behavior (shadow mode)."""
    import os

    return os.environ.get(HOOK_FAST_PATH_SHADOW_ENV, "0") == "1"


VALID_GUARD_ACTIONS = frozenset(GUARD_ACTION_VALUES)
VALID_GUARD_MODES = {"observe", "prompt", "enforce"}
VALID_SECURITY_LEVELS = {"relaxed", "gentle", "balanced", "strict", "paranoid", "custom"}
VALID_RISK_ACTION_KEYS = {
    "local_secret_read",
    "credential_exfiltration",
    "data_flow_exfiltration",
    "destructive_shell",
    "encoded_execution",
    "network_egress",
    "prompt_injection",
    "mcp_dangerous_tool",
    "malicious_skill",
    "package_script",
    "persistence",
    "guard_bypass",
    "cloud_advisory",
    "encoded_exfiltration",
}
DEFAULT_SECURITY_LEVEL = "balanced"
SECURITY_LEVEL_RISK_ACTIONS: dict[str, dict[str, GuardAction]] = {
    "relaxed": {
        "local_secret_read": "warn",
        "credential_exfiltration": "warn",
        "data_flow_exfiltration": "warn",
        "destructive_shell": "warn",
        "encoded_execution": "warn",
        "network_egress": "allow",
        "prompt_injection": "warn",
        "mcp_dangerous_tool": "warn",
        "malicious_skill": "warn",
        "package_script": "warn",
        "persistence": "warn",
        "guard_bypass": "warn",
        "cloud_advisory": "allow",
        "encoded_exfiltration": "warn",
    },
    "gentle": {
        "local_secret_read": "warn",
        "credential_exfiltration": "warn",
        "data_flow_exfiltration": "warn",
        "destructive_shell": "warn",
        "encoded_execution": "warn",
        "network_egress": "allow",
        "prompt_injection": "warn",
        "mcp_dangerous_tool": "warn",
        "malicious_skill": "warn",
        "package_script": "warn",
        "persistence": "warn",
        "guard_bypass": "warn",
        "cloud_advisory": "allow",
        "encoded_exfiltration": "warn",
    },
    "balanced": {
        "local_secret_read": "require-reapproval",
        "credential_exfiltration": "require-reapproval",
        "data_flow_exfiltration": "require-reapproval",
        "destructive_shell": "require-reapproval",
        "encoded_execution": "require-reapproval",
        "network_egress": "warn",
        "prompt_injection": "require-reapproval",
        "mcp_dangerous_tool": "require-reapproval",
        "malicious_skill": "require-reapproval",
        "package_script": "warn",
        "persistence": "require-reapproval",
        "guard_bypass": "block",
        "cloud_advisory": "warn",
        "encoded_exfiltration": "require-reapproval",
    },
    "strict": {
        "local_secret_read": "require-reapproval",
        "credential_exfiltration": "require-reapproval",
        "data_flow_exfiltration": "block",
        "destructive_shell": "require-reapproval",
        "encoded_execution": "require-reapproval",
        "network_egress": "require-reapproval",
        "prompt_injection": "block",
        "mcp_dangerous_tool": "block",
        "malicious_skill": "block",
        "package_script": "require-reapproval",
        "persistence": "block",
        "guard_bypass": "block",
        "cloud_advisory": "require-reapproval",
        "encoded_exfiltration": "block",
    },
    "paranoid": {
        "local_secret_read": "block",
        "credential_exfiltration": "block",
        "data_flow_exfiltration": "block",
        "destructive_shell": "block",
        "encoded_execution": "block",
        "network_egress": "block",
        "prompt_injection": "block",
        "mcp_dangerous_tool": "block",
        "malicious_skill": "block",
        "package_script": "block",
        "persistence": "block",
        "guard_bypass": "block",
        "cloud_advisory": "block",
        "encoded_exfiltration": "block",
    },
    "custom": {
        "local_secret_read": "require-reapproval",
        "credential_exfiltration": "require-reapproval",
        "data_flow_exfiltration": "require-reapproval",
        "destructive_shell": "require-reapproval",
        "encoded_execution": "require-reapproval",
        "network_egress": "warn",
        "prompt_injection": "require-reapproval",
        "mcp_dangerous_tool": "require-reapproval",
        "malicious_skill": "require-reapproval",
        "package_script": "warn",
        "persistence": "require-reapproval",
        "guard_bypass": "block",
        "cloud_advisory": "warn",
        "encoded_exfiltration": "require-reapproval",
    },
}
EDITABLE_GUARD_SETTING_KEYS = frozenset(
    {
        "mode",
        "presentation_mode",
        "presentation_mode_explicit",
        "presentation_schema_version",
        "protection_posture",
        "protection_posture_explicit",
        "watch_auto_revert_hours",
        "security_level",
        "default_action",
        "unknown_publisher_action",
        "changed_hash_action",
        "new_network_domain_action",
        "subprocess_action",
        "risk_actions",
        "harness_risk_actions",
        "approval_wait_timeout_seconds",
        "approval_surface_policy",
        "approval_browser_delay_seconds",
        "approval_browser_immediate_severity",
        "desktop_notifications",
        "update_channel",
        "telemetry",
        "sync",
        "billing",
        "receipt_redaction_level",
    }
)
VALID_RECEIPT_REDACTION_LEVELS = frozenset({"full", "partial", "none"})

VALID_APPROVAL_SURFACE_POLICIES = {"attention-aware", "auto-open-once", "native-only", "approval-center"}
VALID_APPROVAL_BROWSER_SEVERITIES = frozenset({"info", "low", "medium", "high", "critical"})
BARE_TOML_KEY = re.compile(r"^[A-Za-z0-9_-]+$")
WORKSPACE_BLOCKED_POLICY_KEYS = frozenset(
    {
        "mode",
        "presentation_mode",
        "presentation_mode_explicit",
        "presentation_schema_version",
        "presentation_revision",
        "presentation_density",
        "display_density",
        "density",
        "protection_posture",
        "watch_auto_revert_hours",
        "default_action",
        "unknown_publisher_action",
        "changed_hash_action",
        "new_network_domain_action",
        "subprocess_action",
        "security_level",
        "risk_actions",
        "harness_risk_actions",
        "harnesses",
        "publishers",
        "artifacts",
    }
)


class GuardHomeMigrationError(RuntimeError):
    """Raised when legacy Guard state cannot be migrated safely."""


def _coerce_action_map(payload: object) -> dict[str, GuardAction]:
    if not isinstance(payload, dict):
        return {}
    action_map: dict[str, GuardAction] = {}
    for key, value in payload.items():
        if not isinstance(key, str):
            continue
        action = _action_map_value(value)
        resolved_action = normalize_guard_action(action, unknown_action="require-reapproval")
        action_map[key] = resolved_action
    return action_map


def _coerce_risk_action_map(payload: object) -> dict[str, GuardAction]:
    if not isinstance(payload, dict):
        return {}
    action_map: dict[str, GuardAction] = {}
    for key, value in payload.items():
        if not isinstance(key, str) or key not in VALID_RISK_ACTION_KEYS:
            continue
        action = _action_map_value(value)
        resolved_action = normalize_guard_action(action, unknown_action="require-reapproval")
        action_map[key] = resolved_action
    return action_map


def _action_map_value(value: object) -> object:
    if not isinstance(value, dict):
        return value
    if "action" in value:
        return value.get("action")
    if "default_action" in value:
        return value.get("default_action")
    return value


def _coerce_harness_risk_action_map(payload: object) -> dict[str, dict[str, GuardAction]]:
    if not isinstance(payload, dict):
        return {}
    action_map: dict[str, dict[str, GuardAction]] = {}
    for harness, value in payload.items():
        if not isinstance(harness, str) or not harness.strip():
            continue
        harness_actions = _coerce_risk_action_map(value)
        if harness_actions:
            action_map[harness] = harness_actions
    return action_map


@dataclass(frozen=True, slots=True)
class GuardConfig:
    """Merged local Guard configuration."""

    guard_home: Path
    workspace: Path | None
    mode: GuardMode = "prompt"
    presentation_mode: str = "everyday"
    presentation_mode_explicit: bool = False
    presentation_schema_version: int = PRESENTATION_SCHEMA_VERSION
    presentation_revision: int = 0
    presentation_source: str = "default"
    presentation_diagnostic: str | None = None
    protection_posture: str = DEFAULT_PROTECTION_POSTURE
    protection_posture_explicit: bool = False
    watch_auto_revert_hours: int = DEFAULT_WATCH_AUTO_REVERT_HOURS
    watch_entered_at: str | None = None
    security_level: str = DEFAULT_SECURITY_LEVEL
    default_action: GuardAction = "warn"
    unknown_publisher_action: GuardAction = "review"
    changed_hash_action: GuardAction = "require-reapproval"
    new_network_domain_action: GuardAction = "warn"
    subprocess_action: GuardAction = "warn"
    approval_wait_timeout_seconds: int = 120
    approval_surface_policy: str = "attention-aware"
    approval_browser_delay_seconds: int = 20
    approval_browser_immediate_severity: str = "critical"
    desktop_notifications: bool = True
    update_channel: str = "stable"
    telemetry: bool = False
    sync: bool = False
    receipt_redaction_level: str = "full"
    billing: bool = False
    runtime_detector_registry: bool = False
    runtime_detector_timeout_ms: int = 50
    runtime_detector_debug_trace: bool = False
    runtime_detector_disabled_ids: tuple[str, ...] = ()
    sandbox_analysis: str = "off"
    risk_actions: dict[str, GuardAction] | None = None
    harness_risk_actions: dict[str, dict[str, GuardAction]] | None = None
    harness_actions: dict[str, GuardAction] | None = None
    publisher_actions: dict[str, GuardAction] | None = None
    artifact_actions: dict[str, GuardAction] | None = None
    evidence_retain_days: int = 90
    receipt_detail_limit: int | None = None
    guard_event_limit: int | None = None
    managed_policy_status: str = "absent"
    managed_policy_hash: str | None = None
    managed_locked_settings: tuple[str, ...] = ()
    install_owner: str = "user"
    managed_policy: ManagedPolicy | None = None

    def resolve_action_override(
        self,
        harness: str,
        artifact_id: str | None,
        publisher: str | None,
    ) -> GuardAction | None:
        narrow_override = self.resolve_artifact_or_publisher_action_override(
            artifact_id,
            publisher,
        )
        if narrow_override is not None:
            return narrow_override
        if self.harness_actions is not None and harness in self.harness_actions:
            return self.harness_actions[harness]
        return None

    def resolve_artifact_or_publisher_action_override(
        self,
        artifact_id: str | None,
        publisher: str | None,
    ) -> GuardAction | None:
        if artifact_id is not None and self.artifact_actions is not None and artifact_id in self.artifact_actions:
            return self.artifact_actions[artifact_id]
        if publisher is not None and self.publisher_actions is not None and publisher in self.publisher_actions:
            return self.publisher_actions[publisher]
        return None


def resolve_guard_home(override: str | None = None) -> Path:
    """Resolve the Guard home directory."""

    if override:
        return Path(override).expanduser().resolve()
    return resolve_guard_home_for_user_home(Path.home())


def resolve_guard_home_for_user_home(user_home: Path) -> Path:
    """Resolve Guard state beneath an already authenticated user home."""

    canonical_home = user_home / DEFAULT_GUARD_DIRNAME
    legacy_home = _existing_legacy_guard_home(user_home)
    if legacy_home is None:
        return canonical_home
    if _guard_home_has_sync_credentials(canonical_home):
        return canonical_home
    if _guard_home_has_state(canonical_home):
        return canonical_home
    if _guard_home_has_sync_credentials(legacy_home) or _guard_home_has_state(legacy_home):
        try:
            _migrate_guard_home_transactionally(source=legacy_home, destination=canonical_home)
        except GuardHomeMigrationError:
            return legacy_home
        return canonical_home
    return canonical_home


def _parse_toml(content: bytes) -> dict[str, object]:
    payload = tomllib.loads(content.decode("utf-8"))
    return payload if isinstance(payload, dict) else {}


def _read_toml(path: Path, *, parent_validator: GuardConfigParentValidator | None = None) -> dict[str, object]:
    captured = capture_guard_config(
        path,
        parent_validator=parent_validator,
        expected_parent=path.parent.absolute() if parent_validator is not None else None,
    )
    return _parse_toml(captured.content)


def _coerce_loaded_receipt_redaction_level(value: object) -> str:
    if isinstance(value, str) and value in VALID_RECEIPT_REDACTION_LEVELS:
        return value
    return "full"


def load_guard_config(
    guard_home: Path,
    workspace: Path | None = None,
    *,
    managed_policy_state: ManagedPolicyState | None = None,
    config_reader: Callable[[Path], dict[str, object]] | None = None,
) -> GuardConfig:
    """Load Guard config from home and workspace overrides."""

    guard_home.mkdir(parents=True, exist_ok=True)
    home_config = (
        _read_toml(guard_home / "config.toml") if config_reader is None else config_reader(guard_home / "config.toml")
    )
    workspace_config = _load_workspace_guard_config(workspace, config_reader=config_reader)

    merged = _merge_config_payload(home_config, workspace_config)
    managed_state = managed_policy_state or load_managed_policy()
    effective_managed_policy = managed_state.policy
    if effective_managed_policy is None and managed_state.status in {"invalid", "inaccessible", "tampered"}:
        effective_managed_policy = fail_closed_managed_policy()
    if effective_managed_policy is not None:
        merged = apply_managed_policy(merged, effective_managed_policy)
    loaded_mode = _coerce_loaded_guard_mode(merged.get("mode"), "prompt")
    loaded_security_level = _coerce_loaded_security_level(merged.get("security_level", DEFAULT_SECURITY_LEVEL))
    explicit_posture = coerce_loaded_protection_posture(merged.get("protection_posture"))
    managed_locks_level = (
        effective_managed_policy is not None and "security_level" in effective_managed_policy.locked_settings
    )
    if managed_locks_level:
        loaded_posture = derive_protection_posture(loaded_mode, loaded_security_level)
        posture_explicit = False
    elif explicit_posture is not None:
        loaded_posture = explicit_posture
        posture_explicit = True
    else:
        loaded_posture = derive_protection_posture(loaded_mode, loaded_security_level)
        posture_explicit = False
    persisted_presentation_value = merged.get("presentation_mode")
    persisted_presentation = coerce_persisted_presentation_mode(
        persisted_presentation_value,
        explicit=merged.get("presentation_mode_explicit", persisted_presentation_value is not None),
        schema_version=merged.get("presentation_schema_version", PRESENTATION_SCHEMA_VERSION),
    )
    presentation_revision = _coerce_loaded_non_negative_int(merged.get("presentation_revision"), 0)
    return GuardConfig(
        guard_home=guard_home,
        workspace=workspace,
        mode=("observe" if loaded_posture == "watch" else loaded_mode),
        presentation_mode=persisted_presentation.value,
        presentation_mode_explicit=persisted_presentation.explicit,
        presentation_schema_version=persisted_presentation.schema_version,
        presentation_revision=presentation_revision,
        presentation_source=persisted_presentation.source,
        presentation_diagnostic=persisted_presentation.diagnostic,
        protection_posture=loaded_posture,
        protection_posture_explicit=posture_explicit,
        watch_auto_revert_hours=coerce_watch_auto_revert_hours(merged.get("watch_auto_revert_hours")),
        watch_entered_at=_coerce_watch_entered_at(merged.get("watch_entered_at")),
        default_action=_coerce_loaded_guard_action_or_default(merged.get("default_action"), "warn"),
        unknown_publisher_action=_coerce_loaded_guard_action_or_default(
            merged.get("unknown_publisher_action"),
            "review",
        ),
        changed_hash_action=_coerce_loaded_guard_action_or_default(
            merged.get("changed_hash_action"),
            "require-reapproval",
        ),
        new_network_domain_action=_coerce_loaded_guard_action_or_default(
            merged.get("new_network_domain_action"),
            "warn",
        ),
        subprocess_action=_coerce_loaded_guard_action_or_default(merged.get("subprocess_action"), "warn"),
        approval_wait_timeout_seconds=_coerce_loaded_non_negative_int(
            merged.get("approval_wait_timeout_seconds"),
            120,
        ),
        approval_surface_policy=_coerce_loaded_approval_surface_policy(merged.get("approval_surface_policy")),
        approval_browser_delay_seconds=_coerce_loaded_bounded_int(
            merged.get("approval_browser_delay_seconds"),
            default=20,
            maximum=300,
        ),
        approval_browser_immediate_severity=_coerce_loaded_approval_browser_severity(
            merged.get("approval_browser_immediate_severity")
        ),
        desktop_notifications=_coerce_loaded_bool(merged.get("desktop_notifications", True)),
        update_channel=_coerce_loaded_update_channel(merged.get("update_channel")),
        telemetry=bool(merged.get("telemetry", False)),
        sync=bool(merged.get("sync", False)),
        billing=bool(merged.get("billing", False)),
        runtime_detector_registry=_coerce_loaded_bool(merged.get("runtime_detector_registry", False)),
        runtime_detector_timeout_ms=_coerce_loaded_positive_int(merged.get("runtime_detector_timeout_ms", 50), 50),
        runtime_detector_debug_trace=_coerce_loaded_bool(merged.get("runtime_detector_debug_trace", False)),
        runtime_detector_disabled_ids=_coerce_loaded_string_tuple(merged.get("runtime_detector_disabled_ids")),
        sandbox_analysis=_coerce_sandbox_analysis(merged.get("sandbox_analysis", "off")),
        harness_actions=_coerce_action_map(merged.get("harnesses")),
        publisher_actions=_coerce_action_map(merged.get("publishers")),
        artifact_actions=_coerce_action_map(merged.get("artifacts")),
        security_level=loaded_security_level,
        risk_actions=_coerce_risk_action_map(merged.get("risk_actions")),
        harness_risk_actions=_coerce_harness_risk_action_map(merged.get("harness_risk_actions")),
        receipt_redaction_level=_coerce_loaded_receipt_redaction_level(
            merged.get("receipt_redaction_level"),
        ),
        evidence_retain_days=_coerce_loaded_bounded_positive_int(
            merged.get("evidence_retain_days"),
            default=90,
            maximum=3_650,
        ),
        receipt_detail_limit=_coerce_loaded_optional_bounded_positive_int(
            merged.get("receipt_detail_limit"),
            maximum=1_000_000,
        ),
        guard_event_limit=_coerce_loaded_optional_bounded_positive_int(
            merged.get("guard_event_limit"),
            maximum=1_000_000,
        ),
        managed_policy_status=managed_state.status,
        managed_policy_hash=effective_managed_policy.content_hash if effective_managed_policy is not None else None,
        managed_locked_settings=tuple(sorted(effective_managed_policy.locked_settings))
        if effective_managed_policy is not None
        else (),
        install_owner=effective_managed_policy.install_owner if effective_managed_policy is not None else "user",
        managed_policy=effective_managed_policy,
    )


def editable_guard_settings(config: GuardConfig) -> dict[str, object]:
    """Return Guard config values that are safe to edit from the local dashboard."""

    presentation_writable = config.presentation_diagnostic != UNSUPPORTED_PRESENTATION_SCHEMA_DIAGNOSTIC
    return {
        "mode": config.mode,
        "presentation_mode": config.presentation_mode,
        "presentation_mode_explicit": config.presentation_mode_explicit,
        "presentation_schema_version": config.presentation_schema_version,
        "presentation_revision": config.presentation_revision,
        "presentation": {
            "value": config.presentation_mode,
            "source": config.presentation_source,
            "explicit": config.presentation_mode_explicit,
            "writable": presentation_writable,
            "schema_version": config.presentation_schema_version,
            "revision": config.presentation_revision,
            "diagnostic": config.presentation_diagnostic,
        },
        "presentation_diagnostic": config.presentation_diagnostic,
        "protection_posture": config.protection_posture,
        "protection_posture_explicit": config.protection_posture_explicit,
        "watch_auto_revert_hours": config.watch_auto_revert_hours,
        "security_level": config.security_level,
        "default_action": config.default_action,
        "unknown_publisher_action": config.unknown_publisher_action,
        "changed_hash_action": config.changed_hash_action,
        "new_network_domain_action": config.new_network_domain_action,
        "subprocess_action": config.subprocess_action,
        "risk_actions": _effective_risk_actions(config),
        "risk_action_overrides": dict(config.risk_actions or {}),
        "harness_risk_actions": dict(config.harness_risk_actions or {}),
        "approval_wait_timeout_seconds": config.approval_wait_timeout_seconds,
        "approval_surface_policy": config.approval_surface_policy,
        "approval_browser_delay_seconds": config.approval_browser_delay_seconds,
        "approval_browser_immediate_severity": config.approval_browser_immediate_severity,
        "desktop_notifications": config.desktop_notifications,
        "update_channel": config.update_channel,
        "telemetry": config.telemetry,
        "sync": config.sync,
        "receipt_redaction_level": config.receipt_redaction_level,
        "billing": config.billing,
        "approval_gate": public_config(config.guard_home).to_dict(),
        "managed_policy_status": config.managed_policy_status,
        "managed_policy_hash": config.managed_policy_hash,
        "managed_locked_settings": list(config.managed_locked_settings),
        "install_owner": config.install_owner,
    }


@serialize_guard_settings
def update_guard_settings(
    guard_home: Path,
    payload: dict[str, object],
    *,
    approval_gate_grant: ApprovalGateGrant | None = None,
    cloud_sync_entitled: bool = False,
    event_source: str = "settings",
    skip_approval_gate: bool = False,
) -> GuardConfig:
    """Persist safe local Guard settings to config.toml and return the updated config."""
    if not skip_approval_gate:
        require_settings_write(guard_home, approval_gate_grant=approval_gate_grant)
    current = _read_toml(guard_home / "config.toml")
    current_config = load_guard_config(guard_home)
    next_payload = dict(current)
    presentation_update = resolve_presentation_settings_update(
        payload,
        current_mode=coerce_presentation_mode_write(current_config.presentation_mode),
        current_explicit=current_config.presentation_mode_explicit,
        current_revision=current_config.presentation_revision,
        current_writable=current_config.presentation_diagnostic != UNSUPPORTED_PRESENTATION_SCHEMA_DIAGNOSTIC,
    )
    switching_to_custom_without_overrides = (
        payload.get("security_level") == "custom" and not {"risk_actions", "harness_risk_actions"} & payload.keys()
    )
    if switching_to_custom_without_overrides:
        next_payload["risk_actions"] = _effective_risk_actions(current_config)
    next_payload = apply_named_posture_harness_policy(
        next_payload, payload, valid_security_levels=VALID_SECURITY_LEVELS
    )
    for key, value in payload.items():
        if key not in EDITABLE_GUARD_SETTING_KEYS:
            continue
        if key in PRESENTATION_SETTING_INPUT_KEYS:
            continue
        next_payload[key] = _coerce_editable_setting(key, value)
    apply_presentation_settings_update(
        next_payload, presentation_update, current_revision=current_config.presentation_revision
    )
    incoming_selected_posture = _incoming_selects_protection_posture(
        payload,
        current_config,
        next_payload.get("mode", current_config.mode),
        next_payload.get("security_level", current_config.security_level),
    )
    next_payload = _sync_protection_posture_payload(next_payload, current_config, payload)
    effective_next_payload = next_payload
    if current_config.managed_policy is not None:
        effective_next_payload = apply_managed_policy(next_payload, current_config.managed_policy)
        missing = object()
        weakened = [
            key
            for key in current_config.managed_locked_settings
            if (requested := _nested_setting_value(next_payload, key, missing)) is not missing
            and _nested_setting_value(effective_next_payload, key, missing) != requested
        ]
        if weakened:
            raise ValueError(f"Managed policy locks prevent weakening: {', '.join(sorted(weakened))}")
    preserving_existing_sync = (
        current.get("sync") is True
        and current_config.sync is True
        and next_payload.get("sync") is True
        and (payload.get("mode") != "observe" or effective_next_payload.get("mode") == "observe")
    )
    if (
        next_payload.get("sync") is True
        and payload.get("sync") is True
        and not cloud_sync_entitled
        and not preserving_existing_sync
    ):
        raise ValueError("Cloud sync requires a paid team plan.")
    _write_guard_config(guard_home / "config.toml", next_payload)
    updated = load_guard_config(guard_home)
    notify_native_policy_mutation(guard_home)
    record_posture_change_if_needed(
        guard_home,
        previous=current_config.protection_posture,
        next_posture=updated.protection_posture,
        previous_explicit=current_config.protection_posture_explicit,
        next_explicit=updated.protection_posture_explicit,
        selected=incoming_selected_posture,
        event_source=event_source,
    )
    return updated


@serialize_guard_settings
def update_guard_update_channel(
    guard_home: Path,
    update_channel: object,
    *,
    approval_gate_grant: ApprovalGateGrant | None = None,
) -> GuardConfig:
    """Persist the local release channel selected from the update surface."""

    require_settings_write(guard_home, approval_gate_grant=approval_gate_grant)
    if not isinstance(update_channel, str) or update_channel not in VALID_UPDATE_CHANNELS:
        raise ValueError("Update channel must be stable or alpha.")
    current_config = load_guard_config(guard_home)
    if "update_channel" in current_config.managed_locked_settings:
        raise ValueError("Managed policy locks the update channel.")
    current = _read_toml(guard_home / "config.toml")
    current["update_channel"] = update_channel
    _write_guard_config(guard_home / "config.toml", current)
    updated = load_guard_config(guard_home)
    notify_native_policy_mutation(guard_home)
    return updated


@serialize_guard_settings
def reset_guard_settings(
    guard_home: Path,
    *,
    approval_gate_grant: ApprovalGateGrant | None = None,
) -> GuardConfig:
    """Reset editable local Guard settings while preserving non-dashboard config."""

    require_settings_write(guard_home, approval_gate_grant=approval_gate_grant)
    current = _read_toml(guard_home / "config.toml")
    next_payload = {key: value for key, value in current.items() if key not in EDITABLE_GUARD_SETTING_KEYS}
    next_payload["presentation_revision"] = next_presentation_revision(
        load_guard_config(guard_home).presentation_revision
    )
    _write_guard_config(guard_home / "config.toml", next_payload)
    updated = load_guard_config(guard_home)
    notify_native_policy_mutation(guard_home)
    return updated


def _coerce_editable_setting(key: str, value: object) -> object:
    if key == "presentation_mode":
        return coerce_presentation_mode_write(value)
    if key == "presentation_mode_explicit":
        if isinstance(value, bool):
            return value
        raise ValueError("presentation_mode_explicit must be true or false.")
    if key == "presentation_schema_version":
        if value == PRESENTATION_SCHEMA_VERSION:
            return value
        raise ValueError("Unsupported presentation schema version.")
    if key == "mode":
        if isinstance(value, str) and value in VALID_GUARD_MODES:
            return value
        raise ValueError("Invalid Guard mode.")
    if key == "protection_posture":
        return coerce_protection_posture(value)
    if key == "protection_posture_explicit":
        if isinstance(value, bool):
            return value
        raise ValueError("protection_posture_explicit must be true or false.")
    if key == "watch_auto_revert_hours":
        if isinstance(value, int) and not isinstance(value, bool) and 0 <= value <= 168:
            return value
        raise ValueError("Watch auto-revert hours must be between 0 and 168.")
    if key == "security_level":
        return _coerce_security_level(value)
    if key == "risk_actions":
        return _coerce_risk_action_payload(value)
    if key == "harness_risk_actions":
        return _coerce_harness_risk_action_payload(value)
    if key.endswith("_action"):
        if isinstance(value, str) and value in VALID_GUARD_ACTIONS:
            return value
        raise ValueError("Invalid Guard action.")
    if key == "approval_surface_policy":
        if isinstance(value, str) and value in VALID_APPROVAL_SURFACE_POLICIES:
            return "attention-aware" if value == "auto-open-once" else value
        raise ValueError("Invalid approval surface policy.")
    if key == "approval_browser_delay_seconds":
        if isinstance(value, int) and not isinstance(value, bool) and 0 <= value <= 300:
            return value
        raise ValueError("Browser attention delay must be between 0 and 300 seconds.")
    if key == "approval_browser_immediate_severity":
        if isinstance(value, str) and value in VALID_APPROVAL_BROWSER_SEVERITIES:
            return value
        raise ValueError("Invalid immediate browser attention severity.")
    if key == "approval_wait_timeout_seconds":
        if isinstance(value, int) and not isinstance(value, bool) and 0 <= value <= MAX_APPROVAL_WAIT_TIMEOUT_SECONDS:
            return value
        raise ValueError(f"Approval wait timeout must be between 0 and {MAX_APPROVAL_WAIT_TIMEOUT_SECONDS} seconds.")
    if key in {"desktop_notifications", "telemetry", "sync", "billing"}:
        if isinstance(value, bool):
            return value
        raise ValueError(f"{key} must be true or false.")
    if key == "update_channel":
        if isinstance(value, str) and value in VALID_UPDATE_CHANNELS:
            return value
        raise ValueError("Update channel must be stable or alpha.")
    if key == "receipt_redaction_level":
        if isinstance(value, str) and value in VALID_RECEIPT_REDACTION_LEVELS:
            return value
        raise ValueError(f"Invalid receipt redaction level: {value!r}")
    raise ValueError(f"Unsupported Guard setting: {key}")


def _coerce_security_level(value: object) -> str:
    if isinstance(value, str) and value in VALID_SECURITY_LEVELS:
        return value
    raise ValueError("Invalid Guard security level.")


def _coerce_loaded_security_level(value: object) -> str:
    if isinstance(value, str) and value in VALID_SECURITY_LEVELS:
        return value
    return DEFAULT_SECURITY_LEVEL


def _coerce_loaded_update_channel(value: object) -> str:
    return value if isinstance(value, str) and value in VALID_UPDATE_CHANNELS else "stable"


def _coerce_loaded_guard_mode(value: object, fallback: GuardMode) -> GuardMode:
    if value == "observe":
        return "observe"
    if value == "prompt":
        return "prompt"
    if value == "enforce":
        return "enforce"
    return fallback


def _coerce_loaded_guard_action(value: object, fallback: GuardAction | None) -> GuardAction | None:
    if value is None:
        return fallback
    return normalize_guard_action(value, unknown_action="require-reapproval")


def _coerce_loaded_guard_action_or_default(value: object, fallback: GuardAction) -> GuardAction:
    resolved = _coerce_loaded_guard_action(value, None)
    return resolved if resolved is not None else fallback


def _coerce_loaded_bool(value: object) -> bool:
    return value if isinstance(value, bool) else False


def _coerce_loaded_non_negative_int(value: object, fallback: int) -> int:
    if isinstance(value, int) and not isinstance(value, bool) and value >= 0:
        return value
    return fallback


def _coerce_loaded_bounded_int(value: object, *, default: int, maximum: int) -> int:
    if isinstance(value, int) and not isinstance(value, bool) and 0 <= value <= maximum:
        return value
    return default


def _coerce_loaded_bounded_positive_int(value: object, *, default: int, maximum: int) -> int:
    if isinstance(value, int) and not isinstance(value, bool) and 1 <= value <= maximum:
        return value
    return default


def _coerce_loaded_optional_bounded_positive_int(value: object, *, maximum: int) -> int | None:
    if value is None:
        return None
    if isinstance(value, int) and not isinstance(value, bool) and 1 <= value <= maximum:
        return value
    return None


def _coerce_loaded_approval_surface_policy(value: object) -> str:
    if value in {"auto-open-once", "approval-center"}:
        return "attention-aware"
    if isinstance(value, str) and value in VALID_APPROVAL_SURFACE_POLICIES:
        return value
    return "attention-aware"


def _coerce_loaded_approval_browser_severity(value: object) -> str:
    if isinstance(value, str) and value in VALID_APPROVAL_BROWSER_SEVERITIES:
        return value
    return "critical"


def _coerce_loaded_positive_int(value: object, fallback: int) -> int:
    if isinstance(value, int) and not isinstance(value, bool) and value > 0:
        return value
    return fallback


def _coerce_loaded_string_tuple(value: object) -> tuple[str, ...]:
    if not isinstance(value, list):
        return ()
    return tuple(item for item in value if isinstance(item, str) and item.strip())


_VALID_SANDBOX_MODES = {"off", "suspicious", "strict"}


def _coerce_sandbox_analysis(value: object) -> str:
    if isinstance(value, str) and value in _VALID_SANDBOX_MODES:
        return value
    return "off"


def _coerce_risk_action_payload(value: object) -> dict[str, GuardAction]:
    if not isinstance(value, dict):
        raise ValueError("Risk actions must be a table.")
    action_map: dict[str, GuardAction] = {}
    for key, action in value.items():
        if not isinstance(key, str) or key not in VALID_RISK_ACTION_KEYS:
            raise ValueError("Invalid Guard risk action.")
        resolved_action = coerce_guard_action(action)
        if resolved_action is None:
            raise ValueError("Invalid Guard risk action.")
        action_map[key] = resolved_action
    return action_map


def _coerce_harness_risk_action_payload(value: object) -> dict[str, dict[str, GuardAction]]:
    if not isinstance(value, dict):
        raise ValueError("Harness risk actions must be a table.")
    harness_actions: dict[str, dict[str, GuardAction]] = {}
    for harness, risk_payload in value.items():
        if not isinstance(harness, str) or not harness.strip():
            raise ValueError("Invalid Guard harness.")
        harness_actions[harness] = _coerce_risk_action_payload(risk_payload)
    return harness_actions


def _posture_or_level_defaults(config: GuardConfig) -> dict[str, GuardAction]:
    managed_locks_level = "security_level" in config.managed_locked_settings
    if config.protection_posture_explicit and not managed_locks_level:
        posture_defaults = resolve_posture_defaults(config.protection_posture)
        if posture_defaults is not None:
            return posture_defaults
    return SECURITY_LEVEL_RISK_ACTIONS.get(config.security_level, SECURITY_LEVEL_RISK_ACTIONS[DEFAULT_SECURITY_LEVEL])


def _effective_risk_actions(config: GuardConfig) -> dict[str, GuardAction]:
    return {**_posture_or_level_defaults(config), **dict(config.risk_actions or {})}


def resolve_risk_action(config: GuardConfig, risk_class: str | None, *, harness: str | None) -> GuardAction | None:
    """Resolve the configured action for a concrete runtime risk class."""

    if not isinstance(risk_class, str) or risk_class not in VALID_RISK_ACTION_KEYS:
        return None
    if isinstance(harness, str) and config.harness_risk_actions is not None:
        harness_actions = config.harness_risk_actions.get(harness)
        if harness_actions is not None and risk_class in harness_actions:
            return harness_actions[risk_class]
    if config.risk_actions is not None and risk_class in config.risk_actions:
        return config.risk_actions[risk_class]
    return _posture_or_level_defaults(config).get(risk_class)


def _sync_protection_posture_payload(
    next_payload: dict[str, object],
    current_config: GuardConfig,
    incoming: Mapping[str, object],
) -> dict[str, object]:
    synced = dict(next_payload)
    synced.pop("protection_posture_explicit", None)
    next_level = synced.get("security_level", current_config.security_level)
    if _incoming_selects_protection_posture(
        incoming,
        current_config,
        synced.get("mode", current_config.mode),
        next_level,
    ):
        posture = coerce_protection_posture(incoming.get("protection_posture"))
        synced["protection_posture"] = posture
        dual_mode, dual_level = dual_write_from_posture(
            posture,
            current_security_level=str(next_level or current_config.security_level),
        )
        if posture == "watch":
            synced["mode"] = "observe"
            if current_config.protection_posture != "watch" or not current_config.watch_entered_at:
                synced["watch_entered_at"] = _utc_now_iso()
        else:
            synced.pop("watch_entered_at", None)
            if "mode" not in incoming:
                synced["mode"] = dual_mode
        if "security_level" not in incoming and dual_level is not None:
            synced["security_level"] = dual_level
        return synced
    if "security_level" in incoming and "protection_posture" not in incoming:
        synced.pop("protection_posture", None)
        return synced
    if current_config.protection_posture_explicit:
        incoming_level = synced.get("security_level", current_config.security_level)
        incoming_mode = synced.get("mode", current_config.mode)
        if "security_level" in incoming and incoming_level != current_config.security_level:
            synced.pop("protection_posture", None)
            return synced
        if current_config.protection_posture == "watch" and incoming_mode != "observe":
            synced.pop("protection_posture", None)
            return synced
        synced["protection_posture"] = current_config.protection_posture
        if current_config.protection_posture == "watch":
            synced["mode"] = "observe"
        return synced
    synced.pop("protection_posture", None)
    return synced


def _incoming_selects_protection_posture(
    incoming: Mapping[str, object],
    current_config: GuardConfig,
    next_mode: object,
    next_level: object,
) -> bool:
    if "protection_posture" not in incoming:
        return False
    if incoming.get("protection_posture_explicit") is False:
        return False
    if incoming.get("protection_posture_explicit") is True:
        incoming_posture = coerce_protection_posture(incoming.get("protection_posture"))
        if not current_config.protection_posture_explicit:
            return True
        return incoming_posture != current_config.protection_posture
    if not {"mode", "security_level", "risk_actions"} & set(incoming):
        return True
    incoming_posture = coerce_protection_posture(incoming.get("protection_posture"))
    derived = derive_protection_posture(next_mode, next_level)
    if current_config.protection_posture_explicit:
        return incoming_posture != current_config.protection_posture
    return incoming_posture != derived


def _write_guard_config(path: Path, payload: dict[str, object]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    lines = _toml_lines_for_table(payload, ())
    atomic_write_settings(path, "\n".join(lines).strip() + "\n")


def _toml_lines_for_table(payload: Mapping[str, object], path: tuple[str, ...]) -> list[str]:
    lines: list[str] = []
    scalar_items: list[tuple[str, object]] = []
    table_items: list[tuple[str, dict[str, object]]] = []
    for key, value in sorted(payload.items(), key=lambda item: item[0]):
        nested_table = _string_object_table(value)
        if nested_table is not None:
            table_items.append((key, nested_table))
            continue
        scalar_items.append((key, value))
    if path:
        lines.append(f"[{'.'.join(_toml_key(item) for item in path)}]")
    for key, value in scalar_items:
        lines.append(f"{_toml_key(key)} = {_toml_literal(value)}")
    for key, value in table_items:
        nested_lines = _toml_lines_for_table(value, (*path, key))
        if lines and nested_lines:
            lines.append("")
        lines.extend(nested_lines)
    return lines


def _toml_key(value: str) -> str:
    if BARE_TOML_KEY.match(value):
        return value
    return json.dumps(value)


def _toml_literal(value: object) -> str:
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, int):
        return str(value)
    if isinstance(value, float):
        return repr(value)
    if isinstance(value, str):
        return json.dumps(value)
    if isinstance(value, list):
        return "[" + ", ".join(_toml_literal(item) for item in value) + "]"
    nested_table = _string_object_table(value)
    if nested_table is not None:
        return _toml_inline_table(nested_table)
    return json.dumps(str(value))


def _toml_inline_table(value: Mapping[str, object]) -> str:
    items: list[str] = []
    for key, item in sorted(value.items(), key=lambda entry: entry[0]):
        items.append(f"{_toml_key(key)} = {_toml_literal(item)}")
    return "{ " + ", ".join(items) + " }"


def overlay_synced_guard_policy(
    config: GuardConfig,
    payload: dict[str, object] | None,
) -> GuardConfig:
    if not isinstance(payload, dict):
        return config
    next_mode = config.mode
    raw_mode = payload.get("mode")
    if config.mode != "observe" and isinstance(raw_mode, str) and raw_mode in VALID_GUARD_MODES:
        next_mode = raw_mode
    default_action = _coerce_action_value(payload.get("defaultAction"), config.default_action)
    unknown_publisher_action = _coerce_action_value(
        payload.get("unknownPublisherAction"),
        config.unknown_publisher_action,
    )
    changed_hash_action = _coerce_action_value(
        payload.get("changedHashAction"),
        config.changed_hash_action,
    )
    new_network_domain_action = _coerce_action_value(
        payload.get("newNetworkDomainAction"),
        config.new_network_domain_action,
    )
    subprocess_action = _coerce_action_value(
        payload.get("subprocessAction"),
        config.subprocess_action,
    )
    sync_enabled = payload.get("syncEnabled")
    cloud_redaction_level = payload.get("receiptRedactionLevel")
    overlaid = replace(
        config,
        mode=next_mode,
        default_action=default_action,
        unknown_publisher_action=unknown_publisher_action,
        changed_hash_action=changed_hash_action,
        new_network_domain_action=new_network_domain_action,
        subprocess_action=subprocess_action,
        sync=bool(sync_enabled) if isinstance(sync_enabled, bool) else config.sync,
        receipt_redaction_level=(
            cloud_redaction_level
            if cloud_redaction_level in VALID_RECEIPT_REDACTION_LEVELS
            else config.receipt_redaction_level
        ),
    )
    return _reapply_managed_config(overlaid)


def _reapply_managed_config(config: GuardConfig) -> GuardConfig:
    if config.managed_policy is None:
        return config
    local = {
        "mode": config.mode,
        "security_level": config.security_level,
        "default_action": config.default_action,
        "unknown_publisher_action": config.unknown_publisher_action,
        "changed_hash_action": config.changed_hash_action,
        "new_network_domain_action": config.new_network_domain_action,
        "subprocess_action": config.subprocess_action,
        "risk_actions": config.risk_actions or {},
        "harness_risk_actions": config.harness_risk_actions or {},
        "telemetry": config.telemetry,
        "sync": config.sync,
        "receipt_redaction_level": config.receipt_redaction_level,
    }
    if config.protection_posture_explicit:
        local["protection_posture"] = config.protection_posture
    composed = apply_managed_policy(local, config.managed_policy)
    composed_mode = _coerce_loaded_guard_mode(composed.get("mode"), config.mode)
    composed_level = _coerce_loaded_security_level(composed.get("security_level"))
    composed_posture = coerce_loaded_protection_posture(composed.get("protection_posture"))
    managed_locks_level = "security_level" in config.managed_locked_settings
    if managed_locks_level:
        next_posture = derive_protection_posture(composed_mode, composed_level)
        next_explicit = False
    elif composed_posture is not None:
        next_posture = composed_posture
        next_explicit = True
    else:
        next_posture = derive_protection_posture(composed_mode, composed_level)
        next_explicit = False
    return replace(
        config,
        mode=composed_mode,
        protection_posture=next_posture,
        protection_posture_explicit=next_explicit,
        security_level=composed_level,
        default_action=_coerce_loaded_guard_action_or_default(composed.get("default_action"), config.default_action),
        unknown_publisher_action=_coerce_loaded_guard_action_or_default(
            composed.get("unknown_publisher_action"), config.unknown_publisher_action
        ),
        changed_hash_action=_coerce_loaded_guard_action_or_default(
            composed.get("changed_hash_action"), config.changed_hash_action
        ),
        new_network_domain_action=_coerce_loaded_guard_action_or_default(
            composed.get("new_network_domain_action"), config.new_network_domain_action
        ),
        subprocess_action=_coerce_loaded_guard_action_or_default(
            composed.get("subprocess_action"), config.subprocess_action
        ),
        risk_actions=_coerce_risk_action_map(composed.get("risk_actions")),
        harness_risk_actions=_coerce_harness_risk_action_map(composed.get("harness_risk_actions")),
        telemetry=_coerce_loaded_bool(composed.get("telemetry", config.telemetry)),
        sync=_coerce_loaded_bool(composed.get("sync", config.sync)),
        receipt_redaction_level=_coerce_loaded_receipt_redaction_level(
            composed.get("receipt_redaction_level", config.receipt_redaction_level)
        ),
    )


def _nested_setting_value(payload: dict[str, object], path: str, missing: object) -> object:
    current: object = payload
    for part in path.split("."):
        if not isinstance(current, dict) or part not in current:
            return missing
        current = current[part]
    return current


def _coerce_action_value(value: object, fallback: GuardAction) -> GuardAction:
    return _coerce_loaded_guard_action_or_default(value, fallback)


def _string_object_table(value: object) -> dict[str, object] | None:
    if not isinstance(value, dict):
        return None
    return {key: item for key, item in value.items() if isinstance(key, str)}


def _existing_legacy_guard_home(user_home: Path) -> Path | None:
    for relative_path in LEGACY_GUARD_DIRNAMES:
        candidate = user_home / relative_path
        if candidate.exists():
            return candidate
    return None


def _migrate_guard_home_state(*, source: Path, destination: Path) -> None:
    if not source.exists():
        return
    destination.mkdir(parents=True, exist_ok=True)
    replace_database = not _guard_home_has_sync_credentials(destination) and not _guard_home_has_state(destination)
    for entry in source.iterdir():
        if entry.name in NON_MIGRATED_GUARD_RUNTIME_FILES:
            continue
        target = destination / entry.name
        if target.exists():
            if replace_database and entry.name == "secrets" and entry.is_dir() and target.is_dir():
                shutil.rmtree(target)
                shutil.copytree(entry, target)
                continue
            if entry.is_dir() and target.is_dir():
                _migrate_guard_home_state(source=entry, destination=target)
                continue
            if replace_database and entry.name == "guard.db" and entry.is_file():
                _copy_guard_database(source=entry, destination=target)
            continue
        if entry.is_dir():
            shutil.copytree(entry, target)
            continue
        if entry.name == "guard.db" and entry.is_file():
            _copy_guard_database(source=entry, destination=target)
            continue
        shutil.copy2(entry, target)


def _migrate_guard_home_transactionally(*, source: Path, destination: Path) -> None:
    destination.parent.mkdir(parents=True, exist_ok=True)
    try:
        with tempfile.TemporaryDirectory(dir=destination.parent, prefix=f"{destination.name}-migration-") as temp_dir:
            staging_root = Path(temp_dir) / destination.name
            _migrate_guard_home_state(source=source, destination=staging_root)
            if destination.exists():
                _remove_guard_home_destination(destination)
            shutil.move(str(staging_root), str(destination))
    except OSError:
        raise GuardHomeMigrationError("guard home migration failed") from None


def _remove_guard_home_destination(path: Path) -> None:
    for entry in path.iterdir():
        if entry.is_dir():
            shutil.rmtree(entry)
            continue
        entry.unlink()
    path.rmdir()


def _copy_guard_database(*, source: Path, destination: Path) -> None:
    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary_destination = destination.with_name(f"{destination.name}.migrating")
    deadline = time.monotonic() + GUARD_DB_BACKUP_TIMEOUT_SECONDS
    try:
        with (
            sqlite3.connect(f"file:{source}?mode=ro", uri=True) as source_connection,
            sqlite3.connect(temporary_destination) as destination_connection,
        ):
            source_connection.backup(
                destination_connection,
                pages=128,
                progress=lambda *_: _raise_when_backup_deadline_elapsed(deadline),
                sleep=GUARD_DB_BACKUP_SLEEP_SECONDS,
            )
        _prune_retired_guard_db_sync_state(temporary_destination)
        temporary_destination.replace(destination)
    except (TimeoutError, sqlite3.Error):
        if temporary_destination.exists():
            temporary_destination.unlink()
        raise GuardHomeMigrationError("guard.db migration failed") from None


def _prune_retired_guard_db_sync_state(database_path: Path) -> None:
    try:
        with sqlite3.connect(database_path) as connection:
            connection.execute("delete from sync_state where state_key = 'credentials'")
    except sqlite3.Error:
        return


def _raise_when_backup_deadline_elapsed(deadline: float) -> None:
    if time.monotonic() >= deadline:
        raise TimeoutError("guard.db migration timed out")


def _load_workspace_guard_config(
    workspace: Path | None, *, config_reader: Callable[[Path], dict[str, object]] | None = None
) -> dict[str, object]:
    if workspace is None:
        return {}
    merged: dict[str, object] = {}
    for filename in WORKSPACE_CONFIG_FILENAMES:
        payload = _read_toml(workspace / filename) if config_reader is None else config_reader(workspace / filename)
        merged = _merge_config_payload(merged, _sanitize_workspace_guard_config(payload))
    return merged


def _sanitize_workspace_guard_config(payload: dict[str, object]) -> dict[str, object]:
    return {key: value for key, value in payload.items() if key not in WORKSPACE_BLOCKED_POLICY_KEYS}


def _merge_config_payload(base: dict[str, object], override: dict[str, object]) -> dict[str, object]:
    merged = dict(base)
    for key, value in override.items():
        existing = merged.get(key)
        if isinstance(existing, dict) and isinstance(value, dict):
            nested_existing = {name: nested_value for name, nested_value in existing.items() if isinstance(name, str)}
            nested_override = {name: nested_value for name, nested_value in value.items() if isinstance(name, str)}
            if "action" in nested_override or "default_action" in nested_override:
                nested_existing.pop("action", None)
                nested_existing.pop("default_action", None)
            merged[key] = _merge_config_payload(nested_existing, nested_override)
            continue
        merged[key] = value
    return merged


def _guard_home_has_state(path: Path) -> bool:
    if not path.exists():
        return False
    entries = list(path.iterdir())
    if not entries:
        return False
    if any(
        entry.name
        not in {
            "guard.db",
            "secrets",
            *GUARD_HOME_METADATA_FILES,
            *NON_MIGRATED_GUARD_RUNTIME_FILES,
        }
        for entry in entries
    ):
        return True
    secrets_dir = path / "secrets"
    if secrets_dir.is_dir() and any(entry.name not in {"key.bin", ".key-init.lock"} for entry in secrets_dir.iterdir()):
        return True
    database_path = path / "guard.db"
    if not database_path.is_file():
        return True
    try:
        with sqlite3.connect(f"file:{database_path}?mode=ro", uri=True) as connection:
            tables = {str(row[0]) for row in connection.execute("select name from sqlite_master where type = 'table'")}
            for table_name in (
                "harness_installations",
                "artifact_snapshots",
                "artifact_hashes",
                "artifact_diffs",
                "artifact_inventory",
                "policy_decisions",
                "runtime_receipts",
                "publisher_cache",
                "guard_events",
                "managed_installs",
                "guard_sessions",
                "guard_operations",
                "guard_operation_items",
                "guard_client_attachments",
                "guard_surface_opens",
                "approval_requests",
            ):
                if table_name not in tables:
                    continue
                if connection.execute(f"select 1 from {table_name} limit 1").fetchone() is not None:
                    return True
            return database_has_custom_extension_state(connection, tables)
    except sqlite3.Error:
        return True


def _guard_home_has_sync_credentials(path: Path) -> bool:
    database_path = path / "guard.db"
    if not database_path.is_file():
        return False
    try:
        with sqlite3.connect(f"file:{database_path}?mode=ro", uri=True) as connection:
            row = connection.execute(
                """
                select 1
                from sync_state
                where state_key = 'oauth_local_credentials'
                limit 1
                """
            ).fetchone()
    except sqlite3.Error:
        return False
    return row is not None
