"""Crash-safe, externally anchored extension-control authority persistence."""

# pyright: reportAttributeAccessIssue=false, reportPrivateUsage=false, reportUnknownArgumentType=false, reportUnknownMemberType=false, reportUnknownVariableType=false

from __future__ import annotations

import base64
import hashlib
import json
import secrets
from collections.abc import Mapping
from dataclasses import replace
from typing import cast

from .managed_controls_policy_bundle import (
    MANAGED_CONTROLS_ACTIVE_STATE_KEY,
    MANAGED_CONTROLS_LAST_GOOD_STATE_KEY,
    MANAGED_CONTROLS_REVISION_STATE_KEY,
    managed_controls_layers_from_activation_state,
    managed_controls_revision_from_state,
)
from .runtime.command_dns_extensions import expand_legacy_dns_layers
from .runtime.command_extensions import CommandSafetyExtensionRegistry
from .runtime.extension_control_authority import (
    SNAPSHOT_PURPOSE,
    TRANSITION_PURPOSE,
    AuthorityAnchor,
    AuthorityHealth,
    AuthorityPhase,
    ExtensionControlAuthorityError,
    ExtensionControlAuthorityView,
    authenticated_record,
    layers_from_json,
    layers_to_json,
    verify_authenticated_record,
)
from .runtime.extension_control_contract import (
    ControlLayerKind,
    ControlState,
    ExtensionControl,
    ExtensionControlLayer,
)
from .runtime.extension_control_proof import (
    ExtensionControlEnrollment,
    ExtensionControlEnrollmentProof,
    ExtensionControlMutation,
    ExtensionControlProof,
    consume_extension_control_enrollment_proof,
    consume_extension_control_proof,
    validate_extension_control_enrollment_proof,
    validate_extension_control_proof,
)
from .store_base import SecretStore
from .store_extension_control_authority_schema import ensure_extension_control_authority_schema
from .store_extension_control_authority_support import (
    _now,
    _private_hash,
    _row_int,
    _row_str,
    preserve_managed_extension_control,
    preserve_migrated_extension_control,
)
from .store_extension_control_authority_transitions import _ExtensionControlAuthorityTransitionMixin


class StoreExtensionControlAuthorityMixin(_ExtensionControlAuthorityTransitionMixin):
    """GuardStore mixin for the local extension-control authority."""

    _extension_control_authority_secret_store: SecretStore | None = None
    _extension_control_degraded_acknowledged: bool = False
    _extension_control_last_catalog_digest: str = "0" * 64
    _catalog_manifest_purpose = "hol-guard.extension-control-catalog-manifest.v1"

    def read_extension_control_authority(self, *, catalog_digest: str) -> ExtensionControlAuthorityView:
        self._extension_control_last_catalog_digest = catalog_digest
        try:
            with self._extension_control_authority_lock():
                return self._read_extension_control_authority_locked(catalog_digest)
        except ExtensionControlAuthorityError:
            return self._tampered_view(catalog_digest)
        except Exception:
            return self._degraded_view(catalog_digest)

    def read_extension_control_authority_for_registry(
        self,
        registry: CommandSafetyExtensionRegistry,
        *,
        include_managed_controls: bool = True,
        read_only: bool = False,
    ) -> ExtensionControlAuthorityView:
        from .native_command_control_authority_io import NativeCommandControlMutationRequiredError

        catalog_digest = registry.catalog_digest
        self._extension_control_last_catalog_digest = catalog_digest
        try:
            self._catalog_target_manifest(registry)
            with self._extension_control_authority_lock(shared=read_only):
                self._require_compatible_extension_control_schema()
                view = self._read_extension_control_authority_locked(catalog_digest, migration_registry=registry)
                stale_manifest: dict[str, str] | None = None
                authority_key: bytes | None = None
                if view.health is AuthorityHealth.PROTECTED:
                    authority_key = self._authority_key(required=True)
                    if authority_key is None:
                        raise ExtensionControlAuthorityError("extension-control authority key is unavailable")
                    view, stale_manifest = self._sync_trusted_catalog_manifest(view, registry, key=authority_key)
                if include_managed_controls:
                    composed = self._with_managed_controls_activation(
                        view,
                        current_manifest=self._catalog_target_manifest(registry),
                        previous_manifest=stale_manifest,
                    )
                else:
                    composed = view
                if stale_manifest is not None:
                    if authority_key is None:
                        raise ExtensionControlAuthorityError("extension-control authority key is unavailable")
                    self._write_catalog_manifest(
                        registry,
                        key=authority_key,
                        manifest=self._catalog_target_manifest(registry),
                        replace=True,
                    )
                return composed
        except NativeCommandControlMutationRequiredError:
            raise
        except ExtensionControlAuthorityError:
            return self._tampered_view(catalog_digest)
        except Exception:
            return self._degraded_view(catalog_digest)

    def _with_managed_controls_activation(
        self,
        view: ExtensionControlAuthorityView,
        *,
        current_manifest: Mapping[str, str] | None = None,
        previous_manifest: Mapping[str, str] | None = None,
    ) -> ExtensionControlAuthorityView:
        with self._connect() as connection:
            rows = connection.execute(
                "select state_key, payload_json from sync_state where state_key in (?, ?)",
                (
                    MANAGED_CONTROLS_ACTIVE_STATE_KEY,
                    MANAGED_CONTROLS_REVISION_STATE_KEY,
                ),
            ).fetchall()
        managed_state: dict[str, object] = {}
        for row in rows:
            try:
                managed_state[str(row["state_key"])] = json.loads(str(row["payload_json"]))
            except json.JSONDecodeError as exc:
                raise ExtensionControlAuthorityError("invalid managed controls state") from exc
        active = managed_state.get(MANAGED_CONTROLS_ACTIVE_STATE_KEY)
        revision_state = managed_state.get(MANAGED_CONTROLS_REVISION_STATE_KEY)
        local_layers = tuple(layer for layer in view.layers if layer.kind is ControlLayerKind.LOCAL_ADMIN)
        if active is None or active == {}:
            if revision_state is None or revision_state == {}:
                return view
            key = self._authority_key(required=True)
            assert key is not None
            managed_revision = managed_controls_revision_from_state(
                revision_state,
                authority_key=key,
            )
            return ExtensionControlAuthorityView(
                view.health,
                view.revision,
                view.catalog_digest,
                local_layers,
                managed_revision,
            )
        if view.health is not AuthorityHealth.PROTECTED:
            raise ExtensionControlAuthorityError("managed controls require protected local authority")
        if revision_state is None or revision_state == {}:
            raise ExtensionControlAuthorityError("managed controls revision state is missing")
        key = self._authority_key(required=True)
        assert key is not None
        if not isinstance(active, dict):
            raise ExtensionControlAuthorityError("invalid managed controls activation state")
        active_catalog_digest = active.get("catalogDigest")
        if not isinstance(active_catalog_digest, str) or not active_catalog_digest:
            raise ExtensionControlAuthorityError("invalid managed controls activation catalog")
        managed_layers, managed_revision = managed_controls_layers_from_activation_state(
            active,
            catalog_digest=active_catalog_digest,
            authority_key=key,
        )
        durable_revision = managed_controls_revision_from_state(
            revision_state,
            authority_key=key,
        )
        if managed_revision != durable_revision:
            raise ExtensionControlAuthorityError("managed controls activation revision mismatch")
        if any(layer.catalog_digest != active_catalog_digest for layer in managed_layers):
            raise ExtensionControlAuthorityError("managed controls activation layer catalog mismatch")
        if current_manifest is None:
            from .runtime.command_extensions import BUILT_IN_COMMAND_EXTENSION_REGISTRY

            if (
                active_catalog_digest != view.catalog_digest
                or view.catalog_digest != BUILT_IN_COMMAND_EXTENSION_REGISTRY.catalog_digest
            ):
                raise ExtensionControlAuthorityError("managed controls current catalog manifest is missing")
            current_manifest = self._catalog_target_manifest(BUILT_IN_COMMAND_EXTENSION_REGISTRY)
        from .store import GuardStore
        from .store_managed_control_manifest_context import pin_managed_manifest_context

        context = pin_managed_manifest_context(cast(GuardStore, self), active=active, layers=managed_layers, key=key)
        # Compare every read with the activation's immutable source contracts.
        # A mutable current manifest cannot erase a previously required clamp.
        managed_layers = tuple(
            replace(
                layer,
                catalog_digest=view.catalog_digest,
                controls=tuple(
                    control
                    if preserve_managed_extension_control(
                        control,
                        previous_manifest=context.manifest,
                        current_manifest=current_manifest,
                    )
                    else replace(control, state=ControlState.DISABLED)
                    for control in layer.controls
                ),
            )
            for layer in managed_layers
        )
        local_layers = tuple(layer for layer in view.layers if layer.kind is ControlLayerKind.LOCAL_ADMIN)
        composed = ExtensionControlAuthorityView(
            view.health,
            view.revision,
            view.catalog_digest,
            (*local_layers, *managed_layers),
            managed_revision,
        )
        return composed

    def managed_controls_lkg_capabilities(
        self,
        policy_bundle: dict[str, object],
    ) -> frozenset[str]:
        """Return negotiation bound to the exact authenticated managed LKG."""

        state = self.get_sync_payload(MANAGED_CONTROLS_LAST_GOOD_STATE_KEY)
        if not isinstance(state, dict):
            return frozenset()
        if state.get("bundleHash") != policy_bundle.get("bundleHash") or state.get(
            "bundleVersion"
        ) != policy_bundle.get("bundleVersion"):
            return frozenset()
        key = self._authority_key(required=False)
        if key is None:
            return frozenset()
        try:
            managed_controls_layers_from_activation_state(
                state,
                catalog_digest=str(state.get("catalogDigest", "")),
                authority_key=key,
            )
        except ExtensionControlAuthorityError:
            return frozenset()
        raw = state.get("negotiatedCapabilities")
        if not isinstance(raw, list) or any(not isinstance(item, str) for item in raw):
            return frozenset()
        return frozenset(cast(list[str], raw))

    def enroll_extension_control_authority(
        self,
        *,
        catalog_digest: str,
        actor_id: str,
        nonce: str,
        proof: ExtensionControlEnrollmentProof,
    ) -> ExtensionControlAuthorityView:
        enrollment = ExtensionControlEnrollment(
            catalog_digest=catalog_digest,
            actor_id=actor_id,
            nonce=nonce,
        )
        validate_extension_control_enrollment_proof(proof, enrollment)
        with self._extension_control_authority_lock():
            current = self._read_extension_control_authority_locked(catalog_digest)
            if current.health is not AuthorityHealth.UNENROLLED:
                raise ExtensionControlAuthorityError("extension control authority already enrolled")
            consume_extension_control_enrollment_proof(self.guard_home, proof, enrollment)
            return self._bootstrap_extension_control_authority(catalog_digest, key=None)

    def commit_extension_control_layers(
        self,
        layers: tuple[ExtensionControlLayer, ...],
        *,
        catalog_digest: str,
        actor_id: str,
        expected_revision: int,
        idempotency_key: str,
        nonce: str,
        proof: ExtensionControlProof,
    ) -> ExtensionControlAuthorityView:
        self._validate_commit_input(
            layers,
            catalog_digest=catalog_digest,
            actor_id=actor_id,
            expected_revision=expected_revision,
            idempotency_key=idempotency_key,
            nonce=nonce,
        )
        mutation = ExtensionControlMutation(
            previous_revision=expected_revision,
            catalog_digest=catalog_digest,
            layers=layers,
            actor_id=actor_id,
            idempotency_key=idempotency_key,
            nonce=nonce,
        )
        validate_extension_control_proof(proof, mutation)
        layers_json = layers_to_json(layers)
        self._validate_serialized_layers(layers_json)
        with self._extension_control_authority_lock():
            self._invalidate_native_extension_control_policy()
            current = self._read_extension_control_authority_locked(catalog_digest)
            key = self._authority_key(required=True)
            assert key is not None
            actor_hash = _private_hash(actor_id, key=key, purpose="actor")
            idempotency_hash = _private_hash(idempotency_key, key=key, purpose="idempotency")
            nonce_hash = _private_hash(nonce, key=key, purpose="nonce")
            proof_hash = _private_hash(proof.proof_id, key=key, purpose="proof")
            proof_already_consumed = False
            with self._connect() as connection:
                ensure_extension_control_authority_schema(connection)
                proof_record = connection.execute(
                    "select * from extension_control_authority_proof where proof_id_hash = ?",
                    (proof_hash,),
                ).fetchone()
                replay = connection.execute(
                    "select * from extension_control_authority_transition where idempotency_key_hash = ?",
                    (idempotency_hash,),
                ).fetchone()
                if proof_record is not None and (
                    replay is None or AuthorityPhase(str(replay["phase"])) is AuthorityPhase.COMMITTED
                ):
                    raise ExtensionControlAuthorityError("extension control authority proof replay")
                if (
                    proof_record is not None
                    and replay is not None
                    and (
                        str(proof_record["mutation_digest"]) != mutation.canonical_digest
                        or int(proof_record["transition_revision"]) != _row_int(replay, "revision")
                    )
                ):
                    raise ExtensionControlAuthorityError("extension control authority proof state conflict")
                if replay is not None:
                    resumed = self._resume_idempotent_transition(
                        connection,
                        replay,
                        current=current,
                        catalog_digest=catalog_digest,
                        layers_json=layers_json,
                        actor_hash=actor_hash,
                        idempotency_hash=idempotency_hash,
                        nonce_hash=nonce_hash,
                        expected_revision=expected_revision,
                        key=key,
                    )
                    if resumed is not None:
                        consumed_at = _now()
                        if proof_record is None:
                            consume_extension_control_proof(self.guard_home, proof, mutation)
                            connection.execute(
                                """
                                insert into extension_control_authority_proof (
                                    proof_id_hash, mutation_digest, transition_revision,
                                    reserved_at, consumed_at
                                ) values (?, ?, ?, ?, ?)
                                """,
                                (
                                    proof_hash,
                                    mutation.canonical_digest,
                                    _row_int(replay, "revision"),
                                    consumed_at,
                                    consumed_at,
                                ),
                            )
                        else:
                            connection.execute(
                                """
                                update extension_control_authority_proof
                                set consumed_at = coalesce(consumed_at, ?)
                                where proof_id_hash = ?
                                """,
                                (consumed_at, proof_hash),
                            )
                        return resumed
                    connection.commit()
                    if proof_record is not None:
                        connection.execute(
                            "delete from extension_control_authority_proof where proof_id_hash = ?",
                            (proof_hash,),
                        )
                        proof_already_consumed = True
                    current = self._read_extension_control_authority_locked(catalog_digest)
            if current.health is not AuthorityHealth.PROTECTED:
                raise ExtensionControlAuthorityError("extension control authority unavailable")
            with self._connect() as connection:
                ensure_extension_control_authority_schema(connection)
                if current.revision != expected_revision:
                    raise ExtensionControlAuthorityError("extension control authority revision conflict")
                if (
                    connection.execute(
                        "select 1 from extension_control_authority_transition where nonce_hash = ?",
                        (nonce_hash,),
                    ).fetchone()
                    is not None
                ):
                    raise ExtensionControlAuthorityError("extension control authority nonce replay")
                if (
                    connection.execute(
                        "select 1 from extension_control_authority_proof where proof_id_hash = ?",
                        (proof_hash,),
                    ).fetchone()
                    is not None
                ):
                    raise ExtensionControlAuthorityError("extension control authority proof replay")
                snapshot_row = connection.execute(
                    "select snapshot_digest from extension_control_authority_snapshot where singleton = 1"
                ).fetchone()
                if snapshot_row is None:
                    raise ExtensionControlAuthorityError("extension control authority snapshot missing")
                previous_digest = str(snapshot_row["snapshot_digest"])

            revision = current.revision + 1
            created_at = _now()
            snapshot_json, snapshot_digest, snapshot_mac = authenticated_record(
                {
                    "revision": revision,
                    "catalog_digest": catalog_digest,
                    "layers_json": layers_json,
                    "previous_digest": previous_digest,
                    "committed_at": created_at,
                },
                key=key,
                purpose=SNAPSHOT_PURPOSE,
            )
            transition_json, transition_digest, transition_mac = authenticated_record(
                {
                    "revision": revision,
                    "previous_revision": current.revision,
                    "previous_digest": previous_digest,
                    "snapshot_digest": snapshot_digest,
                    "catalog_digest": catalog_digest,
                    "actor_id_hash": actor_hash,
                    "idempotency_key_hash": idempotency_hash,
                    "nonce_hash": nonce_hash,
                    "created_at": created_at,
                    "phase": AuthorityPhase.PREPARED.value,
                },
                key=key,
                purpose=TRANSITION_PURPOSE,
            )
            with self._connect() as connection:
                ensure_extension_control_authority_schema(connection)
                connection.execute(
                    """
                    insert into extension_control_authority_proof (
                        proof_id_hash, mutation_digest, transition_revision, reserved_at
                    ) values (?, ?, ?, ?)
                    """,
                    (proof_hash, mutation.canonical_digest, revision, created_at),
                )
                connection.execute(
                    """
                    insert into extension_control_authority_transition (
                        revision, previous_revision, phase, actor_id_hash, idempotency_key_hash,
                        nonce_hash, catalog_digest, layers_json, snapshot_json, snapshot_digest,
                        snapshot_mac, transition_json, transition_digest, transition_mac, created_at
                    ) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        revision,
                        current.revision,
                        AuthorityPhase.PREPARED.value,
                        actor_hash,
                        idempotency_hash,
                        nonce_hash,
                        catalog_digest,
                        layers_json,
                        snapshot_json,
                        snapshot_digest,
                        snapshot_mac,
                        transition_json,
                        transition_digest,
                        transition_mac,
                        created_at,
                    ),
                )
            if not proof_already_consumed:
                consume_extension_control_proof(self.guard_home, proof, mutation)
            anchored = AuthorityAnchor(revision, snapshot_digest, AuthorityPhase.ANCHORED)
            try:
                self._write_and_verify_anchor(anchored, key=key)
            except Exception as exc:
                raise ExtensionControlAuthorityError("extension control authority anchor unavailable") from exc
            with self._connect() as connection:
                connection.execute(
                    "update extension_control_authority_transition set phase = ? where revision = ?",
                    (AuthorityPhase.ANCHORED.value, revision),
                )
                connection.execute(
                    """
                    update extension_control_authority_snapshot
                    set revision = ?, catalog_digest = ?, layers_json = ?, previous_digest = ?,
                        snapshot_json = ?, snapshot_digest = ?, snapshot_mac = ?, committed_at = ?
                    where singleton = 1 and revision = ? and snapshot_digest = ?
                    """,
                    (
                        revision,
                        catalog_digest,
                        layers_json,
                        previous_digest,
                        snapshot_json,
                        snapshot_digest,
                        snapshot_mac,
                        created_at,
                        current.revision,
                        previous_digest,
                    ),
                )
                if connection.execute("select changes()").fetchone()[0] != 1:
                    raise ExtensionControlAuthorityError("extension control authority concurrent update")
                connection.execute(
                    """
                    update extension_control_authority_proof
                    set consumed_at = ?
                    where proof_id_hash = ? and transition_revision = ? and consumed_at is null
                    """,
                    (created_at, proof_hash, revision),
                )
                if connection.execute("select changes()").fetchone()[0] != 1:
                    raise ExtensionControlAuthorityError("extension control authority proof state conflict")
                connection.execute(
                    "update extension_control_authority_transition set phase = ?, committed_at = ? where revision = ?",
                    (AuthorityPhase.COMMITTED.value, created_at, revision),
                )
            try:
                self._write_and_verify_anchor(
                    AuthorityAnchor(revision, snapshot_digest, AuthorityPhase.COMMITTED),
                    key=key,
                )
            except Exception as exc:
                raise ExtensionControlAuthorityError("extension control authority final anchor unavailable") from exc
            with self._connect() as connection:
                self._queue_extension_control_change_event(
                    connection,
                    revision=revision,
                    previous_revision=current.revision,
                    layers_json=layers_json,
                    occurred_at=created_at,
                )
            return self._read_extension_control_authority_locked(catalog_digest)

    def recover_extension_control_authority(
        self,
        *,
        catalog_digest: str,
        migration_registry: CommandSafetyExtensionRegistry | None = None,
    ) -> ExtensionControlAuthorityView:
        with self._extension_control_authority_lock():
            self._invalidate_native_extension_control_policy(explicit_recovery=True)
            key = self._authority_key(required=False)
            if key is None:
                return self._reset_extension_control_authority(
                    catalog_digest, key=None, reason="authentication-key-missing"
                )
            anchor = self._read_anchor(key=key)
            with self._connect() as connection:
                ensure_extension_control_authority_schema(connection)
                snapshot = connection.execute(
                    "select revision, snapshot_digest from extension_control_authority_snapshot where singleton = 1"
                ).fetchone()
                if snapshot is None or anchor is None:
                    return self._reset_extension_control_authority(
                        catalog_digest,
                        key=key,
                        reason="snapshot-or-anchor-missing",
                    )
                current_revision = _row_int(snapshot, "revision")
                current_digest = _row_str(snapshot, "snapshot_digest")
                pending = connection.execute(
                    """
                    select * from extension_control_authority_transition
                    where (revision = ? and phase != ?) or revision = ?
                    order by revision
                    limit 1
                    """,
                    (
                        current_revision,
                        AuthorityPhase.COMMITTED.value,
                        current_revision + 1,
                    ),
                ).fetchone()
                if pending is not None:
                    resumed = self._resume_idempotent_transition(
                        connection,
                        pending,
                        current=ExtensionControlAuthorityView(
                            AuthorityHealth.RECOVERY_REQUIRED,
                            current_revision,
                            catalog_digest,
                            (),
                        ),
                        catalog_digest=_row_str(pending, "catalog_digest"),
                        layers_json=_row_str(pending, "layers_json"),
                        actor_hash=_row_str(pending, "actor_id_hash"),
                        idempotency_hash=_row_str(pending, "idempotency_key_hash"),
                        nonce_hash=_row_str(pending, "nonce_hash"),
                        expected_revision=_row_int(pending, "previous_revision"),
                        key=key,
                    )
                    if resumed is not None and resumed.health is AuthorityHealth.PROTECTED:
                        return resumed
                    connection.commit()
                if anchor.revision == current_revision and anchor.snapshot_digest == current_digest:
                    if anchor.phase is not AuthorityPhase.COMMITTED:
                        self._write_and_verify_anchor(
                            AuthorityAnchor(
                                current_revision,
                                current_digest,
                                AuthorityPhase.COMMITTED,
                            ),
                            key=key,
                        )
                    if current_revision > 0:
                        committed = connection.execute(
                            """select previous_revision, layers_json, created_at
                               from extension_control_authority_transition where revision = ? and phase = ?""",
                            (current_revision, AuthorityPhase.COMMITTED.value),
                        ).fetchone()
                        if committed is None:
                            return self._reset_extension_control_authority(
                                catalog_digest,
                                key=key,
                                reason="committed-transition-missing",
                            )
                        self._queue_extension_control_change_event(
                            connection,
                            revision=current_revision,
                            previous_revision=_row_int(committed, "previous_revision"),
                            layers_json=_row_str(committed, "layers_json"),
                            occurred_at=_row_str(committed, "created_at"),
                        )
                    recovered = self._read_extension_control_authority_locked(
                        catalog_digest,
                        migration_registry=migration_registry,
                    )
                    if recovered.health is AuthorityHealth.PROTECTED:
                        return recovered
            return self._reset_extension_control_authority(
                catalog_digest,
                key=key,
                reason="authenticated-recovery-unverifiable",
            )

    def _reset_extension_control_authority(
        self,
        catalog_digest: str,
        *,
        key: bytes | None,
        reason: str,
    ) -> ExtensionControlAuthorityView:
        # Never import rows with an unverifiable chain; re-establish an empty protected authority.
        from .native_command_control_authority_store import begin_native_command_control_recovery
        from .store import GuardStore

        recovered_key = key if key is not None else secrets.token_bytes(32)
        begin_native_command_control_recovery(cast(GuardStore, self), new_authority_key=recovered_key)
        if key is None:
            self._secret_store().set_secret(self._key_ref(), base64.urlsafe_b64encode(recovered_key).decode())
        reset_at = _now()
        with self._connect() as connection:
            ensure_extension_control_authority_schema(connection)
            snapshot = connection.execute(
                "select * from extension_control_authority_snapshot where singleton = 1"
            ).fetchone()
            transitions = connection.execute(
                "select * from extension_control_authority_transition order by revision"
            ).fetchall()
            proofs = connection.execute(
                "select * from extension_control_authority_proof order by transition_revision, proof_id_hash"
            ).fetchall()
            snapshot_payload = dict(snapshot) if snapshot is not None else None
            transition_payload = [dict(row) for row in transitions]
            proof_payload = [dict(row) for row in proofs]
            previous_snapshot_digest = (
                str(snapshot_payload["snapshot_digest"]) if snapshot_payload is not None else "missing"
            )
            archive_id = hashlib.sha256(f"{reset_at}\0{reason}\0{previous_snapshot_digest}".encode()).hexdigest()
            provenance = {
                "reason": reason,
                "archive_id": archive_id,
                "previous_revision": int(snapshot_payload["revision"]) if snapshot_payload is not None else None,
                "previous_catalog_digest": (
                    str(snapshot_payload["catalog_digest"]) if snapshot_payload is not None else None
                ),
                "previous_snapshot_digest": (
                    str(snapshot_payload["snapshot_digest"]) if snapshot_payload is not None else None
                ),
                "previous_layers_bytes": (
                    len(str(snapshot_payload["layers_json"]).encode("utf-8")) if snapshot_payload is not None else 0
                ),
                "previous_transition_count": len(transition_payload),
                "catalog_digest": catalog_digest,
            }
            connection.execute(
                """
                insert into extension_control_authority_recovery_archive (
                    archive_id, reason, archived_at, previous_revision, previous_catalog_digest,
                    snapshot_row_json, transition_rows_json, proof_rows_json
                ) values (?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    archive_id,
                    reason,
                    reset_at,
                    provenance["previous_revision"],
                    provenance["previous_catalog_digest"],
                    json.dumps(snapshot_payload, sort_keys=True, separators=(",", ":")),
                    json.dumps(transition_payload, sort_keys=True, separators=(",", ":")),
                    json.dumps(proof_payload, sort_keys=True, separators=(",", ":")),
                ),
            )
            connection.execute(
                "insert into guard_events (event_name, payload_json, occurred_at) values (?, ?, ?)",
                (
                    "extension_control_authority_reset",
                    json.dumps(provenance, sort_keys=True, separators=(",", ":")),
                    reset_at,
                ),
            )
            connection.execute("delete from extension_control_authority_proof")
            connection.execute("delete from extension_control_authority_transition")
            connection.execute("delete from extension_control_authority_snapshot")
            if key is None:
                # These rows authenticate with the lost key. They cannot be
                # reused under the explicit new-key recovery epoch. Managed
                # activation remains independently authenticated and fail-closed.
                connection.execute("delete from extension_control_catalog_manifest")
        return self._bootstrap_extension_control_authority(catalog_digest, key=recovered_key)

    def acknowledge_extension_control_degraded_mode(self) -> ExtensionControlAuthorityView:
        with self._extension_control_authority_lock():
            self._invalidate_native_extension_control_policy()
            self._extension_control_degraded_acknowledged = True
            return self._degraded_view(self._extension_control_last_catalog_digest)

    def _read_extension_control_authority_locked(
        self,
        catalog_digest: str,
        *,
        migration_registry: CommandSafetyExtensionRegistry | None = None,
    ) -> ExtensionControlAuthorityView:
        with self._connect() as connection:
            if not ensure_extension_control_authority_schema(connection, require_compatible=False):
                return self._degraded_view(catalog_digest)
            row = connection.execute(
                "select * from extension_control_authority_snapshot where singleton = 1"
            ).fetchone()
        try:
            key = self._authority_key(required=False)
            anchor = self._read_anchor(key=key) if key is not None else None
        except Exception:
            return self._degraded_view(catalog_digest)
        if row is None and anchor is None:
            return ExtensionControlAuthorityView(AuthorityHealth.UNENROLLED, 0, catalog_digest, ())
        if row is None or key is None or anchor is None:
            return self._tampered_view(catalog_digest)
        try:
            revision = int(row["revision"])
            stored_catalog_digest = str(row["catalog_digest"])
            if stored_catalog_digest != catalog_digest:
                if migration_registry is None or migration_registry.catalog_digest != catalog_digest:
                    raise ExtensionControlAuthorityError("extension control catalog digest changed")
                pending = self._pending_transition(revision + 1)
                if pending is not None and _row_str(pending, "catalog_digest") == catalog_digest:
                    with self._connect() as connection:
                        resumed = self._resume_idempotent_transition(
                            connection,
                            pending,
                            current=ExtensionControlAuthorityView(
                                AuthorityHealth.RECOVERY_REQUIRED,
                                revision,
                                stored_catalog_digest,
                                (),
                            ),
                            catalog_digest=_row_str(pending, "catalog_digest"),
                            layers_json=_row_str(pending, "layers_json"),
                            actor_hash=_row_str(pending, "actor_id_hash"),
                            idempotency_hash=_row_str(pending, "idempotency_key_hash"),
                            nonce_hash=_row_str(pending, "nonce_hash"),
                            expected_revision=_row_int(pending, "previous_revision"),
                            key=key,
                        )
                    if resumed is not None and resumed.health is AuthorityHealth.PROTECTED:
                        return resumed
                previous = self._read_extension_control_authority_locked(stored_catalog_digest)
                if previous.health is not AuthorityHealth.PROTECTED:
                    raise ExtensionControlAuthorityError("extension control catalog migration source unavailable")
                return self._migrate_extension_control_catalog(previous, registry=migration_registry, key=key)
            payload = verify_authenticated_record(
                str(row["snapshot_json"]),
                expected_digest=str(row["snapshot_digest"]),
                expected_mac=str(row["snapshot_mac"]),
                key=key,
                purpose=SNAPSHOT_PURPOSE,
            )
            expected = {
                "revision": revision,
                "catalog_digest": str(row["catalog_digest"]),
                "layers_json": str(row["layers_json"]),
                "previous_digest": row["previous_digest"],
                "committed_at": str(row["committed_at"]),
            }
            if any(payload.get(name) != value for name, value in expected.items()):
                raise ExtensionControlAuthorityError("extension control snapshot field mismatch")
            self._validate_serialized_layers(str(row["layers_json"]))
            layers = layers_from_json(str(row["layers_json"]))
            self._validate_layers(layers, catalog_digest)
            if anchor.revision != revision or anchor.snapshot_digest != str(row["snapshot_digest"]):
                pending = self._pending_transition(revision + 1)
                if not (
                    pending is not None
                    and anchor.phase is AuthorityPhase.ANCHORED
                    and anchor.revision == revision + 1
                    and anchor.snapshot_digest == _row_str(pending, "snapshot_digest")
                ):
                    raise ExtensionControlAuthorityError("extension control authority rollback detected")
                return ExtensionControlAuthorityView(AuthorityHealth.RECOVERY_REQUIRED, revision, catalog_digest, ())
            if self._pending_transition(revision + 1) is not None:
                return ExtensionControlAuthorityView(
                    AuthorityHealth.RECOVERY_REQUIRED,
                    revision,
                    catalog_digest,
                    (),
                )
            if anchor.phase is not AuthorityPhase.COMMITTED:
                return ExtensionControlAuthorityView(AuthorityHealth.RECOVERY_REQUIRED, revision, catalog_digest, ())
            self._validate_transition_chain(
                revision,
                current_snapshot_digest=_row_str(row, "snapshot_digest"),
                key=key,
            )
            self._ensure_catalog_migrated_event(
                revision=revision,
                catalog_digest=catalog_digest,
                layers=layers,
            )
            return ExtensionControlAuthorityView(AuthorityHealth.PROTECTED, revision, catalog_digest, layers)
        except ExtensionControlAuthorityError:
            return self._tampered_view(catalog_digest)

    @staticmethod
    def _catalog_target_manifest(registry: CommandSafetyExtensionRegistry) -> dict[str, str]:
        from .store_extension_control_manifest import catalog_target_manifest

        return catalog_target_manifest(registry)

    def _sync_trusted_catalog_manifest(
        self,
        view: ExtensionControlAuthorityView,
        registry: CommandSafetyExtensionRegistry,
        *,
        key: bytes,
    ) -> tuple[ExtensionControlAuthorityView, dict[str, str] | None]:
        from .store import GuardStore
        from .store_managed_control_manifest_context import (
            active_managed_manifest_context,
            managed_manifest_revision_required,
        )

        current = self._catalog_target_manifest(registry)
        store = cast(GuardStore, self)
        context = active_managed_manifest_context(store, key=key)
        with self._connect() as connection:
            existing = connection.execute(
                "select 1 from extension_control_catalog_manifest where catalog_digest = ?",
                (registry.catalog_digest,),
            ).fetchone()
        if existing is None:
            if (
                context is not None
                and any(control.state is ControlState.ENABLED for layer in context.layers for control in layer.controls)
                and managed_manifest_revision_required(
                    store,
                    context,
                    catalog_digest=registry.catalog_digest,
                    current_manifest=current,
                    revision=view.revision,
                    key=key,
                )
            ):
                view = self._migrate_extension_control_catalog(view, registry=registry, key=key)
            self._write_catalog_manifest(registry, key=key, manifest=current)
            return view, None
        persisted = self._load_catalog_manifest(registry.catalog_digest, key=key)
        if persisted is None:
            raise ExtensionControlAuthorityError("extension control catalog manifest conflict")
        if persisted == current:
            return view, None
        # Same catalog digest can still carry a newer trusted contract fingerprint
        # after a package update. Rebind local controls when needed, then let the
        # caller replace the stored manifest after managed layers are composed.
        rebound = tuple(
            replace(
                layer,
                catalog_digest=view.catalog_digest,
                controls=tuple(
                    control
                    for control in layer.controls
                    if preserve_migrated_extension_control(
                        control,
                        previous_manifest=persisted,
                        current_manifest=current,
                    )
                ),
            )
            for layer in view.layers
        )
        managed_revision_needed = False
        if context is not None and any(
            control.state is ControlState.ENABLED
            and persisted.get(f"{control.target.kind.value}:{control.target.target_id}")
            != current.get(f"{control.target.kind.value}:{control.target.target_id}")
            for layer in context.layers
            for control in layer.controls
        ):
            managed_revision_needed = managed_manifest_revision_required(
                store,
                context,
                catalog_digest=registry.catalog_digest,
                current_manifest=current,
                revision=view.revision,
                key=key,
            )
        if rebound != view.layers or managed_revision_needed:
            view = self._migrate_extension_control_catalog(view, registry=registry, key=key)
        return view, persisted

    def _write_catalog_manifest(
        self,
        registry: CommandSafetyExtensionRegistry,
        *,
        key: bytes,
        manifest: dict[str, str],
        replace: bool = False,
    ) -> None:
        manifest_json = json.dumps(manifest, sort_keys=True, separators=(",", ":"))
        recorded_at = _now()
        record_json, record_digest, record_mac = authenticated_record(
            {
                "catalog_digest": registry.catalog_digest,
                "manifest_json": manifest_json,
                "recorded_at": recorded_at,
            },
            key=key,
            purpose=self._catalog_manifest_purpose,
        )
        self._invalidate_native_extension_control_policy()
        with self._connect() as connection:
            if replace:
                connection.execute(
                    """
                    update extension_control_catalog_manifest
                    set manifest_json = ?, record_json = ?, record_digest = ?, record_mac = ?, recorded_at = ?
                    where catalog_digest = ?
                    """,
                    (
                        manifest_json,
                        record_json,
                        record_digest,
                        record_mac,
                        recorded_at,
                        registry.catalog_digest,
                    ),
                )
                if connection.execute("select changes()").fetchone()[0] != 1:
                    raise ExtensionControlAuthorityError("extension control catalog manifest conflict")
                return
            connection.execute(
                """
                insert into extension_control_catalog_manifest (
                    catalog_digest, manifest_json, record_json, record_digest, record_mac, recorded_at
                ) values (?, ?, ?, ?, ?, ?)
                """,
                (registry.catalog_digest, manifest_json, record_json, record_digest, record_mac, recorded_at),
            )

    def _load_catalog_manifest(self, catalog_digest: str, *, key: bytes) -> dict[str, str] | None:
        with self._connect() as connection:
            row = connection.execute(
                "select * from extension_control_catalog_manifest where catalog_digest = ?",
                (catalog_digest,),
            ).fetchone()
        if row is None:
            return None
        payload = verify_authenticated_record(
            str(row["record_json"]),
            expected_digest=str(row["record_digest"]),
            expected_mac=str(row["record_mac"]),
            key=key,
            purpose=self._catalog_manifest_purpose,
        )
        expected = {
            "catalog_digest": catalog_digest,
            "manifest_json": str(row["manifest_json"]),
            "recorded_at": str(row["recorded_at"]),
        }
        if any(payload.get(name) != expected_value for name, expected_value in expected.items()):
            raise ExtensionControlAuthorityError("extension control catalog manifest field mismatch")
        value = json.loads(str(row["manifest_json"]))
        if not isinstance(value, dict) or any(
            not isinstance(k, str) or not isinstance(v, str) for k, v in value.items()
        ):
            raise ExtensionControlAuthorityError("invalid extension control catalog manifest")
        return value

    def _ensure_catalog_migrated_event(
        self,
        *,
        revision: int,
        catalog_digest: str,
        layers: tuple[ExtensionControlLayer, ...],
    ) -> None:
        if revision < 1:
            return
        with self._connect() as connection:
            current = connection.execute(
                "select previous_revision, catalog_digest, layers_json from extension_control_authority_transition "
                "where revision = ?",
                (revision,),
            ).fetchone()
            if current is None or _row_str(current, "catalog_digest") != catalog_digest:
                return
            previous_revision = _row_int(current, "previous_revision")
            previous = connection.execute(
                "select catalog_digest, layers_json from extension_control_authority_transition where revision = ?",
                (previous_revision,),
            ).fetchone()
            if previous is None:
                return
            previous_catalog_digest = _row_str(previous, "catalog_digest")
            if previous_catalog_digest == catalog_digest:
                return
            previous_target_ids = {
                control.target.target_id
                for layer in layers_from_json(_row_str(previous, "layers_json"))
                for control in layer.controls
            }
        current_target_ids = {control.target.target_id for layer in layers for control in layer.controls}
        self._record_catalog_migrated_event_once(
            previous_revision=previous_revision,
            revision=revision,
            previous_catalog_digest=previous_catalog_digest,
            catalog_digest=catalog_digest,
            layers=layers,
            retired_targets=tuple(sorted(previous_target_ids - current_target_ids)),
        )

    def _record_catalog_migrated_event_once(
        self,
        *,
        previous_revision: int,
        revision: int,
        previous_catalog_digest: str,
        catalog_digest: str,
        layers: tuple[ExtensionControlLayer, ...],
        retired_targets: tuple[str, ...],
    ) -> None:
        payload = json.dumps(
            {
                "previous_revision": previous_revision,
                "revision": revision,
                "previous_catalog_digest": previous_catalog_digest,
                "catalog_digest": catalog_digest,
                "layer_count": len(layers),
                "control_count": sum(len(layer.controls) for layer in layers),
                "retired_target_count": len(retired_targets),
                "retired_target_ids": list(retired_targets),
            },
            sort_keys=True,
            separators=(",", ":"),
        )
        with self._connect() as connection:
            existing = connection.execute(
                "select payload_json from guard_events where event_name = ?",
                ("extension_control_authority_catalog_migrated",),
            ).fetchall()
            for row in existing:
                try:
                    recorded = json.loads(str(row["payload_json"]))
                except json.JSONDecodeError:
                    continue
                if isinstance(recorded, dict) and recorded.get("revision") == revision:
                    return
            connection.execute(
                "insert into guard_events (event_name, payload_json, occurred_at) values (?, ?, ?)",
                ("extension_control_authority_catalog_migrated", payload, _now()),
            )

    def _migrate_extension_control_catalog(
        self,
        previous: ExtensionControlAuthorityView,
        *,
        registry: CommandSafetyExtensionRegistry,
        key: bytes,
    ) -> ExtensionControlAuthorityView:
        """Rebind authenticated controls to a trusted built-in catalog update."""

        self._invalidate_native_extension_control_policy()
        catalog_digest = registry.catalog_digest
        previous_manifest = self._load_catalog_manifest(previous.catalog_digest, key=key) or {}
        current_manifest = self._catalog_target_manifest(registry)
        previous = replace(previous, layers=expand_legacy_dns_layers(previous.layers))

        def keep(control: ExtensionControl) -> bool:
            return preserve_migrated_extension_control(
                control, previous_manifest=previous_manifest, current_manifest=current_manifest
            )

        retired_targets = tuple(
            sorted(
                control.target.target_id for layer in previous.layers for control in layer.controls if not keep(control)
            )
        )
        layers = tuple(
            replace(
                layer,
                catalog_digest=catalog_digest,
                controls=tuple(control for control in layer.controls if keep(control)),
            )
            for layer in previous.layers
        )
        self._validate_layers(layers, catalog_digest)
        layers_json = layers_to_json(layers)
        self._validate_serialized_layers(layers_json)
        with self._connect() as connection:
            snapshot = connection.execute(
                "select snapshot_digest, catalog_digest from extension_control_authority_snapshot where singleton = 1"
            ).fetchone()
        if snapshot is None or str(snapshot["catalog_digest"]) != previous.catalog_digest:
            raise ExtensionControlAuthorityError("extension control catalog migration source changed")
        previous_digest = str(snapshot["snapshot_digest"])
        revision = previous.revision + 1
        created_at = _now()
        migration_ref = f"catalog-migration:{previous.catalog_digest}:{catalog_digest}:{previous.revision}"
        actor_hash = _private_hash("trusted-catalog-migration", key=key, purpose="actor")
        idempotency_hash = _private_hash(migration_ref, key=key, purpose="idempotency")
        nonce_hash = _private_hash(migration_ref, key=key, purpose="nonce")
        snapshot_json, snapshot_digest, snapshot_mac = authenticated_record(
            {
                "revision": revision,
                "catalog_digest": catalog_digest,
                "layers_json": layers_json,
                "previous_digest": previous_digest,
                "committed_at": created_at,
            },
            key=key,
            purpose=SNAPSHOT_PURPOSE,
        )
        transition_json, transition_digest, transition_mac = authenticated_record(
            {
                "revision": revision,
                "previous_revision": previous.revision,
                "previous_digest": previous_digest,
                "snapshot_digest": snapshot_digest,
                "catalog_digest": catalog_digest,
                "actor_id_hash": actor_hash,
                "idempotency_key_hash": idempotency_hash,
                "nonce_hash": nonce_hash,
                "created_at": created_at,
                "phase": AuthorityPhase.PREPARED.value,
            },
            key=key,
            purpose=TRANSITION_PURPOSE,
        )
        with self._connect() as connection:
            connection.execute(
                """
                insert into extension_control_authority_transition (
                    revision, previous_revision, phase, actor_id_hash, idempotency_key_hash,
                    nonce_hash, catalog_digest, layers_json, snapshot_json, snapshot_digest,
                    snapshot_mac, transition_json, transition_digest, transition_mac, created_at
                ) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    revision,
                    previous.revision,
                    AuthorityPhase.PREPARED.value,
                    actor_hash,
                    idempotency_hash,
                    nonce_hash,
                    catalog_digest,
                    layers_json,
                    snapshot_json,
                    snapshot_digest,
                    snapshot_mac,
                    transition_json,
                    transition_digest,
                    transition_mac,
                    created_at,
                ),
            )
        self._write_and_verify_anchor(AuthorityAnchor(revision, snapshot_digest, AuthorityPhase.ANCHORED), key=key)
        with self._connect() as connection:
            connection.execute(
                "update extension_control_authority_transition set phase = ? where revision = ?",
                (AuthorityPhase.ANCHORED.value, revision),
            )
            connection.execute(
                """
                update extension_control_authority_snapshot
                set revision = ?, catalog_digest = ?, layers_json = ?, previous_digest = ?,
                    snapshot_json = ?, snapshot_digest = ?, snapshot_mac = ?, committed_at = ?
                where singleton = 1 and revision = ? and snapshot_digest = ?
                """,
                (
                    revision,
                    catalog_digest,
                    layers_json,
                    previous_digest,
                    snapshot_json,
                    snapshot_digest,
                    snapshot_mac,
                    created_at,
                    previous.revision,
                    previous_digest,
                ),
            )
            if connection.execute("select changes()").fetchone()[0] != 1:
                raise ExtensionControlAuthorityError("extension control catalog migration conflict")
            connection.execute(
                "update extension_control_authority_transition set phase = ?, committed_at = ? where revision = ?",
                (AuthorityPhase.COMMITTED.value, created_at, revision),
            )
            connection.execute(
                "insert into guard_events (event_name, payload_json, occurred_at) values (?, ?, ?)",
                (
                    "extension_control_authority_catalog_migrated",
                    json.dumps(
                        {
                            "previous_revision": previous.revision,
                            "revision": revision,
                            "previous_catalog_digest": previous.catalog_digest,
                            "catalog_digest": catalog_digest,
                            "layer_count": len(layers),
                            "control_count": sum(len(layer.controls) for layer in layers),
                            "retired_target_count": len(retired_targets),
                            "retired_target_ids": retired_targets,
                        },
                        sort_keys=True,
                        separators=(",", ":"),
                    ),
                    created_at,
                ),
            )
        self._write_and_verify_anchor(AuthorityAnchor(revision, snapshot_digest, AuthorityPhase.COMMITTED), key=key)
        return self._read_extension_control_authority_locked(catalog_digest)

    def _bootstrap_extension_control_authority(
        self, catalog_digest: str, *, key: bytes | None
    ) -> ExtensionControlAuthorityView:
        self._invalidate_native_extension_control_policy()
        if key is None:
            key = secrets.token_bytes(32)
            self._secret_store().set_secret(self._key_ref(), base64.urlsafe_b64encode(key).decode())
        committed_at = _now()
        layers_json = layers_to_json(())
        snapshot_json, digest, mac = authenticated_record(
            {
                "revision": 0,
                "catalog_digest": catalog_digest,
                "layers_json": layers_json,
                "previous_digest": None,
                "committed_at": committed_at,
            },
            key=key,
            purpose=SNAPSHOT_PURPOSE,
        )
        with self._connect() as connection:
            existing = connection.execute(
                "select 1 from extension_control_authority_snapshot where singleton = 1"
            ).fetchone()
            if existing is not None:
                raise ExtensionControlAuthorityError("extension control authority already exists")
            connection.execute(
                """
                insert into extension_control_authority_snapshot (
                    singleton, revision, catalog_digest, layers_json, previous_digest,
                    snapshot_json, snapshot_digest, snapshot_mac, committed_at
                ) values (1, 0, ?, ?, null, ?, ?, ?, ?)
                """,
                (catalog_digest, layers_json, snapshot_json, digest, mac, committed_at),
            )
        self._write_and_verify_anchor(AuthorityAnchor(0, digest, AuthorityPhase.COMMITTED), key=key)
        return ExtensionControlAuthorityView(AuthorityHealth.PROTECTED, 0, catalog_digest, ())
