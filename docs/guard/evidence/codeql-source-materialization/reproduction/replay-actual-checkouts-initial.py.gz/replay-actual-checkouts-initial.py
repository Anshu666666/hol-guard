"""Replay checkout/staging commands against actual pinned repository snapshots."""
import base64
import gzip
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path('/workspace/scratch/c25672eb4c10/codeql-materialization-fix')
OUT = Path('/workspace/scratch/c25672eb4c10/codeql-materialization-evidence/actual-checkouts')
OUT.mkdir(exist_ok=False)
PYTHON = '/workspace/scratch/c25672eb4c10/validation-venv/bin/python'
BASE = '7a387128e2cf2ec79b890dfebe2697e8a49eb45d'
CANDIDATE = subprocess.check_output(['git','rev-parse','HEAD'], cwd=ROOT).decode().strip()
spec = importlib.util.spec_from_file_location('repaired_diagnostic', ROOT/'scripts/ci/codeql_foundation_diagnostic.py')
module = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = module
spec.loader.exec_module(module)
records=[]
git_version = subprocess.check_output(['git','--version']).decode().strip()

for sparse in (True, False):
    for profile_name in ('foundation-cdd','implementation-d8'):
        label = ('original-sparse' if sparse else 'repaired-full')+'-'+profile_name
        case = OUT/label
        case.mkdir()
        source=case/'source'
        staging=case/'staged'
        env_file=case/'environment'
        commands=[]
        def run(args, *, cwd=None, env=None, accepted=(0,)):
            start=time.monotonic()
            result=subprocess.run(args, cwd=cwd, env=env, capture_output=True, timeout=120)
            logname=f'{len(commands):02d}.json'
            raw=json.dumps({'argv':args,'cwd':str(cwd) if cwd else None,'exit_code':result.returncode,'stdout_base64':base64.b64encode(result.stdout).decode(),'stderr_base64':base64.b64encode(result.stderr).decode()},indent=2).encode()+b'\n'
            (case/logname).write_bytes(raw)
            commands.append({'path':logname,'sha256':hashlib.sha256(raw).hexdigest(),'exit_code':result.returncode,'wall_seconds':round(time.monotonic()-start,6)})
            assert result.returncode in accepted, (label,args,result.stderr[-1500:])
            return result
        run(['git','clone','--shared','--no-checkout',str(ROOT),str(source)])
        definition_sha=BASE if sparse else CANDIDATE
        run(['git','checkout','--force',definition_sha],cwd=source)
        if sparse:
            run(['git','config','core.sparseCheckout','true'],cwd=source)
            run(['git','sparse-checkout','set','--no-cone','/.github/workflows/codeql-foundation-diagnostic.yml','/scripts/ci/codeql_foundation_diagnostic.py'],cwd=source)
        run([PYTHON,'-I','scripts/ci/codeql_foundation_diagnostic.py','stage','--source-root','.','--staging-root',str(staging),'--environment-file',str(env_file)],cwd=source)
        env=dict(os.environ,GITHUB_WORKSPACE=str(source))
        env.update(dict(line.split('=',1) for line in env_file.read_text().splitlines()))
        if sparse:
            run(['git','sparse-checkout','disable'],cwd=source)
            run(['git','config','--unset-all','extensions.worktreeConfig'],cwd=source)
        profile=module.PROFILES[profile_name]
        run(['git','checkout','--force',profile.commit],cwd=source)
        identity=module.source_identity(source,profile_name)
        tracked=run(['git','ls-files','-z'],cwd=source).stdout.split(b'\0')
        prefix_counts={}
        for prefix in (b'src/',b'rust/',b'.github/workflows/'):
            paths=[path for path in tracked if path.startswith(prefix)]
            prefix_counts[prefix.decode()]={'tracked':len(paths),'materialized':sum(os.path.lexists(source/os.fsdecode(path)) for path in paths)}
        verification=run([PYTHON,'-I',str(staging/'codeql_foundation_diagnostic.py'),'verify','--profile',profile_name,'--source-root','.','--enforce-layout'],cwd=source,env=env)
        assert identity['commit']==profile.commit and identity['tree']==profile.tree and identity['tracked_clean']
        assert identity['matches_pin'] is (not sparse)
        assert all(value['materialized']==(0 if sparse else value['tracked']) for value in prefix_counts.values())
        proof={'label':label,'definition_commit':definition_sha,'profile':profile_name,'git_version':git_version,'source_identity_with_repaired_collector':identity,'prefix_counts':prefix_counts,'staged_collector_sha256':hashlib.sha256((staging/'codeql_foundation_diagnostic.py').read_bytes()).hexdigest(),'staged_verify_exit_code':verification.returncode,'commands':commands,'codeql_executed':False,'qualification_complete':False}
        raw=json.dumps(proof,indent=2).encode()+b'\n'
        (case/'proof.json').write_bytes(raw)
        records.append(proof)
        print(json.dumps({k:proof[k] for k in ('label','prefix_counts','source_identity_with_repaired_collector')}),flush=True)
(OUT/'summary.json').write_text(json.dumps({'base':BASE,'candidate':CANDIDATE,'git_version':git_version,'cases':records,'qualification_complete':False},indent=2)+'\n')
