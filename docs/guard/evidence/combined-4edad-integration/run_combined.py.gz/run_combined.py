"""Finite gates on one clean integration; raw results stay outside its tree."""

from pathlib import Path
import datetime
import hashlib
import importlib.metadata
import json
import os
import subprocess
import sys
import time


ROOT = Path('/workspace/scratch/c25672eb4c10/release-clean-integration')
OUT = Path(__file__).parent
HEAD = '4edad2ca1dc075c69cbec7c3b59d1a59fc4d3505'
PYTHON = '/workspace/scratch/c25672eb4c10/validation-venv/bin/python'


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True)


def snapshot():
    assert git('rev-parse', 'HEAD').strip() == HEAD
    assert not git('status', '--porcelain=v1', '--untracked-files=all')
    paths = git('ls-files', '-z').split('\0')
    rows = []
    for name in sorted(path for path in paths if path):
        path = ROOT / name
        data = path.read_bytes() if not path.is_symlink() else os.readlink(path).encode()
        rows.append({'path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(),
                     'symlink': path.is_symlink()})
    encoded = json.dumps(rows, sort_keys=True, separators=(',', ':')).encode()
    return rows, hashlib.sha256(encoded).hexdigest()


before, aggregate = snapshot()
(OUT / 'source-before.json').write_text(json.dumps({'head': HEAD, 'aggregate_sha256': aggregate, 'files': before}, indent=2) + '\n')
report = {'head': HEAD, 'cwd': str(ROOT), 'python': sys.version, 'python_executable': sys.executable,
          'python_resolved': str(Path(sys.executable).resolve()),
          'versions': {name: importlib.metadata.version(name) for name in ['pytest', 'ruff', 'basedpyright']},
          'shared_lock': '/workspace/scratch/c25672eb4c10/validation.lock',
          'source_before_aggregate_sha256': aggregate,
          'runner_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
          'pytest_scope_reason': 'Exercise newly combined readiness/publisher/surface diagnostics and daemon project-context forwarding, with six focused real-stdio MCP authority regressions sharing the merged production imports; no historical performance workers.',
          'runs': []}


def checkpoint():
    (OUT / 'validation.json').write_text(json.dumps(report, indent=2) + '\n')


def run(label, command):
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    start = time.monotonic()
    with (OUT / (label + '.stdout')).open('wb') as stdout, (OUT / (label + '.stderr')).open('wb') as stderr:
        result = subprocess.run(command, cwd=ROOT, env={**os.environ, 'PYTHONPATH': 'src'},
                                stdout=stdout, stderr=stderr, check=False)
    after, source_hash = snapshot()
    item = {'label': label, 'command': command, 'started_utc': started,
            'completed_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'exit_code': result.returncode, 'elapsed_seconds': time.monotonic() - start,
            'source_after_aggregate_sha256': source_hash, 'tracked_files_unchanged': after == before}
    report['runs'].append(item)
    checkpoint()
    print(json.dumps(item), flush=True)
    assert after == before


checkpoint()
for label, module, args in [
    ('native-authority', 'scripts/ci/rust_authority_ownership_gate.py', ['--base-ref', 'aa300e4c']),
    ('python-semantic', 'scripts/ci/python_hook_semantic_callgraph_gate.py', []),
    ('io-ownership', 'scripts/ci/rust_io_ownership_gate.py', []),
    ('privacy', 'scripts/ci/rust_io_privacy_gate.py', []),
]:
    run(label, [PYTHON, module, '--root', '.', '--json', str(OUT / (label + '.json')), *args])
run('ruff-full-src', [PYTHON, '-m', 'ruff', 'check', 'src'])
run('format-full-src', [PYTHON, '-m', 'ruff', 'format', '--check', 'src'])
run('types-full-src', [PYTHON, '-m', 'basedpyright', '--pythonversion', '3.12', '--pythonpath', PYTHON, '--outputjson', 'src'])
run('focused-merged-paths', [PYTHON, '-m', 'pytest', '-q',
    'tests/test_bounded_cli_hook_context.py', 'tests/test_bounded_cli_hook_copilot_delivery.py',
    'tests/test_native_slo_launcher_input.py', 'tests/test_native_slo_publisher_diagnostic.py',
    'tests/test_native_slo_surface_failure.py', 'tests/test_native_slo_registered_surfaces.py',
    'tests/test_native_slo_corpus_run.py', 'tests/test_native_slo_faults.py',
    'tests/test_installed_native_ollama_probe.py', 'tests/test_mcp_package_drain_authority_review.py',
    'tests/test_runtime_mcp_authority_callbacks.py::test_local_grant_mutation_cannot_reach_later_saved_lookup_or_child',
    'tests/test_runtime_mcp_authority_callbacks.py::test_private_composer_check_cannot_replace_active_proxy_authority',
    'tests/test_runtime_mcp_authority_callbacks.py::test_authority_mutation_after_completed_write_does_not_veto_success',
    '--basetemp=' + str(OUT / 'pytest-fixtures')])
after, final_hash = snapshot()
(OUT / 'source-after.json').write_text(json.dumps({'head': HEAD, 'aggregate_sha256': final_hash, 'files': after}, indent=2) + '\n')
report['complete'] = True
report['all_commands_passed'] = all(item['exit_code'] == 0 for item in report['runs'])
report['source_after_aggregate_sha256'] = final_hash
report['all_tracked_files_unchanged'] = after == before
checkpoint()
raise SystemExit(0 if report['all_commands_passed'] else 1)
