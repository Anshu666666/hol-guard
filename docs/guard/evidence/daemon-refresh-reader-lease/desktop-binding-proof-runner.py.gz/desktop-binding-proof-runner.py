from pathlib import Path
import datetime
import hashlib
import json
import subprocess

from tests import guard_command_decision_diff as diff

root = Path('/workspace/scratch/c25672eb4c10/refresh-lease-fix')
out = root / 'docs/guard/evidence/daemon-refresh-reader-lease'
assert diff.REPO_ROOT == root
fixture_before = diff.REPORT_PATH.read_bytes()
fixture = json.loads(fixture_before)
expected = fixture['bindings']['sources_sha256']
actual = diff._source_bindings()
paths = sorted({path.resolve() for path in diff._EVIDENCE_SOURCE_PATHS})
server = root/'src/codex_plugin_scanner/guard/daemon/server.py'
assert server not in paths
assert actual == expected
assert len(actual) == len(paths) == 395
inventory = []
for path in paths:
    relative = str(path.relative_to(root))
    binding = diff.source_binding_id(relative)
    sha = hashlib.sha256(path.read_bytes()).hexdigest()
    assert expected[binding] == actual[binding] == sha
    inventory.append({'path': relative, 'binding_id': binding, 'current_sha256': sha,
                      'fixture_sha256': expected[binding], 'matches': True})
fixture_after = diff.REPORT_PATH.read_bytes()
assert fixture_before == fixture_after
receipt = {'schema': 'guard.daemon-refresh-reader-lease.desktop-bindings.v1',
           'checked_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
           'commit': subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),
           'root': str(root),
           'binding_count': len(actual), 'all_current_bindings_match_fixture': actual == expected,
           'server_path': str(server.relative_to(root)),
           'server_is_bound': server in paths,
           'server_sha256': hashlib.sha256(server.read_bytes()).hexdigest(),
           'fixture_path': str(diff.REPORT_PATH.relative_to(root)),
           'fixture_sha256_before': hashlib.sha256(fixture_before).hexdigest(),
           'fixture_sha256_after': hashlib.sha256(fixture_after).hexdigest(),
           'fixture_unchanged': fixture_before == fixture_after,
           'generator_path': str(Path(diff.__file__).relative_to(root)),
           'generator_sha256': hashlib.sha256(Path(diff.__file__).read_bytes()).hexdigest(),
           'report_generation_invoked': False, 'fixture_regeneration_required': False,
           'inventory': inventory}
(out/'desktop-binding-proof.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({k: v for k,v in receipt.items() if k != 'inventory'},indent=2))
