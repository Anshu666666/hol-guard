from pathlib import Path
import datetime
import gzip
import hashlib
import json
import os
import subprocess
import sys
import time

root = Path('/workspace/scratch/c25672eb4c10/refresh-lease-fix')
out = root / 'docs/guard/evidence/daemon-refresh-reader-lease'
stage, *command = sys.argv[1:]
paths = ['src/codex_plugin_scanner/guard/daemon/server.py',
         'tests/test_guard_daemon_refresh_reader_lease.py',
         'tests/test_guard_extension_control_runtime.py']
def identities():
    return {p: hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths}
before = identities()
env = dict(os.environ, PYTHONPATH=str(root/'src'), TMPDIR='/tmp')
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
t0 = time.monotonic()
result = subprocess.run(command,cwd=root,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,check=False)
elapsed = time.monotonic()-t0
after = identities()
raw = result.stdout
blob = gzip.compress(raw,mtime=0)
name = stage+'.log.gz'
(out/name).write_bytes(blob)
receipt = {'schema':'guard.daemon-refresh-reader-lease.validation.v1', 'stage':stage,
           'command':command,'cwd':str(root),'env_overrides':{'PYTHONPATH':str(root/'src'),'TMPDIR':'/tmp'},
           'started_at':started,'elapsed_seconds_including_lock':elapsed,'exit_code':result.returncode,
           'source_before':before,'source_after':after,'source_unchanged':before==after,
           'output':{'path':name,'bytes':len(blob),'sha256':hashlib.sha256(blob).hexdigest(),
                     'decoded_bytes':len(raw),'decoded_sha256':hashlib.sha256(raw).hexdigest()}}
(out/(stage+'.json')).write_text(json.dumps(receipt,indent=2)+'\n')
print(raw.decode('utf-8',errors='replace'))
print(json.dumps({'stage':stage,'exit_code':result.returncode,'elapsed':elapsed,'source_unchanged':before==after}))
if before != after:
    raise SystemExit('source changed while command was executing')
raise SystemExit(result.returncode)
