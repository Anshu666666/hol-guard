"""Capture sanitized local failure details without changing fixture behavior."""

from __future__ import annotations

import json
import os
from pathlib import Path

_original_failure = None
_approval = None
_failures = []


def _failure(error):
    assert _original_failure is not None
    evidence = _original_failure(error)
    _failures.append(
        {
            **evidence,
            "sqlite_errorcode": getattr(error, "sqlite_errorcode", None),
            "sqlite_errorname": getattr(error, "sqlite_errorname", None),
        }
    )
    return evidence


def pytest_runtest_setup(item):
    global _approval, _original_failure
    if _approval is None:
        from scripts import native_slo_launcher_approval as approval

        _approval = approval
        _original_failure = approval.failure_evidence
        approval.failure_evidence = _failure


def pytest_sessionfinish(session, exitstatus):
    if _approval is not None:
        _approval.failure_evidence = _original_failure
    Path(os.environ["CI75_FAILURE_CAPTURE"]).write_text(
        json.dumps({"pytest_exit_status": int(exitstatus), "sanitized_failures": _failures}, indent=2) + "\n"
    )
