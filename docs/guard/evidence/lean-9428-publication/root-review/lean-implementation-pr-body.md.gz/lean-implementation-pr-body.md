This implements the Rust performance PRD on `release/3.2`: native command execution and control authority, scoped policy inputs, native Codex continuation, and measured runtime improvements while preserving Python-owned review semantics. Foundation reconciliation remains in #2951.

Current published commit: `9428b660fa6a261307627660ff7b258327ed9bd4`, tree `051e3c6e2b40a19ff1d97b93d183279af7ccb36e`. This checkpoint builds on the signed `c9ed06bb` cleanup. All 1,306 removed evidence files remain absent from the release branch; complete validation records live on the [separate evidence branch](https://github.com/hashgraph-online/hol-guard/tree/e6d046acf602672e6daccdc8ca648dee92b19e02). This PR remains draft.

## Current repairs

- Bind the complete MCP request and selected policy authority through saved lookups, approval callbacks, package revalidation and the final writer. Mutations stop before subsequent authorization or forwarding. Public aliases, the original three preparation calls, verified package rewriting, completed-write receipts and the 5 ms fence remain intact.
- Forward validated project home/workspace arguments through the bounded CLI daemon path. The existing strict argument parser and receiver validators remain authoritative; unsupported grammar uses the existing CLI fallback. The frozen workload and global workspace behavior are unchanged.
- Provision the existing exact-byte private qualification interpreter on macOS as well as Linux, including the transition environment. Shared interpreters and trust validators remain unchanged.
- Retry only confirmed SQLite BUSY/LOCKED during the fixture's unfinished pending read, without entering storage recovery or changing its deadline. Add bounded receipt, policy-readiness, route-failure, DNS and legacy-producer diagnostics while preserving the original results and acceptance conditions.

Earlier daemon shared-refresh and explicit fixture-workspace corrections remain included. Risk categories still derive twice in the production default. The separately reviewed per-call prototype remains inactive; no E/F campaign has been resumed or pooled.

## Validation and source integrity

The [combined integration receipt](https://github.com/hashgraph-online/hol-guard/blob/e6d046acf602672e6daccdc8ca648dee92b19e02/docs/guard/evidence/combined-4edad-integration/README.md) binds executable source `4edad2ca1dc075c69cbec7c3b59d1a59fc4d3505`. Native-authority, Python semantic, I/O ownership and privacy gates pass, as do full production Ruff, formatting and typing. The focused merged tests pass 231 cases with one expected real-Win32 skip. Production typing covers 1,258 files with zero errors and 20,272 retained warnings. All 4,354 tracked hashes remain identical after every validation command. Every tracked input remained unchanged during those checks. Later documentation and scan-control changes are recorded separately.

The MCP repair has 150 passing callback/approval cases, 414 passing broader integration cases and 40 passing new regressions. Independent actual-stdio review retains the initial package handoff failures and the identical corrected three-case pass. These populations overlap and are not summed.

The actual Desktop generator and its 16 tests pass: all 51,000 non-source corpus results remain identical, and all 395 source bindings match. Only the MCP grant source binding changed. The later project adapter changes are outside that inventory. The project forwarding repair also passes 198 bounded CLI tests and independent source review. Local checks establish their stated scopes; installed qualification requires this actual head's artifacts.

Before this branch update, pinned Gitleaks 8.24.2 scanned the full original release-base-to-actual-commit range (`4b89e0d2..9428b660`) using the exact prepared GitHub tree: **zero findings**. The cleanup had removed 96 historical digest fingerprints. This checkpoint restores only those exact previous fingerprints after the [per-finding audit](https://github.com/hashgraph-online/hol-guard/blob/e6d046acf602672e6daccdc8ca648dee92b19e02/docs/guard/evidence/c9-gitleaks-digest-audit/README.md), while preserving all existing cleanup-head entries and their order. The audit independently recomputes 82 source digests; the other 14 are recorded launcher digests with retained probe/report provenance and no fresh historical binary rehash. The [restoration and independent review](https://github.com/hashgraph-online/hol-guard/blob/e779bc22a97d763b3edf4f6a246b7303e84b658d/docs/guard/evidence/c9-review-and-restoration-receipts/README.md) retain those limitations. The actual scan uses the explicitly changed ignore digest `fb66f1abc0bfd3a366c666cba39f9b2cdfc577ae3d29dd96c59b2f5f03f1c16e`; scanner settings and both other cleanup controls remain unchanged. No broader pattern or CodeQL alert disposition is added.

## Latest completed hosted observations

The [complete `c9ed06bb` cohort](https://github.com/hashgraph-online/hol-guard/blob/e779bc22a97d763b3edf4f6a246b7303e84b658d/docs/guard/evidence/cleanup-c9ed06b-hosted-final/TERMINAL.md) predates these repairs: 37 workflows, 34 successful and three failed. Main CI passes; its Sonar report passes with zero new issues or hotspots, 83.0% new-code coverage and 0.0% duplication. Linux, Windows and macOS arm native-wheel jobs pass; macOS Intel fails the recovery-latency smoke check at 1,080.857 ms. All four paired qualification jobs fail. The CodeQL security check retains 11 high alerts. Those observations remain attached to their original source.

All four default-auto reports have 21 resident decisions and zero receipt failures at c9ed; earlier Windows failures remain retained. The paired Windows run still has an unclassified publisher readiness failure and a separate candidate configuration-source failure with no preserved underlying exception. Both Macs retain frozen-baseline `getfqdn` deadlines and candidate interpreter rejection. Linux completes its paired smoke blocks but retains mixed-writer, control and resource failures. None supplies the original full performance qualification.

The [source69 archive](https://github.com/hashgraph-online/hol-guard/tree/aeb04b6b06bd15ae2a2ecf00e8671c7501239278/docs/guard/rust-performance) retains the complete earlier 590 cohort, original failures and preservation audit. Historical snapshot CodeQL diagnostics contain 25/29 raw findings on immutable cdd/d8 sources; they neither identify the PR's current alerts nor clear a security gate.

## Contract and remaining acceptance

All 144 original task objects, acceptance/dependency/status fields, the complete RSP-106 record and the preceding 119 catalog objects remain preserved. The inherited counts are 74 DONE, 31 OPEN, 29 BLOCKED and 10 DEFERRED. The [archive locator](https://github.com/hashgraph-online/hol-guard/blob/9428b660fa6a261307627660ff7b258327ed9bd4/docs/guard/rust-performance/EVIDENCE_ARCHIVE.md) resolves historical evidence without restoring dumps to the release branch.

Complete the original route/platform samples, latency/CPU/memory targets, receipt/control/recovery evidence, selected-benefit gates, signing and tested original-baseline retirement/rollback. The actual new head still requires its own security/Sonar checks, fresh Greptile 5/5, resolved review threads and independent last-push CODEOWNER approval. Source validation does not establish qualification, activation, merge or rollout.

- [Original PRD](https://github.com/hashgraph-online/hol-guard/blob/9428b660fa6a261307627660ff7b258327ed9bd4/docs/guard/rust-performance/PRD.md)
- [Original TODO](https://github.com/hashgraph-online/hol-guard/blob/9428b660fa6a261307627660ff7b258327ed9bd4/docs/guard/rust-performance/TODO.md)
- [Current contract](https://github.com/hashgraph-online/hol-guard/blob/9428b660fa6a261307627660ff7b258327ed9bd4/docs/guard/rust-performance/CURRENT_CONTRACT.md)
- [Execution ledger](https://github.com/hashgraph-online/hol-guard/blob/9428b660fa6a261307627660ff7b258327ed9bd4/docs/guard/rust-performance/EXECUTION_LEDGER.md)
- [Takeaway](https://github.com/hashgraph-online/hol-guard/blob/9428b660fa6a261307627660ff7b258327ed9bd4/docs/guard/rust-performance/TAKEAWAY.md)
