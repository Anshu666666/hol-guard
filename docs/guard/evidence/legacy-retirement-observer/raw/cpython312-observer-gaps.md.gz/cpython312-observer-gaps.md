# CPython 3.12 process-observer boundaries

Read-only source investigation of the available CPython **3.12.14** standard library under `/opt/codex/runtimes/codex-primary-runtime/dependencies/python/lib/python3.12`. Windows source was inspected on Linux; Windows behavior was not executed. This research informs a diagnostic-only observer and does not supply qualification evidence.

## Launch coverage

`multiprocessing.process.BaseProcess.start` invokes `_Popen(self)` before assigning `_popen`, `_sentinel`, deleting target/arguments, or adding the process to `_children`. An exception during the constructor may therefore leave a created child absent from `active_children()` and without an attached `Process._popen`. Count entry before launch and preserve every incomplete attempt.

POSIX `popen_spawn_posix.Popen._launch` first asks `resource_tracker.getfd()`, which may create an additional interpreter. It then serializes preparation data and the process object, invokes `util.spawnv_passfds`, assigns the returned PID, and writes the serialized data to the child. Failure during that write occurs after a child exists. The constructor can fail without `BaseProcess.start` ever publishing `_popen`.

`util.spawnv_passfds` calls `_posixsubprocess.fork_exec` directly. On the available CPython 3.12.14, a harmless `python -I -c pass` launch followed by `waitpid` emitted **no audit event containing process/spawn/fork/exec**. A passive Python profiler saw `spawnv_passfds` entry, `c_call`/`c_return` for `fork_exec`, and the Python function return carrying the child PID. Therefore `subprocess.Popen`/`os.fork` audit events alone do not provide process coverage. Record the original function's entry/return and low-level C attempt; a C success followed by exceptional Python cleanup without an attributable PID is incomplete, not a zero-spawn result.

On Windows, `popen_spawn_win32.Popen.__init__` calls `_winapi.CreateProcess` before setting `self.pid` and `self._handle`, then serializes preparation/process data. The OS process exists before later Python steps can fail. The audit event is a prelaunch observation, not a PID or completion receipt. Profile the constructor and preserve the actual object/handle state at return or exception. A created PID with no trustworthy object state must fail diagnostic completeness.

The Windows spawn code may launch `sys._base_executable` instead of the virtual-environment `sys.executable`, setting `__PYVENV_LAUNCHER__` for the child. Attest the actual launched executable as well as the logical installation prefix; do not reject or mislabel this documented source path by assuming those executables are always identical.

## Child bootstrap

`spawn._main` unpickles preparation data, calls `prepare`, and only then unpickles the process object. `prepare` replaces `sys.path` and `sys.argv` with inherited values and reruns the entry script as `__mp_main__` before unpickling the target. Entry-level observer setup therefore covers subsequent target-module imports, provided registration occurs before the entry's application imports and uses the same inherited context.

It does not cover interpreter startup/site initialization, importing multiprocessing itself, or preparation-data unpickling. Those inputs form an explicit trusted, source-pinned boundary. `-I` flags are inherited through `util._args_from_interpreter_flags`; spawn subsequently restores the parent's prepared `sys.path`, so the observer must attest that intended path state as well.

The POSIX resource tracker runs `-c 'from multiprocessing.resource_tracker import main;main(fd)'`; it does **not** rerun the transition entry and cannot produce its per-child observer receipt. Record this separately as unobserved infrastructure with exact executable/command/source provenance, or leave completeness false. Do not count it as an observed producer child or silently exclude its creation. Resource-tracker relaunch is possible if an existing tracker fails its liveness probe.

## Exit and seal coverage

`BaseProcess._bootstrap` runs the target, then multiprocessing `_exit_function`, then `threading._shutdown`, and only then returns its exit code to `spawn_main`, which calls `sys.exit`. A target-return profile event occurs before child cleanup and cannot seal full interpreter completion.

`_bootstrap._after_fork` clears `multiprocessing.util._finalizer_registry` **after** entry-script replay. An observer registered using `multiprocessing.util.Finalize` at entry may therefore be discarded. Ordinary `atexit` registration is separate, but SIGKILL/TerminateProcess/os._exit bypass ordinary finalization. Such a child can have authentic start/events and confirmed OS exit while lacking a complete final observation seal; under the proposed conservative design that remains incomplete.

Multiprocessing `_exit_function` terminates daemonic children and joins active children. This can kill an evaluator before its own seal even when the guardian exits normally. A diagnostic must preserve that distinction rather than manufacturing a child seal on the parent's behalf.

POSIX `Popen.poll` obtains status from `waitpid`; Windows `Popen.wait` sets return code only after `WaitForSingleObject` reports signaled, followed by `GetExitCodeProcess`. Windows `terminate` explicitly avoids inferring exit from a non-STILL_ACTIVE exit code alone. Parent verification should bind exit to the owned child handle/sentinel and previously recorded identity, never PID absence or an unqualified boolean.

## Diagnostic test targets

- A POSIX `spawnv_passfds` launch is counted even with no process audit event.
- A resource-tracker launch is represented despite absence of transition-entry replay.
- Creation succeeds but constructor serialization or later cleanup raises: attempt remains incomplete and cannot disappear from totals.
- Guardian creates an evaluator; guardian/evaluator is killed before sealing: OS exit does not substitute for a final seal.
- Entry replay installs observation before target import; missing/replaced/incomplete registration fails completeness.
- A target returns before cleanup creates or kills children: sealing at target return is rejected.
- Windows base-executable substitution is recorded precisely; audit launch intent never substitutes for returned PID/owned handle or confirmed exit.
- Counter overflow, JSONL write/truncation failure, missing/duplicate/out-of-order sequence numbers, unknown child identity, and late events all preserve an explicit incomplete state.

No baseline source, runtime behavior, gate acceptance, timeout, or revision floor was changed by this research.
