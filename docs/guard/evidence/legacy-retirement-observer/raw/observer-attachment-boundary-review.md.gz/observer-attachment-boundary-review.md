# Observer attachment and callback boundary review

Read-only review after the independent observer suite reached **23 passing tests**. This review made no further fixture or repository changes. The preceding eight failures, source manifests, final successful transcript, and retained final fixtures remain in this directory.

## Acceptance isolation

The current driver calls `worker_evidence` before attaching `producer_observation` as a sibling of `worker`. Neither `worker_evidence` nor `suite_acceptance` references that new sibling. The continuation branch still uses the original `passed` and `verified_legacy_rejection`; suite replay still reconstructs its result from the retained worker/process objects. No acceptance function, deadline constant, revision floor, stop result, or baseline source changed in the inspected diff.

There is a separate report-size boundary: collection bounds diagnostics to approximately 48 KiB, while the final aggregate sanitizer bounds the entire transition report to 256 KiB. Appending diagnostics can overflow an aggregate already near that limit. The final `assert_privacy_safe(report)` is outside `verify`'s main exception handler, so its exception can reach `main`'s failure fallback and replace an otherwise retained outcome. The attachment should fit the remaining aggregate budget or omit only diagnostic detail when it cannot fit. This must not alter the global evidence bound or the original phase/acceptance fields.

## Privacy projection

The existing sanitizer removes keys whose underscore-delimited components include forbidden words. Consequently these observer fields are lost in the public phase report:

- `source_attestation_qualified`;
- `nonspawning_source_attested`;
- returned-process `output_limit_exceeded`.

At the actual `phases[].producer_observation.events[]` nesting, scalar event fields remain within the depth bound, but strings inside a seal event's nested `incomplete` list cross depth 6 and become `"truncated"`. Top-level observation counters, process identity rows, the global incomplete list, `diagnostic_only=True`, and `proof_verified=False` survive. The enclosing temporary directory is removed before the final report is returned, so a hash of a discarded private ledger does not recover the removed details.

A suitable fix is a bounded public projection with safe field names such as `bootstrap_attestation_qualified`, `nonspawning_attested`, and `limit_exceeded`, plus flat process/error records where needed. Preserve the sanitizer's depth/privacy rules. The projection should explicitly remain nonqualifying.

## Callback and timing effects

The inspected observer replaces no application callable and writes no timeout or deadline value. Audit, profiling, and exception-monitor callbacks catch ordinary exceptions; cached fingerprints reduce repeated file reads. Its callable-identity behavior was exercised in subprocess tests for safe native-entry aliases, `subprocess.Popen`, and `multiprocessing.BaseProcess.start`.

Observation still adds synchronous Python/C profiler dispatch, exception-monitor dispatch, stat/psutil/hash work, locking, and ledger writes while existing deadlines run. Identical timings or startup outcomes cannot be promised. An observer-induced timeout remains an original phase failure. The instrumented negative phase must remain ineligible for native-retirement or performance credit.

One preservation gap exists for pre-existing per-thread profilers: `sys.getprofile()` inspects the current thread and `threading.getprofile()` inspects the default for new threads. A different existing thread may have installed its own `sys.setprofile` callback while both checked values are `None`; `threading.setprofile_all_threads` would replace that callback. The suite demonstrates coverage of an existing thread that had no profiler, not preservation of a distinct existing thread's profiler. Either establish that startup ownership condition explicitly or decline profiling when it cannot be established. This is separate from ordinary application-function identity.

The exception monitor reports an observed exact error and whether a cache-named frame was present. Because bootstrap/source attestation remains pending, those observations should not be promoted into authenticated cache causality or no-producer proof.
