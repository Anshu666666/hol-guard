# Independent observer hardening result

The final independent suite passed **28 tests in 4.43 seconds**. Ruff check and format check passed. Exact hashes were captured before execution; all six implementation/entry/driver/test files remained unchanged afterward. All **30 distinct retained ledger files** carried the expected observer source hash.

The historical records are retained separately: the original 12-test smoke passed; the expanded replay suite exposed eight failures, which were fixed before a 23-test pass; the monitoring conversion exposed two initialization failures, retained before the final 28-test pass. No earlier transcript, source manifest, or fixture collection was overwritten.

## Boundaries now exercised

- A thread installs its own custom profiler and signals readiness before observer bootstrap. After bootstrap that exact callback remains installed, records an actual application call, and the observer independently records the same native-entry alias. Application functions, `subprocess.Popen`, and `multiprocessing.BaseProcess.start` retain their identities.
- A diagnostic collected from a bounded-process observation and a synthetic seal error survives `assert_privacy_safe({'phases': [{'producer_observation': observation}]})` **exactly**. The public projection retains flat error facts, `bootstrap_attestation_qualified=False`, `nonspawning_attested=False`, and timeout/containment/limit flags.
- A small original report retains optional diagnostics. An original report within 128 bytes of the 256 KiB bound is returned exactly when adding diagnostics overflows it; the helper leaves its input unchanged. An already oversized original still raises the original validation failure.
- All previous process/ledger cases continue to pass: real spawn replay; child-only native entry; killed child missing its seal; low-level POSIX creation before worker-slot registration; existing-thread coverage; late activity after seal; failed/nonboolean cleanup; malformed sequence, identity, registration, call history, launch attribution, and duplicate PID filenames.

## Monitoring initialization finding

On the available CPython 3.12.14, setting `PY_START | PY_RETURN | CALL | C_RAISE | RAISE` raised `ValueError: cannot set C_RETURN or C_RAISE events independently`. The broad bootstrap exception boundary kept application execution going but left only a registration record, which both new tests detected.

The corrected mask is `PY_START | PY_RETURN | CALL | RAISE` (1045), while the C_RAISE callback stays registered. A standalone harmless `len(1)` TypeError confirmed that the C_RAISE callback still fires through CALL coverage. Adding both C outcome bits is accepted but `get_events` normalizes them away, so excluding them from the stored mask also avoids a false exit-mask mismatch.

## Evidence files

- `observer-hardening-recheck.txt`: final pytest output.
- `observer-hardening-recheck-source-manifest.json`: exact pretest sources.
- `observer-hardening-recheck-summary.json`: test counts and posttest identity checks.
- `observer-hardening-recheck-fixtures/`: final private test ledgers.
- `observer-hardening-initial.txt` and matching manifest/fixtures: monitoring initialization failures.
- `observer-tests-counterexamples-initial.txt` and matching source manifest: earlier eight replay failures.
- `observer-tests-counterexamples-recheck.txt`: the earlier 23-test success.

All results remain diagnostic-only and grant **no native retirement, rollback, performance, or program qualification credit**. Monitoring and synchronous evidence collection still add work under unchanged application deadlines; the suite does not establish zero timing impact or a complete source-attested producer closure.
