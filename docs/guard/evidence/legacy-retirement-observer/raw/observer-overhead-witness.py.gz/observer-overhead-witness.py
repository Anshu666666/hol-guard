from __future__ import annotations

import datetime
import hashlib
import json
import os
import statistics
import subprocess
import sys
import tempfile
import time
from pathlib import Path

REPO = Path('/workspace/scratch/c25672eb4c10/retirement-observer')
OUT = Path('/workspace/scratch/c25672eb4c10/retirement-review/observer-overhead-witness.json')
sys.path.insert(0, str(REPO))
from scripts.ci.installed_transition_observer_receipt import collect

DRIVER = '''from __future__ import annotations
import json
import subprocess
import sys
import time
from pathlib import Path

sys.path.insert(0, REPO)
mode = sys.argv[1]
fixture = Path(sys.argv[2])
bootstrap_started = time.perf_counter_ns()
if mode == "enabled":
    from scripts.ci.installed_transition_observer import bootstrap
    bootstrap(__name__, argv=["--phase", "baseline_rollback", "--fixture-root", str(fixture)])
bootstrap_ns = time.perf_counter_ns() - bootstrap_started

def harmless_call(number):
    return (number * 17) % 103

application_started = time.perf_counter_ns()
checksum = sum(harmless_call(number) for number in range(10000))
child_started = time.perf_counter_ns()
child = subprocess.run([sys.executable, "-I", "-c", "raise SystemExit(0)"], timeout=5, check=False)
child_ns = time.perf_counter_ns() - child_started
application_ns = time.perf_counter_ns() - application_started
print(json.dumps({"mode": mode, "checksum": checksum, "child_return_code": child.returncode,
                  "bootstrap_ns": bootstrap_ns, "application_ns": application_ns, "child_ns": child_ns}), flush=True)
'''


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


sources = [
    'scripts/ci/installed_transition_observer.py',
    'scripts/ci/installed_transition_observer_support.py',
    'scripts/ci/installed_transition_observer_receipt.py',
]


def source_inventory() -> list[dict]:
    return [{'path': source, 'sha256': sha((REPO / source).read_bytes()), 'bytes': (REPO / source).stat().st_size}
            for source in sources]


report = {
    'schema': 'hol-guard.observer-local-overhead.v1',
    'diagnostic_only': True,
    'qualification_credit': False,
    'baseline_modified': False,
    'deadlines_modified': False,
    'timing_subtraction_used_for_acceptance': False,
    'native_ipc_exercised': False,
    'scenario': '10000 harmless Python calls and one synchronous isolated Python child; external wall includes interpreter and observer startup',
    'pair_count': 12,
    'source_before': source_inventory(),
    'driver_sha256': sha(DRIVER.encode()),
    'python_version': sys.version,
    'python_sha256': sha(Path(sys.executable).read_bytes()),
    'started_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'runs': [],
}
expected_checksum = sum((number * 17) % 103 for number in range(10000))
with tempfile.TemporaryDirectory(prefix='hol-observer-overhead-') as temporary:
    root = Path(temporary)
    driver = root / 'driver.py'
    driver.write_text(DRIVER.replace('REPO', repr(str(REPO)), 1))
    report['rendered_driver_sha256'] = sha(driver.read_bytes())
    for pair in range(12):
        order = ('disabled', 'enabled') if pair % 2 == 0 else ('enabled', 'disabled')
        for mode in order:
            run_root = root / f'{pair:02}-{mode}'
            run_root.mkdir(mode=0o700)
            fixture = run_root / 'fixture'
            fixture.mkdir(mode=0o700)
            started = time.perf_counter_ns()
            result = subprocess.run([sys.executable, '-I', str(driver), mode, str(fixture)],
                                    cwd=run_root, capture_output=True, text=True, timeout=15)
            wall_ns = time.perf_counter_ns() - started
            if result.returncode != 0:
                raise RuntimeError('overhead_driver_failed:' + sha(result.stderr.encode()))
            sample = json.loads(result.stdout)
            assert sample['checksum'] == expected_checksum and sample['child_return_code'] == 0
            collection_started = time.perf_counter_ns()
            diagnostic = collect(fixture)
            collection_ns = time.perf_counter_ns() - collection_started
            assert diagnostic['proof_verified'] is False
            sample.update(pair=pair, process_wall_ns=wall_ns, parent_collection_ns=collection_ns,
                          phase_return_code=result.returncode,
                          diagnostic_event_count=len(diagnostic['events']),
                          diagnostic_incomplete=diagnostic['incomplete'])
            report['runs'].append(sample)

report['summary_ms'] = {}
for key in ('bootstrap_ns', 'application_ns', 'child_ns', 'process_wall_ns', 'parent_collection_ns'):
    grouped = {mode: [row[key] / 1_000_000 for row in report['runs'] if row['mode'] == mode]
               for mode in ('disabled', 'enabled')}
    delta = [next(row[key] for row in report['runs'] if row['pair'] == pair and row['mode'] == 'enabled') / 1_000_000
             - next(row[key] for row in report['runs'] if row['pair'] == pair and row['mode'] == 'disabled') / 1_000_000
             for pair in range(12)]
    report['summary_ms'][key.removesuffix('_ns')] = {
        mode: {'minimum': min(values), 'median': statistics.median(values), 'maximum': max(values)}
        for mode, values in grouped.items()
    }
    report['summary_ms'][key.removesuffix('_ns')]['paired_enabled_minus_disabled'] = {
        'minimum': min(delta), 'median': statistics.median(delta), 'maximum': max(delta)}
report['source_after'] = source_inventory()
report['sources_unchanged'] = report['source_before'] == report['source_after']
assert report['sources_unchanged']
report['finished_at'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
OUT.write_text(json.dumps(report, indent=2, sort_keys=True) + '\n')
print(json.dumps({'pairs': 12, 'runs': len(report['runs']), 'sources_unchanged': True, 'summary_ms': report['summary_ms']}))
