from __future__ import annotations

import ast
import hashlib
import json
import subprocess
from pathlib import Path

ROOT = Path('/workspace/scratch/c25672eb4c10/retirement-observer')
BASE = '623a6e058b2c4b650021e3c359d8e58b1be6ea05'
OUT = Path('/workspace/scratch/c25672eb4c10/retirement-review/observer-preservation.json')


def original(path: str) -> str:
    return subprocess.check_output(['git', 'show', f'{BASE}:{path}'], cwd=ROOT).decode()


def sha(text: str) -> str:
    return hashlib.sha256(text.encode()).hexdigest()


class RemoveObservations(ast.NodeTransformer):
    def visit_If(self, node):
        if ast.unparse(node.test) == "phase == 'baseline_rollback'" and 'producer_observation' in ast.dump(node):
            return None
        return self.generic_visit(node)

    def visit_FunctionDef(self, node):
        if node.name == 'public_transition_report':
            return None
        return self.generic_visit(node)

    def visit_Return(self, node):
        if isinstance(node.value, ast.Call) and isinstance(node.value.func, ast.Name) and node.value.func.id == 'public_transition_report':
            node.value.func.id = 'assert_privacy_safe'
        return self.generic_visit(node)


collector = 'scripts/ci/verify_installed_artifact_transitions.py'
before = original(collector)
after = (ROOT / collector).read_text()
normalized = RemoveObservations().visit(ast.parse(after))
collector_same = ast.dump(normalized) == ast.dump(ast.parse(before))
assert collector_same

entry = 'scripts/ci/installed_transition_entry.py'
entry_after = ast.parse((ROOT / entry).read_text())
entry_after.body = [
    node for node in entry_after.body
    if not (isinstance(node, ast.Import) and [alias.name for alias in node.names] == ['os'])
    and not (isinstance(node, ast.Try) and 'installed_transition_observer' in ast.dump(node))
]
entry_same = ast.dump(entry_after) == ast.dump(ast.parse(original(entry)))
assert entry_same

protected = [
    'scripts/ci/installed_artifact_transition_probe.py',
    'scripts/ci/installed_transition_diagnostics.py',
    'scripts/native_slo_session.py',
    'scripts/native_slo_contract.py',
    'scripts/native_slo_acceptance.py',
    '.github/workflows/native-wheel-ci.yml',
]
records = []
for path in protected:
    try:
        first = original(path)
    except subprocess.CalledProcessError:
        continue
    second = (ROOT / path).read_text()
    assert first == second
    records.append({'path': path, 'sha256': sha(first), 'bytes': len(first.encode()), 'unchanged': True})

function_hashes = []
for name in ('worker_evidence', 'suite_acceptance'):
    blocks = []
    for text in (before, after):
        node = next(node for node in ast.parse(text).body if isinstance(node, ast.FunctionDef) and node.name == name)
        blocks.append('\n'.join(text.splitlines()[node.lineno - 1:node.end_lineno]) + '\n')
    assert blocks[0] == blocks[1]
    function_hashes.append({'function': name, 'sha256': sha(blocks[0]), 'bytes': len(blocks[0].encode()), 'unchanged': True})

production_changes = subprocess.check_output(['git', 'status', '--porcelain', '--', 'src', 'rust'], cwd=ROOT).decode()
assert not production_changes
result = {
    'schema': 'hol-guard.observer-source-preservation.v1',
    'parent_commit': BASE,
    'collector_ast_equals_original_after_removing_observation_attachment_and_publication_fallback': collector_same,
    'entry_ast_equals_original_after_removing_observer_bootstrap_and_its_os_import': entry_same,
    'production_python_or_rust_changes': [],
    'unchanged_gate_functions': function_hashes,
    'unchanged_contracts_and_lifecycle_sources': records,
    'new_observation_always_diagnostic_only': True,
    'new_observation_always_proof_verified_false': True,
    'deadline_values_changed': False,
    'floor_values_changed': False,
    'baseline_files_edited': False,
    'identical_wall_clock_behavior_claimed': False,
    'qualification_scope': 'local synthetic stdio/process observation only; no installed IPC, retirement or performance qualification',
}
OUT.write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
print(json.dumps({'checks_passed': True, 'protected_files': len(records), 'gate_functions': len(function_hashes), 'sha256': sha(OUT.read_text())}))
