"""Run only the independent three-case package handoff witness."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import subprocess
import time

root = Path('/workspace/scratch/c25672eb4c10')
work = root / 'mcp-callback-review-tree'
evidence = root / 'mcp-callback-independent-review'
snapshot = evidence / 'snapshot-02/snapshot.json'
files = [item for item in json.loads(snapshot.read_text())['files'] if item['path'].startswith('src/')]
for item in files:
    assert hashlib.sha256((work / item['path']).read_bytes()).hexdigest() == item['sha256'], item['path']
command = [
    str(root / 'validation-venv/bin/python'), '-m', 'pytest', '-q',
    'tests/test_mcp_package_drain_authority_review.py',
    '--basetemp=' + str(evidence / 'package-expanded-fixed'),
]
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
tick = time.monotonic()
with (evidence / 'package-expanded-fixed.log').open('wb') as output:
    result = subprocess.run(command, cwd=work, env=dict(os.environ, PYTHONPATH='src'), stdout=output, stderr=subprocess.STDOUT)
body = (evidence / 'package-expanded-fixed.log').read_bytes()
record = {
    'command': command,
    'cwd': str(work),
    'started_at': started,
    'finished_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'elapsed_seconds': time.monotonic() - tick,
    'exit_code': result.returncode,
    'log_sha256': hashlib.sha256(body).hexdigest(),
    'log_bytes': len(body),
    'source_snapshot': 'snapshot-02/snapshot.json',
    'test_sha256': hashlib.sha256((work / 'tests/test_mcp_package_drain_authority_review.py').read_bytes()).hexdigest(),
    'source_before_after_identical': all(
        hashlib.sha256((work / item['path']).read_bytes()).hexdigest() == item['sha256'] for item in files
    ),
}
(evidence / 'package-expanded-fixed.receipt.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record, indent=2))
print(body.decode())
