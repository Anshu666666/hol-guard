"""Real-stdio security regression; no inactive adapter is installed."""

from __future__ import annotations

import json
import os
from copy import deepcopy
from dataclasses import replace
from pathlib import Path

import pytest

from codex_plugin_scanner.guard import mcp_tool_calls as calls
from codex_plugin_scanner.guard.config import GuardConfig
from codex_plugin_scanner.guard.proxy import framing, runtime_mcp
from codex_plugin_scanner.guard.proxy.tool_call_binding import current_tool_call_binding

from .test_mcp_owned_preparation_pilot import _session


def test_local_grant_mutation_cannot_reach_later_saved_lookup_or_child(tmp_path, monkeypatch):
    proxy, messages, marker = _session(tmp_path)
    proxy.config = replace(proxy.config, artifact_actions={})
    trace = []
    original_override = GuardConfig.resolve_action_override
    original_grant = proxy.store.read_local_mcp_grant
    original_saved = proxy.store.resolve_policy_decision_lookup_with_memory_pattern

    def policy(config, *args, **kwargs):
        trace.append('policy')
        return original_override(config, *args, **kwargs)

    def grant(*args, **kwargs):
        result = original_grant(*args, **kwargs)
        proxy.config.artifact_actions['codex:runtime:project:synthetic:safe_echo'] = 'block'
        trace.append('grant_changed_current_policy_to_block')
        return result

    def saved(*args, **kwargs):
        trace.append('later_saved_lookup')
        return original_saved(*args, **kwargs)

    monkeypatch.setattr(GuardConfig, 'resolve_action_override', policy)
    monkeypatch.setattr(proxy.store, 'read_local_mcp_grant', grant)
    monkeypatch.setattr(proxy.store, 'resolve_policy_decision_lookup_with_memory_pattern', saved)
    result = proxy.run_session(messages)
    (tmp_path / 'callback-witness.json').write_text(json.dumps({
        'trace': trace,
        'child_received': marker.exists(),
        'last_event': result['events'][-1],
        'current_action': proxy.config.artifact_actions['codex:runtime:project:synthetic:safe_echo'],
        'production_default': True,
        'inactive_prototype_installed': False,
    }, indent=2) + '\n')

    assert trace[:3] == ['policy', 'policy', 'grant_changed_current_policy_to_block']
    assert 'later_saved_lookup' not in trace
    assert not marker.exists()
    assert result['events'][-1]['session_terminal'] is True


def test_unchanged_policy_callbacks_keep_original_order_and_child_bytes(tmp_path, monkeypatch):
    proxy, messages, marker = _session(tmp_path)
    trace = []
    original_override = GuardConfig.resolve_action_override
    original_grant = proxy.store.read_local_mcp_grant
    original_saved = proxy.store.resolve_policy_decision_lookup_with_memory_pattern
    original_package = proxy._package_request_artifact
    original_drain = proxy._drain_and_validate_catalog_authority

    def policy(config, *args, **kwargs):
        trace.append('policy')
        return original_override(config, *args, **kwargs)

    def grant(*args, **kwargs):
        trace.append('local_grant')
        return original_grant(*args, **kwargs)

    def saved(*args, **kwargs):
        trace.append('saved_lookup')
        return original_saved(*args, **kwargs)

    def package(*args, **kwargs):
        trace.append('package_classifier')
        return original_package(*args, **kwargs)

    def drain(**kwargs):
        if kwargs.get('quiet_seconds') == 0.005:
            trace.append('quiet_5ms')
        return original_drain(**kwargs)

    monkeypatch.setattr(GuardConfig, 'resolve_action_override', policy)
    monkeypatch.setattr(proxy.store, 'read_local_mcp_grant', grant)
    monkeypatch.setattr(proxy.store, 'resolve_policy_decision_lookup_with_memory_pattern', saved)
    monkeypatch.setattr(proxy, '_package_request_artifact', package)
    monkeypatch.setattr(proxy, '_drain_and_validate_catalog_authority', drain)
    result = proxy.run_session(messages)
    assert trace == ['policy', 'policy', 'local_grant', 'saved_lookup', 'package_classifier', 'quiet_5ms']
    assert json.loads(marker.read_text()) == messages[-1]
    assert result['responses'][-1]['result']['content'][0]['text'] == 'forwarded'


@pytest.mark.parametrize('stage', ['hash_policy', 'current_policy', 'browser_context', 'saved_lookup', 'validation',
                                   'package_classifier', 'quiet', 'writer'])
def test_authority_changes_stop_at_the_next_boundary(tmp_path, monkeypatch, stage):
    proxy, messages, marker = _session(tmp_path)
    proxy.config = replace(proxy.config, artifact_actions={})
    trace = []
    changed = []
    original_policy = GuardConfig.resolve_action_override
    original_context = calls._browser_runtime_exact_match_context
    original_saved = proxy.store.resolve_policy_decision_lookup_with_memory_pattern
    original_validation = proxy.store.approval_reuse_validation_reason
    original_package = proxy._package_request_artifact
    original_drain = proxy._drain_and_validate_catalog_authority
    original_write = proxy._write_message

    def mutate():
        proxy.config.artifact_actions['codex:runtime:project:synthetic:safe_echo'] = 'block'
        changed.append(True)
        trace.append('changed')

    def policy(config, *args, **kwargs):
        trace.append('policy')
        result = original_policy(config, *args, **kwargs)
        if stage == ('hash_policy' if trace.count('policy') == 1 else 'current_policy'):
            mutate()
        return result

    def context(*args, **kwargs):
        result = original_context(*args, **kwargs)
        if stage == 'browser_context':
            mutate()
        return result

    def saved(*args, **kwargs):
        trace.append('saved')
        result = original_saved(*args, **kwargs)
        if stage == 'saved_lookup':
            mutate()
        return result

    def validation(*args, **kwargs):
        trace.append('validation')
        result = original_validation(*args, **kwargs)
        if stage == 'validation':
            mutate()
        return result

    def package(*args, **kwargs):
        trace.append('package')
        result = original_package(*args, **kwargs)
        if stage == 'package_classifier':
            mutate()
        return result

    def drain(**kwargs):
        result = original_drain(**kwargs)
        if stage == 'quiet' and kwargs.get('quiet_seconds') == 0.005:
            mutate()
        return result

    def write(stream, message, **kwargs):
        if stage == 'writer' and message.get('method') == 'tools/call':
            mutate()
        return original_write(stream, message, **kwargs)

    monkeypatch.setattr(GuardConfig, 'resolve_action_override', policy)
    monkeypatch.setattr(calls, '_browser_runtime_exact_match_context', context)
    monkeypatch.setattr(proxy.store, 'resolve_policy_decision_lookup_with_memory_pattern', saved)
    monkeypatch.setattr(proxy.store, 'approval_reuse_validation_reason', validation)
    monkeypatch.setattr(proxy, '_package_request_artifact', package)
    monkeypatch.setattr(proxy, '_drain_and_validate_catalog_authority', drain)
    monkeypatch.setattr(proxy, '_write_message', write)
    result = proxy.run_session(messages)
    assert changed == [True]
    assert trace[-1] == 'changed'
    assert not marker.exists()
    assert result['events'][-1]['reason_code'] == 'tool_call_authority_changed'
    assert result['events'][-1]['session_terminal'] is True


@pytest.mark.parametrize('mutation', ['original_arguments', 'owned_arguments', 'artifact_metadata', 'artifact_private',
                                      'equal_config_owner', 'effective_cwd', 'catalog_epoch', 'catalog_sibling', 'command'])
def test_grant_callback_binds_every_authority_input(tmp_path, monkeypatch, mutation):
    proxy, messages, marker = _session(tmp_path)
    if mutation == 'effective_cwd':
        proxy.context = replace(proxy.context, workspace_dir=None)
        proxy.config = replace(proxy.config, workspace=None)
        first = tmp_path / 'first'
        second = tmp_path / 'second'
        first.mkdir()
        second.mkdir()
        monkeypatch.chdir(first)
    original_evaluate = proxy._evaluate_tool_call_authority
    original_grant = proxy.store.read_local_mcp_grant
    artifacts = []

    def evaluate(**kwargs):
        artifacts.append(kwargs['artifact'])
        return original_evaluate(**kwargs)

    def grant(*args, **kwargs):
        result = original_grant(*args, **kwargs)
        if mutation == 'original_arguments':
            messages[-1]['params']['arguments']['text'] = 'changed'
        elif mutation == 'owned_arguments':
            current_tool_call_binding().owned_message['params']['arguments']['text'] = 'changed'
        elif mutation == 'artifact_metadata':
            artifacts[0].metadata['tool_description'] = 'changed'
        elif mutation == 'artifact_private':
            artifacts[0].runtime_private_metadata['private'] = 'changed'
        elif mutation == 'equal_config_owner':
            proxy.config = replace(proxy.config)
        elif mutation == 'effective_cwd':
            os.chdir(second)
        elif mutation == 'catalog_epoch':
            proxy._tool_catalog_generation += 1
        elif mutation == 'catalog_sibling':
            proxy._tool_catalog['new-sibling'] = {'inputSchema': {'type': 'object'}}
        else:
            proxy.command.append('changed')
        return result

    def saved(*args, **kwargs):
        pytest.fail('a changed authority reached a later saved lookup')

    monkeypatch.setattr(proxy, '_evaluate_tool_call_authority', evaluate)
    monkeypatch.setattr(proxy.store, 'read_local_mcp_grant', grant)
    monkeypatch.setattr(proxy.store, 'resolve_policy_decision_lookup_with_memory_pattern', saved)
    result = proxy.run_session(messages)
    assert not marker.exists()
    assert result['events'][-1]['reason_code'] in {'tool_call_authority_changed', 'tool_call_request_changed'}
    assert result['events'][-1]['session_terminal'] is True


def test_nested_preparation_cannot_replace_the_selected_outer_artifact(tmp_path, monkeypatch):
    proxy, messages, marker = _session(tmp_path)
    original_evaluate = proxy._evaluate_tool_call_authority
    artifacts = []
    nested = []

    def evaluate(**kwargs):
        artifacts.append(kwargs['artifact'])
        return original_evaluate(**kwargs)

    def package(*, tool_name, arguments):
        nested.append(proxy._resolve_tool_call_authority(tool_name='nested', arguments=arguments))
        artifacts[0].runtime_private_metadata['changed_outer'] = True
        return None

    monkeypatch.setattr(proxy, '_evaluate_tool_call_authority', evaluate)
    monkeypatch.setattr(proxy, '_package_request_artifact', package)
    result = proxy.run_session(messages)
    assert len(nested) == 1
    assert len(artifacts) == 2
    assert not marker.exists()
    assert result['events'][-1]['reason_code'] == 'tool_call_authority_changed'


def test_private_evaluator_owned_artifact_is_bound_through_the_write(tmp_path, monkeypatch):
    proxy, messages, marker = _session(tmp_path)
    original_evaluate = proxy._evaluate_tool_call_authority
    consumed = []
    original_drain = proxy._drain_and_validate_catalog_authority

    def evaluate(**kwargs):
        artifact, artifact_hash, decision = original_evaluate(**kwargs)
        owned = replace(artifact, metadata=deepcopy(artifact.metadata), runtime_private_metadata={})
        consumed.append(owned)
        return owned, artifact_hash, decision

    def drain(**kwargs):
        result = original_drain(**kwargs)
        if kwargs.get('quiet_seconds') == 0.005:
            consumed[0].runtime_private_metadata['changed'] = True
        return result

    monkeypatch.setattr(proxy, '_evaluate_tool_call_authority', evaluate)
    monkeypatch.setattr(proxy, '_drain_and_validate_catalog_authority', drain)
    result = proxy.run_session(messages)
    assert len(consumed) == 1
    assert not marker.exists()
    assert result['events'][-1]['reason_code'] == 'tool_call_authority_changed'


def test_unsupported_artifact_inside_proxy_never_drops_the_guard(tmp_path, monkeypatch):
    proxy, messages, marker = _session(tmp_path)
    original_artifact = runtime_mcp.build_tool_call_artifact
    callbacks = []

    class Hostile(dict):
        def items(self):
            callbacks.append('items')
            raise AssertionError

    def artifact(*args, **kwargs):
        result = original_artifact(*args, **kwargs)
        result.runtime_private_metadata['unsupported'] = Hostile(value='private')
        return result

    monkeypatch.setattr(runtime_mcp, 'build_tool_call_artifact', artifact)
    result = proxy.run_session(messages)
    assert callbacks == []
    assert not marker.exists()
    assert result['events'][-1]['reason_code'] == 'tool_call_authority_changed'


def test_authority_mutation_after_completed_write_does_not_veto_success(tmp_path, monkeypatch):
    proxy, messages, marker = _session(tmp_path)
    proxy.config = replace(proxy.config, artifact_actions={})
    original = framing._write_encoded_line
    completed = []

    def write(stream, data, **kwargs):
        result = original(stream, data, **kwargs)
        if json.loads(data).get('method') == 'tools/call':
            proxy.config.artifact_actions['codex:runtime:project:synthetic:safe_echo'] = 'block'
            completed.append(True)
        return result

    monkeypatch.setattr(framing, '_write_encoded_line', write)
    result = proxy.run_session(messages)
    assert completed == [True]
    assert json.loads(marker.read_text()) == messages[-1]
    assert result['responses'][-1]['result']['content'][0]['text'] == 'forwarded'
