"""Package only explicit source/test evidence, excluding ephemeral store state."""

from pathlib import Path
import ast
import gzip
import hashlib
import json
import shutil
import subprocess


workspace = Path('/workspace/scratch/c25672eb4c10')
source = workspace / 'mcp-authority-callback-evidence'
tree = workspace / 'mcp-authority-callback-evidence-tree'
destination = tree / 'docs/guard/evidence/mcp-authority-callback'
destination.mkdir(parents=True, exist_ok=True)


def copy(path, relative):
    raw = path.read_bytes()
    target = destination / relative
    if path.suffix in {'.log', '.py', '.diff', '.stdout', '.stderr', '.txt'}:
        target = Path(str(target) + '.gz')
        raw = gzip.compress(raw, mtime=0)
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists():
        assert target.read_bytes() == raw, target
    else:
        target.write_bytes(raw)


for name in ['pre-fix/source-and-execution.json', 'pre-fix/pytest.log', 'pre-fix/test_callback_stdio.py',
             'grant-fixed-first.log', 'forward-first.log', 'callback-first.log', 'callback-and-saved-second.log',
             'disposition-corrected.log', 'first-forward-callback-source.json',
             'run_validation.py', 'package_evidence.py']:
    copy(source / name, name)
for name in ['pre-fix/sources', 'first-forward-callback-source', 'review-initial']:
    for path in sorted((source / name).rglob('*')):
        if path.is_file() and not path.is_symlink():
            copy(path, path.relative_to(source))
for run in sorted(source.iterdir()):
    if run.is_dir() and (run / 'receipt.json').exists():
        receipt = json.loads((run / 'receipt.json').read_text())
        assert receipt['source_changed'] == [], run
        for path in sorted(run.rglob('*')):
            if path.is_file() and not path.is_symlink():
                copy(path, Path('validation') / path.relative_to(source))
for name in ['authority-before-mapping.json', 'authority-with-mapping.json', 'privacy-final.json', 'io-ownership-final.json']:
    if (source / name).exists():
        copy(source / name, Path('validation') / name)
for name in ['pre-fix/fixtures', 'grant-fixed-fixtures', 'callback-fixtures-first', 'final-security-regressions-fixtures']:
    for path in sorted((source / name).rglob('*')):
        if path.is_file() and not path.is_symlink() and path.name in {'callback-witness.json', 'received.json', 'wire.json', 'witness.json'}:
            copy(path, Path('synthetic-witnesses') / path.relative_to(source))
copy(workspace / 'rsp100-independent-review/SECURITY-REPAIR-DESIGN.md', 'original-design.md')
peer = workspace / 'mcp-callback-independent-review'
copy(peer / 'pytest-witness-alias-inventory.json', 'independent-pytest-alias-clarification.json')
overlay = peer / 'evidence-overlay/docs/guard/evidence/mcp-authority-callback-independent-review'
peer_destination = tree / 'docs/guard/evidence/mcp-authority-callback-independent-review'
if not peer_destination.exists():
    shutil.copytree(overlay, peer_destination)
else:
    for path in overlay.rglob('*'):
        if path.is_file():
            assert path.read_bytes() == (peer_destination / path.relative_to(overlay)).read_bytes()

code = workspace / 'mcp-authority-callback'
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=code, text=True).strip()
assert head == '6f930c563e4f4e7d43e3bc74171636bc7cbd9d43'
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=code, text=True)
changed = subprocess.check_output(['git', 'diff', '--name-only', 'b157e5b33493b17c439b4237d750bb436382d9b9', head], cwd=code, text=True).splitlines()
files = []
for path in changed:
    raw = (code / path).read_bytes()
    files.append({'path': path, 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()})
source_receipt = {'source_commit': '7e735d294fe3e9b753b8a07ede30c2e865da9d5e', 'ownership_commit': head,
                  'prerequisite_type_identity_commit': 'b157e5b33493b17c439b4237d750bb436382d9b9',
                  'public_base': '1d8467bd2c60a05a45199796027b6b328079eb2e',
                  'clean': True, 'files': files,
                  'unmodified_other_tracked_files': True,
                  'independent_overlay_manifest_sha256': hashlib.sha256((peer_destination / 'manifest.json').read_bytes()).hexdigest(),
                  'desktop_generation_owner': 'refresh_lease_fix',
                  'evidence_only_branch': 'codex/mcp-authority-callback-evidence-20260918'}
(destination / 'final-source.json').write_text(json.dumps(source_receipt, indent=2) + '\n')

old = json.loads(subprocess.check_output(['git', 'show', '7e735d294fe3e9b753b8a07ede30c2e865da9d5e:docs/guard/contracts/hook-data-plane-ownership.v2.json'], cwd=code))
new = json.loads((code / 'docs/guard/contracts/hook-data-plane-ownership.v2.json').read_text())
node = next(node for node in new['nodes'] if node['id'] == 'policy_and_approval_control')
path = 'src/codex_plugin_scanner/guard/mcp_authority_binding.py'
assert node['paths'].count(path) == 1
node['paths'].remove(path)
assert old == new
review = {'before_mapping_native_authority_gate': 'passed', 'after_mapping_native_authority_gate': 'passed',
          'mapping': {'node': 'policy_and_approval_control', 'class': 'python_control', 'path': path},
          'only_manifest_change_is_one_exact_path': True,
          'existing_node_roles_targets_patterns_and_privacy_serializers_unchanged': True,
          'reason': 'Private in-memory invocation authority capture/check and scoped callback control; no emitted artifact serializer, persistence, or source I/O.',
          'initial_gate_pass_explanation': 'The helper was outside the existing protected globs; the declaration adds explicit ownership coverage, not a repair of a failed gate.',
          'no_rust_or_python_hook_authority_role_change': True}
(destination / 'ownership-review.json').write_text(json.dumps(review, indent=2) + '\n')

records = []
for path in sorted(destination.rglob('*')):
    if path.is_file() and path.name != 'manifest.json':
        raw = path.read_bytes()
        item = {'path': str(path.relative_to(destination)), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
        if path.suffix == '.gz':
            original = gzip.decompress(raw)
            item.update(uncompressed_bytes=len(original), uncompressed_sha256=hashlib.sha256(original).hexdigest())
        records.append(item)
(destination / 'manifest.json').write_text(json.dumps({'schema': 'guard.mcp-authority-callback-evidence.v1', 'files': records}, indent=2) + '\n')
print(json.dumps({'files': len(records), 'stored_bytes': sum(item['bytes'] for item in records),
                  'manifest_sha256': hashlib.sha256((destination / 'manifest.json').read_bytes()).hexdigest()}))
