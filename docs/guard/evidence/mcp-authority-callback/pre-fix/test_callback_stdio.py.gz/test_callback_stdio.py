"""Real-stdio security regression; no inactive adapter is installed."""

from __future__ import annotations

import json
from dataclasses import replace

from codex_plugin_scanner.guard.config import GuardConfig

from tests.test_mcp_owned_preparation_pilot import _session


def test_local_grant_mutation_cannot_reach_later_saved_lookup_or_child(tmp_path, monkeypatch):
    proxy, messages, marker = _session(tmp_path)
    proxy.config = replace(proxy.config, artifact_actions={})
    trace = []
    original_override = GuardConfig.resolve_action_override
    original_grant = proxy.store.read_local_mcp_grant
    original_saved = proxy.store.resolve_policy_decision_lookup_with_memory_pattern

    def policy(config, *args, **kwargs):
        trace.append('policy')
        return original_override(config, *args, **kwargs)

    def grant(*args, **kwargs):
        result = original_grant(*args, **kwargs)
        proxy.config.artifact_actions['codex:runtime:project:synthetic:safe_echo'] = 'block'
        trace.append('grant_changed_current_policy_to_block')
        return result

    def saved(*args, **kwargs):
        trace.append('later_saved_lookup')
        return original_saved(*args, **kwargs)

    monkeypatch.setattr(GuardConfig, 'resolve_action_override', policy)
    monkeypatch.setattr(proxy.store, 'read_local_mcp_grant', grant)
    monkeypatch.setattr(proxy.store, 'resolve_policy_decision_lookup_with_memory_pattern', saved)
    result = proxy.run_session(messages)
    (tmp_path / 'callback-witness.json').write_text(json.dumps({
        'trace': trace,
        'child_received': marker.exists(),
        'last_event': result['events'][-1],
        'current_action': proxy.config.artifact_actions['codex:runtime:project:synthetic:safe_echo'],
        'production_default': True,
        'inactive_prototype_installed': False,
    }, indent=2) + '\n')

    assert trace[:3] == ['policy', 'policy', 'grant_changed_current_policy_to_block']
    assert 'later_saved_lookup' not in trace
    assert not marker.exists()
    assert result['events'][-1]['session_terminal'] is True


def test_unchanged_policy_callbacks_keep_original_order_and_child_bytes(tmp_path, monkeypatch):
    proxy, messages, marker = _session(tmp_path)
    trace = []
    original_override = GuardConfig.resolve_action_override
    original_grant = proxy.store.read_local_mcp_grant
    original_saved = proxy.store.resolve_policy_decision_lookup_with_memory_pattern
    original_package = proxy._package_request_artifact
    original_drain = proxy._drain_and_validate_catalog_authority

    def policy(config, *args, **kwargs):
        trace.append('policy')
        return original_override(config, *args, **kwargs)

    def grant(*args, **kwargs):
        trace.append('local_grant')
        return original_grant(*args, **kwargs)

    def saved(*args, **kwargs):
        trace.append('saved_lookup')
        return original_saved(*args, **kwargs)

    def package(*args, **kwargs):
        trace.append('package_classifier')
        return original_package(*args, **kwargs)

    def drain(**kwargs):
        if kwargs.get('quiet_seconds') == 0.005:
            trace.append('quiet_5ms')
        return original_drain(**kwargs)

    monkeypatch.setattr(GuardConfig, 'resolve_action_override', policy)
    monkeypatch.setattr(proxy.store, 'read_local_mcp_grant', grant)
    monkeypatch.setattr(proxy.store, 'resolve_policy_decision_lookup_with_memory_pattern', saved)
    monkeypatch.setattr(proxy, '_package_request_artifact', package)
    monkeypatch.setattr(proxy, '_drain_and_validate_catalog_authority', drain)
    result = proxy.run_session(messages)
    assert trace == ['policy', 'policy', 'local_grant', 'saved_lookup', 'package_classifier', 'quiet_5ms']
    assert json.loads(marker.read_text()) == messages[-1]
    assert result['responses'][-1]['result']['content'][0]['text'] == 'forwarded'
