"""Run one finite local check with complete changed-source receipts."""

import argparse
import datetime
import gzip
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time


parser = argparse.ArgumentParser()
parser.add_argument("name")
parser.add_argument("command", nargs=argparse.REMAINDER)
args = parser.parse_args()
root = Path.cwd()
destination = Path(__file__).parent / args.name
destination.mkdir(exist_ok=False)
command = args.command
if command and command[0] == "--":
    command = command[1:]
paths = sorted(set(subprocess.check_output(
    ["git", "diff", "--name-only", "HEAD"], text=True
).splitlines() + subprocess.check_output(
    ["git", "ls-files", "--others", "--exclude-standard"], text=True
).splitlines() + subprocess.check_output(
    ["git", "diff", "--name-only", "b157e5b33493b17c439b4237d750bb436382d9b9", "HEAD"], text=True
).splitlines()))
paths = [path for path in paths if (path.startswith(("src/", "tests/")) and path.endswith(".py"))
         or path == "docs/guard/contracts/hook-data-plane-ownership.v2.json"]


def capture(label):
    result = []
    for relative in paths:
        raw = (root / relative).read_bytes()
        archive = destination / label / (relative + ".gz")
        archive.parent.mkdir(parents=True, exist_ok=True)
        archive.write_bytes(gzip.compress(raw, mtime=0))
        result.append({"path": relative, "size": len(raw), "sha256": hashlib.sha256(raw).hexdigest(),
                       "lossless_source": str(archive.relative_to(destination))})
    return result


before = capture("before")
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
start = time.monotonic()
with (destination / "output.log").open("wb") as log:
    process = subprocess.run(command, env={**os.environ, "PYTHONPATH": "src"}, stdout=log, stderr=subprocess.STDOUT)
elapsed = time.monotonic() - start
after = capture("after")
receipt = {
    "cwd": str(root), "head": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
    "started_utc": started, "completed_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "command": command, "environment_override": {"PYTHONPATH": "src"},
    "shared_validation_lock": "/workspace/scratch/c25672eb4c10/validation.lock",
    "lock_held_by_calling_flock": True, "seconds": elapsed, "exit_code": process.returncode,
    "source_before": before, "source_after": after,
    "runner_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    "source_changed": [(first["path"], first["sha256"], second["sha256"]) for first, second in zip(before, after, strict=True)
                       if first["sha256"] != second["sha256"]],
}
(destination / "receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
print(json.dumps({"name": args.name, "exit_code": process.returncode, "seconds": elapsed,
                  "changed_sources": receipt["source_changed"]}))
raise SystemExit(process.returncode)
