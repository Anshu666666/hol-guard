"""Run the existing Desktop corpus generator on one frozen isolated source."""

from __future__ import annotations

import argparse
import gzip
import hashlib
import importlib
import json
import os
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--source-commit", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    root = args.root.resolve()
    output = args.output.resolve()
    commit = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=root, text=True).strip()
    status = subprocess.check_output(["git", "status", "--porcelain=v1", "--untracked-files=all"], cwd=root, text=True)
    if commit != args.source_commit or status:
        raise RuntimeError("desktop_refresh_requires_exact_clean_source")
    output.mkdir(parents=True, exist_ok=False)
    fixture = root / "tests/fixtures/guard-command-corpus/decision-diff-report.json"
    before_raw = fixture.read_bytes()
    (output / "fixture-before.json.gz").write_bytes(gzip.compress(before_raw, mtime=0))
    (output / "runner.py.gz").write_bytes(gzip.compress(Path(__file__).read_bytes(), mtime=0))
    os.chdir(root)
    sys.path[:0] = [str(root), str(root / "src")]
    source = importlib.import_module("tests.guard_command_decision_diff")
    if Path(source.__file__).resolve() != root / "tests/guard_command_decision_diff.py":
        raise RuntimeError("desktop_refresh_wrong_generator_import")
    source_before = source._source_bindings()
    inventory = {
        source.source_binding_id(str(path.resolve().relative_to(root))): str(path.resolve().relative_to(root))
        for path in source._EVIDENCE_SOURCE_PATHS
    }
    report = {
        "schema": "guard.mcp-authority-desktop-source-refresh.v1",
        "source_commit": commit,
        "source_tree": subprocess.check_output(["git", "rev-parse", "HEAD^{tree}"], cwd=root, text=True).strip(),
        "initial_clean_status": status == "",
        "python": sys.version,
        "python_executable": sys.executable,
        "fixture_before_sha256": digest(before_raw),
        "original_fixture_source_bindings_match": json.loads(before_raw)["bindings"]["sources_sha256"] == source_before,
        "source_bindings_before": source_before,
        "actual_source_inventory": inventory,
        "generator_module_sha256": digest(Path(source.__file__).read_bytes()),
        "performance_campaign": False,
        "runs": [],
    }

    def checkpoint() -> None:
        (output / "validation.json").write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")

    def run(label: str, command: list[str]) -> int:
        started_utc = datetime.now(timezone.utc).isoformat()
        started = time.perf_counter()
        environ = os.environ.copy()
        environ["PYTHONPATH"] = str(root / "src")
        with (output / (label + ".stdout")).open("wb") as stdout, (output / (label + ".stderr")).open("wb") as stderr:
            completed = subprocess.run(command, cwd=root, env=environ, stdout=stdout, stderr=stderr, check=False)
        report["runs"].append(
            {
                "label": label,
                "command": command,
                "started_utc": started_utc,
                "finished_utc": datetime.now(timezone.utc).isoformat(),
                "exit_code": completed.returncode,
                "elapsed_seconds": time.perf_counter() - started,
            }
        )
        checkpoint()
        return completed.returncode

    checkpoint()
    code = run("repository-generator-write", [sys.executable, "tests/guard_command_decision_diff.py", "--write"])
    if code:
        return code
    after_raw = fixture.read_bytes()
    (output / "fixture-after.json.gz").write_bytes(gzip.compress(after_raw, mtime=0))
    before, after = json.loads(before_raw), json.loads(after_raw)
    old_bindings = before["bindings"].pop("sources_sha256")
    new_bindings = after["bindings"].pop("sources_sha256")
    current_sources = source._source_bindings()
    changed = {
        inventory.get(name, name): {"before": old_bindings.get(name), "after": new_bindings.get(name)}
        for name in sorted(set(old_bindings) | set(new_bindings))
        if old_bindings.get(name) != new_bindings.get(name)
    }
    report.update(
        fixture_after_sha256=digest(after_raw),
        fixture_after_framed_sha256=source.report_framed_sha256(json.loads(after_raw)),
        all_non_source_report_fields_identical=before == after,
        evaluated_corpus_count=after["corpus"]["total_count"],
        current_vs_proposed=after["current_vs_proposed"],
        legacy_to_current=after["legacy_to_current"],
        oracle_reconciliation=after["oracle_reconciliation"],
        changed_bound_sources=changed,
        current_source_bindings_match_generated=new_bindings == current_sources,
        bound_sources_unchanged_during_generation=current_sources == source_before,
        source_bindings_after=current_sources,
    )
    checkpoint()
    if before != after or new_bindings != current_sources or current_sources != source_before:
        raise RuntimeError("desktop_refresh_unexpected_semantic_or_source_change")
    code = run(
        "decision-diff-and-desktop-tests",
        [
            sys.executable,
            "-m",
            "pytest",
            "-q",
            "-p",
            "no:cacheprovider",
            "tests/test_guard_command_decision_diff.py",
            "tests/test_guard_desktop_contract.py",
        ],
    )
    report["bound_sources_unchanged_after_validation"] = source._source_bindings() == source_before
    report["fixture_unchanged_after_validation"] = fixture.read_bytes() == after_raw
    checkpoint()
    if not report["bound_sources_unchanged_after_validation"] or not report["fixture_unchanged_after_validation"]:
        raise RuntimeError("desktop_refresh_source_changed_during_validation")
    print(
        json.dumps(
            {
                "exit_code": code,
                "changed_bound_sources": sorted(changed),
                "framed_sha256": report["fixture_after_framed_sha256"],
            }
        )
    )
    return code


if __name__ == "__main__":
    raise SystemExit(main())
