"""Finite current-production probes; never install or execute E/F adapters."""

from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
import sys
import tempfile
from pathlib import Path


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--repository", type=Path, required=True)
    parser.add_argument("--case", choices=("capture", "completed-owned-mutation"), required=True)
    args = parser.parse_args()
    root = args.repository.resolve()
    sys.path[:0] = [str(root), str(root / "src")]
    from tests.test_mcp_owned_preparation_pilot import _session
    from codex_plugin_scanner.guard.proxy import framing, runtime_mcp
    from codex_plugin_scanner.guard.proxy.tool_call_binding import current_tool_call_binding

    result = {
        "case": args.case,
        "pilot_installed": False,
        "commit": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=root, text=True).strip(),
        "status": subprocess.check_output(["git", "status", "--porcelain"], cwd=root, text=True),
        "source_sha256": {
            name: hashlib.sha256((root / name).read_bytes()).hexdigest()
            for name in (
                "src/codex_plugin_scanner/guard/proxy/runtime_mcp.py",
                "src/codex_plugin_scanner/guard/proxy/tool_call_binding.py",
                "src/codex_plugin_scanner/guard/proxy/framing.py",
                "tests/test_mcp_owned_preparation_pilot.py",
            )
        },
    }
    with tempfile.TemporaryDirectory(prefix="mcp-independent-review-") as directory:
        proxy, messages, marker = _session(Path(directory))
        target = messages[-1]
        original_bind = runtime_mcp.bind_tool_call
        original_drain = proxy._drain_and_validate_catalog_authority
        original_write = framing._write_encoded_line
        observed = {"capture_mutation": False, "binding_none": False, "quiet_fence": False}

        def bind(message, **kwargs):
            binding = original_bind(message, **kwargs)
            if message is target:
                observed["binding_none"] = binding is None
            return binding

        def drain(**kwargs):
            response = original_drain(**kwargs)
            if kwargs.get("quiet_seconds") == 0.005:
                observed["quiet_fence"] = True
                target["params"]["arguments"]["text"] = "changed after original authority"
            return response

        def trace(frame, event, _arg):
            if (
                event == "line"
                and frame.f_code.co_name == "_own_plain_json"
                and frame.f_locals.get("value") is target
                and "key" in frame.f_locals
                and not observed["capture_mutation"]
            ):
                target["capture_race_marker"] = True
                observed["capture_mutation"] = True
                sys.settrace(None)
            return trace

        def write(stream, data, **kwargs):
            response = original_write(stream, data, **kwargs)
            if json.loads(data).get("method") == "tools/call":
                binding = current_tool_call_binding()
                assert binding is not None
                binding.owned_message["params"]["arguments"]["text"] = "changed only after completed write"
            return response

        try:
            if args.case == "capture":
                runtime_mcp.bind_tool_call = bind
                proxy._drain_and_validate_catalog_authority = drain
                sys.settrace(trace)
            else:
                framing._write_encoded_line = write
            session = proxy.run_session(messages)
        finally:
            sys.settrace(None)
            runtime_mcp.bind_tool_call = original_bind
            framing._write_encoded_line = original_write
        result.update(observed)
        result["forwarded"] = json.loads(marker.read_text()) if marker.exists() else None
        result["response"] = session["responses"][-1]
        result["event"] = session["events"][-1]
    print(json.dumps(result, sort_keys=True, indent=2))


if __name__ == "__main__":
    main()
