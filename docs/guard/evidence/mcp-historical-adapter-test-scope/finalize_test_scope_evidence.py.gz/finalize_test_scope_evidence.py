from __future__ import annotations

import ast
import gzip
import hashlib
import json
import pathlib
import subprocess


ROOT = pathlib.Path('/workspace/scratch/c25672eb4c10/mcp-binding-test-reconciliation')
OUT = ROOT / 'docs/guard/evidence/mcp-historical-adapter-test-scope'
REVIEW = pathlib.Path('/workspace/scratch/c25672eb4c10/mcp-independent-review')
TESTS = ['test_mcp_owned_preparation_pilot.py', 'test_mcp_streaming_preparation_pilot.py']


def identity(data):
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


def case_count(node):
    count = 1
    for decorator in node.decorator_list:
        if isinstance(decorator, ast.Call) and isinstance(decorator.func, ast.Attribute):
            if decorator.func.attr == 'parametrize':
                count *= len(ast.literal_eval(decorator.args[1]))
    return count


def test_nodes(text):
    functions = {}
    aliases = {}
    for node in ast.parse(text).body:
        if isinstance(node, ast.FunctionDef):
            functions[node.name] = node
        elif isinstance(node, ast.Assign) and isinstance(node.value, ast.Attribute):
            for target in node.targets:
                if isinstance(target, ast.Name) and target.id.startswith('test_'):
                    aliases[target.id] = node
    return functions, aliases


original = {name: gzip.decompress((OUT / (name + '.gz')).read_bytes()).decode() for name in TESTS}
current = {name: (ROOT / 'tests' / name).read_text() for name in TESTS}
old_e, _ = test_nodes(original[TESTS[0]])
new_e, _ = test_nodes(current[TESTS[0]])
scopes = {}
for name in TESTS:
    old_functions, old_aliases = test_nodes(original[name])
    new_functions, new_aliases = test_nodes(current[name])
    retained = []
    for label in sorted(old_functions.keys() & new_functions.keys()):
        left, right = old_functions[label], new_functions[label]
        assert ast.dump(left, include_attributes=False) == ast.dump(right, include_attributes=False), label
        before = ast.get_source_segment(original[name], left).encode()
        after = ast.get_source_segment(current[name], right).encode()
        assert before == after, label
        retained.append({'name': label, 'source_sha256': identity(before)['sha256'], 'byte_identical_function_and_ast': True})
    retained_aliases = []
    for label in sorted(old_aliases.keys() & new_aliases.keys()):
        assert ast.dump(old_aliases[label], include_attributes=False) == ast.dump(new_aliases[label], include_attributes=False), label
        retained_aliases.append({'name': label, 'target': old_aliases[label].value.attr, 'ast_unchanged': True})

    def collect(functions, aliases, external):
        values = {n: case_count(v) for n, v in functions.items() if n.startswith('test_')}
        values.update({n: case_count(external[v.value.attr]) for n, v in aliases.items()})
        return values

    old_cases = collect(old_functions, old_aliases, old_e)
    new_cases = collect(new_functions, new_aliases, new_e)
    unchanged_cases = sum(old_cases[n] for n in old_cases.keys() & new_cases.keys())
    scopes[name] = {
        'retained': retained,
        'retained_aliases': retained_aliases,
        'archived_obsolete_functions': sorted(old_functions.keys() - new_functions.keys()),
        'archived_obsolete_aliases': {n: v.value.attr for n, v in old_aliases.items() if n not in new_aliases},
        'new_current_runtime_functions': sorted(new_functions.keys() - old_functions.keys()),
        'new_current_runtime_aliases': {n: v.value.attr for n, v in new_aliases.items() if n not in old_aliases},
        'original_cases': old_cases,
        'current_cases': new_cases,
        'accounting': {
            'original': sum(old_cases.values()),
            'current': sum(new_cases.values()),
            'retained': unchanged_cases,
            'archived_obsolete': sum(old_cases.values()) - unchanged_cases,
            'new': sum(new_cases.values()) - unchanged_cases,
        },
    }
assert [scopes[name]['accounting'] for name in TESTS] == [
    {'original': 37, 'current': 29, 'retained': 20, 'archived_obsolete': 17, 'new': 9},
    {'original': 44, 'current': 34, 'retained': 25, 'archived_obsolete': 19, 'new': 9},
]
write_json(OUT / 'predicate-scope.json', scopes)

for name in [
    'test-scope-first.log', 'test-scope-final.log',
    'boundary_review_probe.py', 'proposed-historical-test-scope.diff',
    'finalize_test_scope_evidence.py',
    '9ca32244-capture.stderr', '9ca32244-completed-owned-mutation.stderr',
    'a9290fda-capture.stderr', 'a9290fda-completed-owned-mutation.stderr',
]:
    (OUT / (name + '.gz')).write_bytes(gzip.compress((REVIEW / name).read_bytes(), mtime=0))
for name in [
    'test-scope-first-receipt.json', 'test-scope-final-receipt.json',
    '9ca32244-capture.json', '9ca32244-completed-owned-mutation.json',
    'a9290fda-capture.json', 'a9290fda-completed-owned-mutation.json',
    '9ca32244-probe-receipts.json', 'a9290fda-probe-receipts.json',
]:
    (OUT / name).write_bytes((REVIEW / name).read_bytes())

source_record = json.loads((OUT / 'original-source.json').read_text())
for name, expected in source_record['files'].items():
    data = gzip.decompress((OUT / expected['archive']).read_bytes()) if 'archive' in expected else (ROOT / name).read_bytes()
    assert identity(data) == {key: expected[key] for key in ('bytes', 'sha256')}, name
unchanged_scopes = ['src', 'scripts', 'contracts', 'pyproject.toml', 'uv.lock', 'docs/guard/rust-performance',
                    'docs/guard/rust-performance-mcp-owned-preparation.md', 'docs/guard/rust-performance-mcp-streaming-preparation.md']
diff = subprocess.check_output(['git', 'diff', 'a9290fda493b93ce1df0113865d7eb487ebd57d5', '--', *unchanged_scopes], cwd=ROOT)
assert not diff
static_checks = []
for command in [
    ['/workspace/scratch/c25672eb4c10/validation-venv/bin/python', '-m', 'ruff', 'check', *['tests/' + name for name in TESTS]],
    ['/workspace/scratch/c25672eb4c10/validation-venv/bin/python', '-m', 'ruff', 'format', '--check', *['tests/' + name for name in TESTS]],
    ['git', 'diff', '--check'],
]:
    result = subprocess.run(command, cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    static_checks.append({'argv': command, 'exit_code': result.returncode, 'output': result.stdout.decode()})
    assert result.returncode == 0, result.stdout.decode()
write_json(OUT / 'validation.json', {
    'source_base': 'a9290fda493b93ce1df0113865d7eb487ebd57d5',
    'final_tests': {'passed': 87, 'elapsed_seconds': 8.52, 'receipt': 'test-scope-final-receipt.json', 'raw': 'test-scope-final.log.gz'},
    'initial_tests': {'passed': 84, 'elapsed_seconds': 9.00, 'receipt': 'test-scope-first-receipt.json', 'raw': 'test-scope-first.log.gz'},
    'static_checks': static_checks,
    'unchanged_scopes_from_source_base': unchanged_scopes,
    'original_records_verified': len(source_record['files']),
    'retained_helper_case_count': 45,
    'archived_obsolete_case_count': 36,
    'new_current_runtime_incompatibility_cases': 18,
    'current_production_binding_cases': 24,
    'measurement_workers': 'Forbidden by test-only fixture; accounting predicates use stubbed workers.',
    'scope': 'Finite current-production source validation, not repository CI, performance, E/F activation, or replacement historical evidence.',
})

records = {}
for path in sorted(OUT.rglob('*')):
    if not path.is_file() or path.name == 'manifest.json':
        continue
    data = path.read_bytes()
    record = identity(data)
    if path.suffix == '.gz':
        record['decoded'] = identity(gzip.decompress(data))
    elif path.suffix == '.json':
        json.loads(data)
    records[path.relative_to(OUT).as_posix()] = record
write_json(OUT / 'manifest.json', {'schema': 'guard.mcp-historical-adapter-test-scope.v1', 'files': records})
print(json.dumps({'files': len(records), 'manifest_sha256': identity((OUT / 'manifest.json').read_bytes())['sha256'],
                  'case_accounting': {name: scopes[name]['accounting'] for name in TESTS}}))
