"""Independent finite local-owner and nested-scope witnesses; no workload run."""

from __future__ import annotations

import json

import pytest

from codex_plugin_scanner.guard import mcp_tool_calls as calls
from codex_plugin_scanner.guard.mcp_authority_binding import current_mcp_authority_check
from codex_plugin_scanner.guard.proxy.tool_call_binding import current_tool_call_binding

from .test_mcp_owned_preparation_pilot import _session
from .test_mcp_per_call_risk_prototype import original_evaluator, prototype  # noqa: F401


@pytest.mark.parametrize("nested", [False, True], ids=["single", "nested"])
@pytest.mark.parametrize("mutate_owned", [False, True], ids=["unchanged", "changed-owned-copy"])
def test_local_owned_artifact_and_nested_authority_scope(tmp_path, monkeypatch, prototype, nested, mutate_owned):
    outer_root = tmp_path / "outer"
    inner_root = tmp_path / "inner"
    outer_root.mkdir()
    inner_root.mkdir()
    proxy, messages, marker = _session(outer_root)
    inner, inner_messages, inner_marker = _session(inner_root)
    expected = json.loads(json.dumps(messages[-1]))
    expected_inner = json.loads(json.dumps(inner_messages[-1]))
    original_categories = calls.tool_call_risk_categories
    original_grant = proxy.store.read_local_mcp_grant
    original_lookup = proxy.store.resolve_policy_decision_lookup_with_memory_pattern
    prepared = []
    grants = []
    lookups = []
    nested_results = []
    restored = []

    def categories(artifact, arguments):
        result = original_categories(artifact, arguments)
        prepared.append(artifact)
        return result

    def grant(*args, **kwargs):
        result = original_grant(*args, **kwargs)
        grants.append(True)
        assert len(grants) == 1
        assert len(prepared) == 1
        selected_authority = current_mcp_authority_check()
        selected_request = current_tool_call_binding()
        assert selected_authority is not None and selected_request is not None
        if nested:
            nested_result = inner.run_session(inner_messages)
            nested_results.append(nested_result)
            assert json.loads(inner_marker.read_text()) == expected_inner
            assert nested_result["responses"][-1]["result"]["content"][0]["text"] == "forwarded"
            assert current_mcp_authority_check() is selected_authority
            assert current_tool_call_binding() is selected_request
            restored.append(True)
        if mutate_owned:
            # Only the candidate's copy changes. The outer production artifact
            # and original wire arguments stay unchanged, so local ownership
            # must still guard the next saved-state callback.
            prepared[0].runtime_private_metadata["changed_in_grant"] = True
        return result

    def lookup(*args, **kwargs):
        lookups.append(kwargs["artifact_hash"])
        return original_lookup(*args, **kwargs)

    monkeypatch.setattr(calls, "tool_call_risk_categories", categories)
    monkeypatch.setattr(proxy.store, "read_local_mcp_grant", grant)
    monkeypatch.setattr(proxy.store, "resolve_policy_decision_lookup_with_memory_pattern", lookup)
    result = proxy.run_session(messages)
    record = {
        "nested": nested,
        "mutate_owned": mutate_owned,
        "grants": len(grants),
        "outer_saved_lookups": len(lookups),
        "outer_child_received": marker.exists(),
        "inner_child_received": inner_marker.exists(),
        "nested_scope_restored_by_identity": restored,
        "prototype_counters": dict(prototype.counters),
        "outer_event": result["events"][-1],
        "scope": "finite actual JSON-recorder stdio calls; no performance or E/F execution",
    }
    (tmp_path / "witness.json").write_text(json.dumps(record, indent=2) + "\n")
    assert grants == [True]
    assert restored == ([True] if nested else [])
    assert len(nested_results) == int(nested)
    assert prototype.counters["category_derivations"] == 1 + int(nested)
    assert prototype.counters["existing_argument_owner"] == 1 + int(nested)
    assert prototype.counters["compatibility_fallback"] == 0
    assert prototype.counters["unsupported_fallback"] == 0
    if mutate_owned:
        assert lookups == []
        assert not marker.exists()
        assert result["events"][-1]["reason_code"] == "tool_call_authority_changed"
        assert result["events"][-1]["session_terminal"] is True
        assert prototype.counters["completed_invocations"] == int(nested)
    else:
        assert len(lookups) == 1
        assert json.loads(marker.read_text()) == expected
        assert result["responses"][-1]["result"]["content"][0]["text"] == "forwarded"
        assert prototype.counters["completed_invocations"] == 1 + int(nested)
