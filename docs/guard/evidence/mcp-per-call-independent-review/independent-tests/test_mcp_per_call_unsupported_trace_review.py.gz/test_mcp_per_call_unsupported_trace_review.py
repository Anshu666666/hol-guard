"""Finite compatibility call-order witness; it records no performance data."""

import json
import sys

from codex_plugin_scanner.guard.config import GuardConfig
from codex_plugin_scanner.guard.proxy import runtime_mcp

from .test_mcp_owned_preparation_pilot import _session
from .test_mcp_per_call_risk_prototype import original_evaluator, prototype  # noqa: F401


def test_unsupported_fallback_preserves_default_preparation_calls(
    tmp_path, monkeypatch, original_evaluator, prototype
):
    proxy, _messages, _marker = _session(tmp_path)
    selected_evaluator = runtime_mcp.RuntimeMcpGuardProxy._evaluate_tool_call_authority
    check_code = runtime_mcp.RuntimeMcpGuardProxy._check_tool_call_preparation.__code__
    original_override = GuardConfig.resolve_action_override
    trace = []

    class ObservedDict(dict):
        def items(self):
            trace.append("custom_items")
            return super().items()

    def override(*args, **kwargs):
        trace.append("policy")
        return original_override(*args, **kwargs)

    def call_trace(frame, event, _argument):
        if event == "call" and frame.f_code is check_code:
            trace.append("preparation")

    monkeypatch.setattr(GuardConfig, "resolve_action_override", override)
    arguments = ObservedDict(text="ordinary")
    previous_trace = sys.getprofile()
    try:
        sys.setprofile(call_trace)
        monkeypatch.setattr(runtime_mcp.RuntimeMcpGuardProxy, "_evaluate_tool_call_authority", original_evaluator)
        expected = proxy._resolve_tool_call_authority(tool_name="safe_echo", arguments=arguments)
        expected_trace = list(trace)
        trace.clear()
        monkeypatch.setattr(runtime_mcp.RuntimeMcpGuardProxy, "_evaluate_tool_call_authority", selected_evaluator)
        actual = proxy._resolve_tool_call_authority(tool_name="safe_echo", arguments=arguments)
    finally:
        sys.setprofile(previous_trace)
    (tmp_path / "witness.json").write_text(json.dumps({
        "baseline_trace": expected_trace,
        "prototype_trace": trace,
        "baseline_preparation_calls": expected_trace.count("preparation"),
        "prototype_preparation_calls": trace.count("preparation"),
        "equal_result": actual == expected,
        "prototype_counters": dict(prototype.counters),
        "scope": "finite direct-Python unsupported-input call order; no timing, worker or profile campaign",
    }, indent=2) + "\n")
    assert actual == expected
    assert trace == expected_trace
