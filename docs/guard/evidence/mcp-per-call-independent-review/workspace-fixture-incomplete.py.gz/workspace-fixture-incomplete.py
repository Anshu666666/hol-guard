"""Finite unsupported path callback compatibility witness; no timing data."""

import json
from dataclasses import replace

from codex_plugin_scanner.guard.proxy import runtime_mcp

from .test_mcp_owned_preparation_pilot import _session
from .test_mcp_per_call_risk_prototype import original_evaluator, prototype  # noqa: F401


def test_unsupported_workspace_preserves_original_path_callback_order(
    tmp_path, monkeypatch, original_evaluator, prototype
):
    proxy, _messages, _marker = _session(tmp_path)
    selected_evaluator = runtime_mcp.RuntimeMcpGuardProxy._evaluate_tool_call_authority
    trace = []

    class ObservedWorkspace:
        def __fspath__(self):
            trace.append("workspace_fspath")
            return str(tmp_path)

    proxy.context = replace(proxy.context, workspace_dir=ObservedWorkspace())
    monkeypatch.setattr(runtime_mcp.RuntimeMcpGuardProxy, "_evaluate_tool_call_authority", original_evaluator)
    expected = proxy._resolve_tool_call_authority(tool_name="safe_echo", arguments={"text": "ordinary"})
    expected_trace = list(trace)
    trace.clear()
    monkeypatch.setattr(runtime_mcp.RuntimeMcpGuardProxy, "_evaluate_tool_call_authority", selected_evaluator)
    actual = proxy._resolve_tool_call_authority(tool_name="safe_echo", arguments={"text": "ordinary"})
    (tmp_path / "witness.json").write_text(json.dumps({
        "baseline_trace": expected_trace,
        "prototype_trace": trace,
        "equal_result": actual == expected,
        "prototype_counters": dict(prototype.counters),
        "scope": "finite Python-only unsupported workspace callback order, no timing or campaign",
    }, indent=2) + "\n")
    assert actual == expected
    assert trace == expected_trace
    assert prototype.counters["unsupported_fallback"] == 1
    assert prototype.counters["category_derivations"] == 0
