from __future__ import annotations

import gzip
import hashlib
import json
import sys
import types
from dataclasses import replace
from pathlib import Path
from tempfile import TemporaryDirectory

import pytest

ROOT = Path('/workspace/scratch/c25672eb4c10/rsp100-per-call')
OUT = Path('/workspace/scratch/c25672eb4c10/rsp100-independent-review')
sys.path.insert(0, str(ROOT))

from codex_plugin_scanner.guard import mcp_tool_calls as calls
from codex_plugin_scanner.guard.config import GuardConfig
from codex_plugin_scanner.guard.proxy import runtime_mcp
from tests.test_mcp_owned_preparation_pilot import _session

source = gzip.decompress((OUT / 'snapshot-initial/scripts/guard_mcp_per_call_risk_prototype.py.gz').read_bytes())
module = types.ModuleType('independent_frozen_per_call_prototype')
sys.modules[module.__name__] = module
exec(compile(source, str(ROOT / 'scripts/guard_mcp_per_call_risk_prototype.py'), 'exec'), module.__dict__)


def grant_callback_witness(enabled: bool) -> dict:
    with TemporaryDirectory(prefix='grant-', dir=OUT) as directory, pytest.MonkeyPatch.context() as patch:
        proxy, messages, marker = _session(Path(directory))
        proxy.config = replace(proxy.config, artifact_actions={})
        prototype = module.PerCallRiskPrototype()
        restore = module.install_adapter(runtime_mcp, prototype) if enabled else lambda: None
        original_grant = proxy.store.read_local_mcp_grant
        original_saved = proxy.store.resolve_policy_decision_lookup_with_memory_pattern
        original_kernel = calls._build_tool_call_hash_for_categories
        captured = {}
        trace = []

        def hash_kernel(artifact, arguments, **kwargs):
            result = original_kernel(artifact, arguments, **kwargs)
            captured.update(artifact=artifact, arguments=arguments, kwargs=kwargs, hash=result)
            return result

        def grant(*args, **kwargs):
            result = original_grant(*args, **kwargs)
            artifact = captured['artifact']
            proxy.config.artifact_actions[artifact.artifact_id] = 'block'
            trace.append({'event': 'grant_callback_changed_policy'})
            return result

        def saved(*args, **kwargs):
            fresh_hash = original_kernel(captured['artifact'], captured['arguments'], **captured['kwargs'])
            trace.append({'event': 'saved_lookup', 'received_hash': kwargs['artifact_hash'],
                          'fresh_hash': fresh_hash, 'stale_hash': kwargs['artifact_hash'] != fresh_hash})
            return original_saved(*args, **kwargs)

        patch.setattr(calls, '_build_tool_call_hash_for_categories', hash_kernel)
        patch.setattr(proxy.store, 'read_local_mcp_grant', grant)
        patch.setattr(proxy.store, 'resolve_policy_decision_lookup_with_memory_pattern', saved)
        try:
            result = proxy.run_session(messages)
            return {'prototype_enabled': enabled, 'trace': trace, 'child_received': marker.exists(),
                    'last_event': result['events'][-1], 'prototype_counters': dict(prototype.counters)}
        finally:
            restore()


def metaclass_witness() -> dict:
    callbacks = []

    class HostileMeta(type):
        def __eq__(cls, other):
            callbacks.append(type.__getattribute__(other, '__name__') if type(other) is type else type(other).__name__)
            return False

    class Hostile(metaclass=HostileMeta):
        pass

    try:
        module._digest(Hostile())
        outcome = 'accepted'
    except module._UnsupportedAuthorityError:
        outcome = 'unsupported'
    return {'outcome': outcome, 'custom_equality_calls': len(callbacks), 'callback_trace': callbacks}


def catalog_order_witness() -> dict:
    with TemporaryDirectory(prefix='catalog-', dir=OUT) as directory, pytest.MonkeyPatch.context() as patch:
        proxy, _messages, _marker = _session(Path(directory))
        proxy._tool_catalog = {'safe_echo': {'description': 'ordinary', 'inputSchema': {'type': 'object'}}}
        before = module._digest(proxy._tool_catalog).hex()
        prototype = module.PerCallRiskPrototype()
        restore = module.install_adapter(runtime_mcp, prototype)
        original_override = GuardConfig.resolve_action_override
        policy_calls = []

        def override(config, *args, **kwargs):
            result = original_override(config, *args, **kwargs)
            policy_calls.append(True)
            if len(policy_calls) == 1:
                definition = proxy._tool_catalog['safe_echo']
                description = definition.pop('description')
                definition['description'] = description
            return result

        patch.setattr(GuardConfig, 'resolve_action_override', override)
        try:
            result = proxy._resolve_tool_call_authority(tool_name='safe_echo', arguments={'text': 'ordinary'})
            return {'raw_catalog_binding_changed': before != module._digest(proxy._tool_catalog).hex(),
                    'completed': True, 'action': result.decision.action, 'prototype_counters': dict(prototype.counters)}
        finally:
            restore()


def working_directory_witness() -> dict:
    with TemporaryDirectory(prefix='cwd-', dir=OUT) as directory, pytest.MonkeyPatch.context() as patch:
        directory = Path(directory)
        first_cwd = directory / 'first'
        second_cwd = directory / 'second'
        first_cwd.mkdir()
        second_cwd.mkdir()
        patch.chdir(first_cwd)
        proxy, _messages, _marker = _session(directory)
        proxy.context = replace(proxy.context, workspace_dir=None)
        proxy.config = replace(proxy.config, workspace=None)
        prototype = module.PerCallRiskPrototype()
        restore = module.install_adapter(runtime_mcp, prototype)
        original_override = GuardConfig.resolve_action_override
        policy_calls = []

        def override(config, *args, **kwargs):
            result = original_override(config, *args, **kwargs)
            policy_calls.append(True)
            if len(policy_calls) == 1:
                patch.chdir(second_cwd)
            return result

        patch.setattr(GuardConfig, 'resolve_action_override', override)
        try:
            arguments = {'text': 'ordinary'}
            result = proxy._resolve_tool_call_authority(tool_name='safe_echo', arguments=arguments)
            fresh_hash = calls.build_tool_call_hash(result.artifact, arguments, workspace=Path.cwd(), config=proxy.config)
            return {'completed': True, 'cwd_changed': Path.cwd() == second_cwd,
                    'returned_hash_differs_from_current_authority': result.artifact_hash != fresh_hash,
                    'prototype_counters': dict(prototype.counters)}
        finally:
            restore()


report = {'schema': 'guard.rsp100-independent-review.witness.v1', 'performance_campaign': False,
          'prototype_source_sha256': hashlib.sha256(source).hexdigest(),
          'grant_callback_cases': [grant_callback_witness(False), grant_callback_witness(True)],
          'metaclass': metaclass_witness(), 'catalog_order': catalog_order_witness(),
          'working_directory': working_directory_witness()}
(OUT / 'witness-expanded.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))
