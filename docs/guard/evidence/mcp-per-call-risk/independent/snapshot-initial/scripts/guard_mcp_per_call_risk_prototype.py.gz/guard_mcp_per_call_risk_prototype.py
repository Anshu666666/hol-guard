"""Explicit per-invocation risk reuse prototype; never imported by production.

Only the default authority evaluator is substituted. The production request
owner, package classifier, notification flow and final writer stay in charge.
"""

from __future__ import annotations

import math
from collections import Counter
from dataclasses import fields, replace
from hashlib import sha256
from pathlib import Path, PosixPath, PurePosixPath, PureWindowsPath, WindowsPath

from codex_plugin_scanner.guard import mcp_tool_calls as calls
from codex_plugin_scanner.guard.adapters.base import HarnessContext
from codex_plugin_scanner.guard.config import GuardConfig
from codex_plugin_scanner.guard.mdm.contracts import (
    ManagedIntegrityTrust,
    ManagedNetworkPolicy,
    ManagedPolicy,
    ManagedUpdatePolicy,
)
from codex_plugin_scanner.guard.models import GuardArtifact
from codex_plugin_scanner.guard.proxy import framing, runtime_mcp, tool_call_binding
from codex_plugin_scanner.guard.proxy.tool_catalog import ToolCatalog
from codex_plugin_scanner.guard.runtime.mcp_protection import McpServerIdentity

_RECORD_TYPES = (
    GuardArtifact,
    GuardConfig,
    HarnessContext,
    ManagedPolicy,
    ManagedNetworkPolicy,
    ManagedUpdatePolicy,
    ManagedIntegrityTrust,
    McpServerIdentity,
)
_PATH_TYPES = (PosixPath, WindowsPath, PurePosixPath, PureWindowsPath)


class _UnsupportedAuthorityError(ValueError):
    """A deliberate unsupported-input decision before category reuse begins."""


def _changed():
    return framing.ProxyIoLimitError(source="per_call_risk", reason="tool_call_authority_changed")


def _digest(value):
    """Hash complete ordered typed values without a second container owner.

    The only record/Path types accepted are exact trusted implementation types.
    Private metadata, key bytes and managed settings are included directly;
    display/redaction projections never enter this private authority binding.
    """

    digest = sha256()

    def part(tag, data=b""):
        digest.update(tag)
        digest.update(len(data).to_bytes(8, "big"))
        digest.update(data)

    def visit(item):
        kind = type(item)
        if item is None:
            part(b"n")
        elif kind is bool:
            part(b"b", b"1" if item else b"0")
        elif kind is str:
            part(b"s", item.encode("utf-8"))
        elif kind is int:
            part(b"i", str(item).encode("ascii"))
        elif kind is float and math.isfinite(item):
            part(b"f", item.hex().encode("ascii"))
        elif kind is bytes:
            part(b"y", item)
        elif kind in (list, tuple):
            part(b"l" if kind is list else b"t", len(item).to_bytes(8, "big"))
            for child in item:
                visit(child)
        elif kind is dict:
            part(b"d", len(item).to_bytes(8, "big"))
            for key, child in item.items():
                if type(key) is not str:
                    raise _UnsupportedAuthorityError
                visit(key)
                visit(child)
        elif kind is frozenset:
            if any(type(child) is not str for child in item):
                raise _UnsupportedAuthorityError
            part(b"z", len(item).to_bytes(8, "big"))
            for child in sorted(item):
                visit(child)
        elif kind in _PATH_TYPES:
            part(b"p", kind.__name__.encode("ascii"))
            visit(str(item))
        elif kind in _RECORD_TYPES:
            part(b"r", kind.__name__.encode("ascii"))
            for record_field in fields(kind):
                visit(record_field.name)
                visit(object.__getattribute__(item, record_field.name))
        else:
            raise _UnsupportedAuthorityError

    visit(value)
    return digest.digest()


def _own_artifact(artifact):
    if type(artifact) is not GuardArtifact or type(artifact.args) is not tuple:
        raise _UnsupportedAuthorityError
    if any(type(value) is not str for value in artifact.args):
        raise _UnsupportedAuthorityError
    return replace(
        artifact,
        **{
            item.name: tool_call_binding._own_plain_json(getattr(artifact, item.name))
            for item in fields(GuardArtifact)
            if item.name != "args"
        },
    )


def _authority(proxy, config):
    catalog = proxy._tool_catalog
    if type(catalog) not in (dict, ToolCatalog):
        raise _UnsupportedAuthorityError
    if type(catalog) is dict:
        _digest(catalog)  # Reject custom callbacks before catalog normalization.
    return (
        (config,) if proxy.config is config else (config, proxy.config),
        proxy.command,
        proxy.context,
        proxy.harness,
        proxy.server_name,
        proxy.source_scope,
        proxy.config_path,
        proxy.transport,
        proxy.server_id,
        proxy.server_env_keys,
        proxy.server_identity,
        proxy._active_executable_identity,
        proxy._active_runtime_launch_identity,
        proxy._active_server_env_values_hash,
        proxy._active_server_identity,
        proxy._tool_catalog_generation,
        proxy._tool_catalog_state,
        runtime_mcp._tool_catalog_fingerprint(catalog, state=proxy._tool_catalog_state),
    )


class PerCallRiskPrototype:
    """Counters survive calls; private owners and facts never do."""

    def __init__(self):
        self.counters = Counter()

    def evaluate(self, proxy, *, artifact, arguments, config):
        binding = tool_call_binding.current_tool_call_binding()
        try:
            if type(config) is not GuardConfig:
                raise _UnsupportedAuthorityError
            if binding is not None:
                binding.check()
                if arguments is not binding.owned_message["params"].get("arguments"):
                    raise _changed()
                owned_arguments = arguments
                self.counters["existing_argument_owner"] += 1
            else:
                owned_arguments = tool_call_binding._own_plain_json(arguments)
                self.counters["new_argument_owner"] += 1
            owned_artifact = _own_artifact(artifact)
            original_input = _digest((artifact, None if binding is not None else arguments))
            owned_input = _digest((owned_artifact, None if binding is not None else owned_arguments))
            if original_input != owned_input:
                raise _changed()
            object_owners = (
                proxy.config,
                proxy.context,
                proxy.store,
                proxy._tool_catalog,
                proxy._current_config_provider,
            )
            authority = _digest(_authority(proxy, config))
        except (_UnsupportedAuthorityError, tool_call_binding._UnsupportedPlainJsonError):
            self.counters["unsupported_fallback"] += 1
            return None
        except (TypeError, ValueError, RecursionError, RuntimeError) as error:
            if isinstance(error, framing.ProxyIoLimitError):
                raise
            raise _changed() from error

        def check():
            try:
                current_owners = (
                    proxy.config,
                    proxy.context,
                    proxy.store,
                    proxy._tool_catalog,
                    proxy._current_config_provider,
                )
                if any(
                    current is not original for current, original in zip(current_owners, object_owners, strict=True)
                ):
                    raise _changed()
                if binding is not None:
                    binding.check()
                if (
                    _digest((artifact, None if binding is not None else arguments)) != original_input
                    or _digest((owned_artifact, None if binding is not None else owned_arguments)) != original_input
                    or _digest(_authority(proxy, config)) != authority
                ):
                    raise _changed()
            except (TypeError, ValueError, RecursionError, RuntimeError) as error:
                if isinstance(error, framing.ProxyIoLimitError):
                    raise
                raise _changed() from error

        categories = calls.tool_call_risk_categories(owned_artifact, owned_arguments)
        self.counters["category_derivations"] += 1
        artifact_hash = calls._build_tool_call_hash_for_categories(
            owned_artifact,
            owned_arguments,
            workspace=proxy.context.workspace_dir or Path.cwd(),
            config=config,
            risk_categories=categories,
        )
        # The first external policy callback occurs at the end of the hash
        # kernel. No prepared hash reaches policy/saved state until this check.
        check()
        configured_override = config.resolve_action_override(
            owned_artifact.harness, owned_artifact.artifact_id, owned_artifact.publisher
        )
        check()
        current = calls._evaluate_current_tool_call_for_categories(
            config=config,
            artifact=owned_artifact,
            arguments=owned_arguments,
            current_config_action=configured_override if configured_override is not None else config.default_action,
            risk_categories=categories,
        )
        check()
        decision = proxy._disable_saved_allow_without_complete_catalog(
            calls._evaluate_tool_call_with_current(
                store=proxy.store,
                config=config,
                artifact=owned_artifact,
                artifact_hash=artifact_hash,
                arguments=owned_arguments,
                current=current,
                claim_saved_approval=False,
            )
        )
        check()
        self.counters["completed_invocations"] += 1
        return owned_artifact, artifact_hash, decision


def install_adapter(runtime, prototype):
    """Explicit test-process substitution of the evaluator only."""

    original = runtime.RuntimeMcpGuardProxy._evaluate_tool_call_authority

    def evaluate(proxy, *, artifact, arguments, config):
        prepared = prototype.evaluate(proxy, artifact=artifact, arguments=arguments, config=config)
        if prepared is not None:
            return prepared
        return original(proxy, artifact=artifact, arguments=arguments, config=config)

    runtime.RuntimeMcpGuardProxy._evaluate_tool_call_authority = evaluate

    def restore():
        runtime.RuntimeMcpGuardProxy._evaluate_tool_call_authority = original

    return restore
