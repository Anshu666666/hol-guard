"""Explicit pytest-only installation; no benchmark/profile worker is launched."""

from __future__ import annotations

import hashlib
import importlib
import json
import sys
from pathlib import Path

from codex_plugin_scanner.guard.proxy import runtime_mcp

_state = {}


def pytest_addoption(parser):
    parser.addoption("--per-call-prototype-receipt", default=None)


def pytest_configure(config):
    root = Path(__file__).resolve().parents[1]
    script_root = str(root / "scripts")
    sys.path.insert(0, script_root)
    module = importlib.import_module("guard_mcp_per_call_risk_prototype")
    prototype = module.PerCallRiskPrototype()
    _state.update(prototype=prototype, restore=module.install_adapter(runtime_mcp, prototype), script_root=script_root)


def pytest_sessionfinish(session, exitstatus):
    destination = session.config.getoption("--per-call-prototype-receipt")
    if destination is None:
        return
    root = Path(__file__).resolve().parents[1]
    sources = [
        "src/codex_plugin_scanner/guard/proxy/runtime_mcp.py",
        "src/codex_plugin_scanner/guard/proxy/tool_call_binding.py",
        "src/codex_plugin_scanner/guard/mcp_tool_calls.py",
        "scripts/guard_mcp_per_call_risk_prototype.py",
        "tests/guard_mcp_per_call_prototype_plugin.py",
    ]
    receipt = {
        "schema": "guard.mcp-per-call-prototype.finite-tests.v1",
        "exit_status": int(exitstatus),
        "source_sha256": {name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in sources},
        "prototype_counters": dict(_state["prototype"].counters),
        "production_activation": False,
        "performance_campaign": False,
        "evaluator_only_substitution": True,
    }
    Path(destination).write_text(json.dumps(receipt, indent=2) + "\n")


def pytest_unconfigure(config):
    del config
    if _state:
        _state["restore"]()
        sys.path.remove(_state["script_root"])
        _state.clear()
