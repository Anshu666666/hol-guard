"""Finite source tests for an explicitly installed per-invocation prototype."""

from __future__ import annotations

import importlib
import json
from dataclasses import replace
from pathlib import Path

import pytest

from codex_plugin_scanner.guard import mcp_tool_calls as calls
from codex_plugin_scanner.guard.config import GuardConfig
from codex_plugin_scanner.guard.mdm.contracts import ManagedIntegrityTrust, ManagedPolicy
from codex_plugin_scanner.guard.proxy import framing, runtime_mcp

from .test_mcp_owned_preparation_pilot import _session


@pytest.fixture
def prototype(monkeypatch):
    monkeypatch.syspath_prepend(str(Path(__file__).resolve().parents[1] / "scripts"))
    module = importlib.import_module("guard_mcp_per_call_risk_prototype")
    candidate = module.PerCallRiskPrototype()
    restore = module.install_adapter(runtime_mcp, candidate)
    try:
        yield candidate
    finally:
        restore()


def test_one_invocation_derives_categories_and_signals_once(tmp_path, monkeypatch):
    proxy, messages, marker = _session(tmp_path)
    expected = json.loads(json.dumps(messages[-1]))
    phases = []
    original_categories = calls.tool_call_risk_categories
    original_signals = calls._tool_call_risk_signals_for_categories
    original_override = GuardConfig.resolve_action_override
    original_package = proxy._package_request_artifact

    def categories(*args, **kwargs):
        phases.append("categories")
        return original_categories(*args, **kwargs)

    def signals(*args, **kwargs):
        phases.append("signals")
        return original_signals(*args, **kwargs)

    def override(*args, **kwargs):
        phases.append("policy")
        return original_override(*args, **kwargs)

    def package(*args, **kwargs):
        phases.append("package")
        return original_package(*args, **kwargs)

    monkeypatch.setattr(calls, "tool_call_risk_categories", categories)
    monkeypatch.setattr(calls, "_tool_call_risk_signals_for_categories", signals)
    monkeypatch.setattr(GuardConfig, "resolve_action_override", override)
    monkeypatch.setattr(proxy, "_package_request_artifact", package)

    result = proxy.run_session(messages)

    assert json.loads(marker.read_text()) == expected
    assert result["responses"][-1]["result"]["content"][0]["text"] == "forwarded"
    assert phases == ["categories", "policy", "policy", "signals", "package"]


@pytest.mark.parametrize("stage", ["hash", "current"])
@pytest.mark.parametrize("mutation", ["config_replace", "config_map", "managed_bytes", "catalog_epoch", "catalog_sibling"])
def test_changed_authority_never_reaches_saved_lookup_or_child(tmp_path, monkeypatch, prototype, stage, mutation):
    proxy, messages, marker = _session(tmp_path)
    proxy.config = replace(
        proxy.config,
        artifact_actions={},
        managed_policy=ManagedPolicy(
            schema_version="synthetic",
            settings={},
            locked_settings=frozenset(),
            integrity_trust=ManagedIntegrityTrust(release_public_keys={"test-key": b"original-key"}),
        ),
    )
    callbacks = []
    original_override = GuardConfig.resolve_action_override

    def override(config, *args, **kwargs):
        result = original_override(config, *args, **kwargs)
        callbacks.append("policy")
        if len(callbacks) == (1 if stage == "hash" else 2):
            if mutation == "config_replace":
                proxy.config = replace(proxy.config)  # Even equal fields are a new current authority object.
            elif mutation == "config_map":
                config.artifact_actions["new-policy"] = "block"
            elif mutation == "managed_bytes":
                config.managed_policy.integrity_trust.release_public_keys["test-key"] = b"changed-key"
            elif mutation == "catalog_epoch":
                proxy._tool_catalog_generation += 1
            else:
                proxy._tool_catalog["sibling"] = {"description": "New tool", "inputSchema": {"type": "object"}}
        return result

    def saved_lookup(*args, **kwargs):
        pytest.fail("Changed authority reached saved lookup with an earlier hash")

    monkeypatch.setattr(GuardConfig, "resolve_action_override", override)
    monkeypatch.setattr(proxy.store, "resolve_policy_decision_lookup_with_memory_pattern", saved_lookup)

    result = proxy.run_session(messages)

    assert not marker.exists()
    assert callbacks == ["policy"] * (1 if stage == "hash" else 2)
    assert result["events"][-1]["reason_code"] == "tool_call_authority_changed"
    assert result["events"][-1]["session_terminal"] is True
    assert prototype.counters["category_derivations"] == 1
    assert prototype.counters["completed_invocations"] == 0


@pytest.mark.parametrize("mutation", ["original_arguments", "owned_arguments", "owned_artifact", "private_artifact", "command"])
def test_category_callback_changes_do_not_reuse_facts(tmp_path, monkeypatch, prototype, mutation):
    proxy, messages, marker = _session(tmp_path)
    original_categories = calls.tool_call_risk_categories

    def categories(artifact, arguments):
        result = original_categories(artifact, arguments)
        if mutation == "original_arguments":
            messages[-1]["params"]["arguments"]["text"] = "changed"
        elif mutation == "owned_arguments":
            arguments["text"] = "changed"
        elif mutation == "owned_artifact":
            artifact.metadata["tool_description"] = "Changed"
        elif mutation == "private_artifact":
            artifact.runtime_private_metadata["private-binding"] = "Changed"
        else:
            proxy.command.append("changed")
        return result

    monkeypatch.setattr(calls, "tool_call_risk_categories", categories)

    result = proxy.run_session(messages)

    assert not marker.exists()
    assert result["events"][-1]["reason_code"] in {"tool_call_request_changed", "tool_call_authority_changed"}
    assert result["events"][-1]["session_terminal"] is True
    assert prototype.counters["category_derivations"] == 1
    assert prototype.counters["completed_invocations"] == 0


def test_each_authority_call_derives_fresh_facts(tmp_path, prototype):
    proxy, _messages, _marker = _session(tmp_path)
    arguments = {"text": "ordinary"}
    first = proxy._resolve_tool_call_authority(tool_name="safe_echo", arguments=arguments)
    second = proxy._resolve_tool_call_authority(tool_name="safe_echo", arguments=arguments)
    assert second == first
    assert prototype.counters["category_derivations"] == 2
    proxy.config = replace(proxy.config, default_action="block")
    strict = proxy._resolve_tool_call_authority(tool_name="safe_echo", arguments=arguments)
    assert strict.decision.action == "block"
    assert strict.artifact_hash != first.artifact_hash
    proxy._tool_catalog_generation += 1
    proxy._tool_catalog["sibling"] = {"description": "Changed sibling", "inputSchema": {"type": "object"}}
    catalog = proxy._resolve_tool_call_authority(tool_name="safe_echo", arguments=arguments)
    assert catalog.artifact_hash != strict.artifact_hash
    arguments["text"] = "cat .env"
    changed = proxy._resolve_tool_call_authority(tool_name="safe_echo", arguments=arguments)
    assert changed.artifact_hash != catalog.artifact_hash
    assert "secret_access" in changed.decision.risk_categories
    assert prototype.counters["category_derivations"] == 5
    assert prototype.counters["completed_invocations"] == 5
    assert not hasattr(changed, "risk_facts")
    assert set(prototype.__dict__) == {"counters"}


def test_unbound_capture_failure_is_terminal(tmp_path, monkeypatch, prototype):
    module = importlib.import_module("guard_mcp_per_call_risk_prototype")
    proxy, _messages, _marker = _session(tmp_path)
    original = module.tool_call_binding._own_plain_json
    arguments = {"nested": [False], "text": "original"}
    mutated = []

    def own(value):
        if value is False and not mutated:
            arguments["new"] = True
            mutated.append(True)
        return original(value)

    monkeypatch.setattr(module.tool_call_binding, "_own_plain_json", own)
    with pytest.raises(framing.ProxyIoLimitError, match="tool_call_authority_changed"):
        proxy._resolve_tool_call_authority(tool_name="safe_echo", arguments=arguments)
    assert prototype.counters["unsupported_fallback"] == 0
