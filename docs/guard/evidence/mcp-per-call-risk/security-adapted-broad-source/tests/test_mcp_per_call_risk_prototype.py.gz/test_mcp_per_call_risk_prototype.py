"""Finite source tests for an explicitly installed per-invocation prototype."""

from __future__ import annotations

import importlib
import json
import sys
from dataclasses import replace
from pathlib import Path

import pytest

from codex_plugin_scanner.guard import mcp_tool_calls as calls
from codex_plugin_scanner.guard.config import GuardConfig
from codex_plugin_scanner.guard.mdm.contracts import ManagedIntegrityTrust, ManagedPolicy
from codex_plugin_scanner.guard.proxy import framing, runtime_mcp

from .test_mcp_owned_preparation_pilot import _session


@pytest.fixture
def original_evaluator():
    return runtime_mcp.RuntimeMcpGuardProxy._evaluate_tool_call_authority


@pytest.fixture
def prototype(monkeypatch, original_evaluator):
    del original_evaluator  # Capture the reference before explicit installation.
    monkeypatch.syspath_prepend(str(Path(__file__).resolve().parents[1] / "scripts"))
    module = importlib.import_module("guard_mcp_per_call_risk_prototype")
    candidate = module.PerCallRiskPrototype()
    restore = module.install_adapter(runtime_mcp, candidate)
    try:
        yield candidate
    finally:
        restore()


def test_one_invocation_derives_categories_and_signals_once(tmp_path, monkeypatch, prototype):
    proxy, messages, marker = _session(tmp_path)
    expected = json.loads(json.dumps(messages[-1]))
    phases = []
    original_categories = calls.tool_call_risk_categories
    original_signals = calls._tool_call_risk_signals_for_categories
    original_override = GuardConfig.resolve_action_override
    original_package = proxy._package_request_artifact

    def categories(*args, **kwargs):
        phases.append("categories")
        return original_categories(*args, **kwargs)

    def signals(*args, **kwargs):
        phases.append("signals")
        return original_signals(*args, **kwargs)

    def override(*args, **kwargs):
        phases.append("policy")
        return original_override(*args, **kwargs)

    def package(*args, **kwargs):
        phases.append("package")
        return original_package(*args, **kwargs)

    monkeypatch.setattr(calls, "tool_call_risk_categories", categories)
    monkeypatch.setattr(calls, "_tool_call_risk_signals_for_categories", signals)
    monkeypatch.setattr(GuardConfig, "resolve_action_override", override)
    monkeypatch.setattr(proxy, "_package_request_artifact", package)

    result = proxy.run_session(messages)

    assert json.loads(marker.read_text()) == expected
    assert result["responses"][-1]["result"]["content"][0]["text"] == "forwarded"
    assert phases == ["categories", "policy", "policy", "signals", "package"]
    assert prototype.counters["existing_argument_owner"] == 1
    assert prototype.counters["new_argument_owner"] == 0


@pytest.mark.parametrize("stage", ["hash", "current"])
@pytest.mark.parametrize(
    "mutation", ["config_replace", "config_map", "managed_bytes", "catalog_epoch", "catalog_sibling"]
)
def test_changed_authority_never_reaches_saved_lookup_or_child(tmp_path, monkeypatch, prototype, stage, mutation):
    proxy, messages, marker = _session(tmp_path)
    proxy.config = replace(
        proxy.config,
        artifact_actions={},
        managed_policy=ManagedPolicy(
            schema_version="synthetic",
            settings={},
            locked_settings=frozenset(),
            integrity_trust=ManagedIntegrityTrust(release_public_keys={"test-key": b"original-key"}),
        ),
    )
    callbacks = []
    original_override = GuardConfig.resolve_action_override

    def override(config, *args, **kwargs):
        result = original_override(config, *args, **kwargs)
        callbacks.append("policy")
        if len(callbacks) == (1 if stage == "hash" else 2):
            if mutation == "config_replace":
                proxy.config = replace(proxy.config)  # Even equal fields are a new current authority object.
            elif mutation == "config_map":
                config.artifact_actions["new-policy"] = "block"
            elif mutation == "managed_bytes":
                config.managed_policy.integrity_trust.release_public_keys["test-key"] = b"changed-key"
            elif mutation == "catalog_epoch":
                proxy._tool_catalog_generation += 1
            else:
                proxy._tool_catalog["sibling"] = {"description": "New tool", "inputSchema": {"type": "object"}}
        return result

    def saved_lookup(*args, **kwargs):
        pytest.fail("Changed authority reached saved lookup with an earlier hash")

    monkeypatch.setattr(GuardConfig, "resolve_action_override", override)
    monkeypatch.setattr(proxy.store, "resolve_policy_decision_lookup_with_memory_pattern", saved_lookup)

    result = proxy.run_session(messages)

    assert not marker.exists()
    assert callbacks == ["policy"] * (1 if stage == "hash" else 2)
    assert result["events"][-1]["reason_code"] == "tool_call_authority_changed"
    assert result["events"][-1]["session_terminal"] is True
    assert prototype.counters["category_derivations"] == 1
    assert prototype.counters["completed_invocations"] == 0


@pytest.mark.parametrize(
    "mutation", ["original_arguments", "owned_arguments", "owned_artifact", "private_artifact", "command"]
)
def test_category_callback_changes_do_not_reuse_facts(tmp_path, monkeypatch, prototype, mutation):
    proxy, messages, marker = _session(tmp_path)
    original_categories = calls.tool_call_risk_categories

    def categories(artifact, arguments):
        result = original_categories(artifact, arguments)
        if mutation == "original_arguments":
            messages[-1]["params"]["arguments"]["text"] = "changed"
        elif mutation == "owned_arguments":
            arguments["text"] = "changed"
        elif mutation == "owned_artifact":
            artifact.metadata["tool_description"] = "Changed"
        elif mutation == "private_artifact":
            artifact.runtime_private_metadata["private-binding"] = "Changed"
        else:
            proxy.command.append("changed")
        return result

    monkeypatch.setattr(calls, "tool_call_risk_categories", categories)

    result = proxy.run_session(messages)

    assert not marker.exists()
    assert result["events"][-1]["reason_code"] in {"tool_call_request_changed", "tool_call_authority_changed"}
    assert result["events"][-1]["session_terminal"] is True
    assert prototype.counters["category_derivations"] == 1
    assert prototype.counters["completed_invocations"] == 0


def test_each_authority_call_derives_fresh_facts(tmp_path, prototype):
    proxy, _messages, _marker = _session(tmp_path)
    arguments = {"text": "ordinary"}
    first = proxy._resolve_tool_call_authority(tool_name="safe_echo", arguments=arguments)
    second = proxy._resolve_tool_call_authority(tool_name="safe_echo", arguments=arguments)
    assert second == first
    assert prototype.counters["category_derivations"] == 2
    proxy.config = replace(proxy.config, default_action="block")
    strict = proxy._resolve_tool_call_authority(tool_name="safe_echo", arguments=arguments)
    assert strict.decision.action == "block"
    assert strict.artifact_hash != first.artifact_hash
    proxy._tool_catalog_generation += 1
    proxy._tool_catalog["sibling"] = {"description": "Changed sibling", "inputSchema": {"type": "object"}}
    catalog = proxy._resolve_tool_call_authority(tool_name="safe_echo", arguments=arguments)
    assert catalog.artifact_hash != strict.artifact_hash
    arguments["text"] = "cat .env"
    changed = proxy._resolve_tool_call_authority(tool_name="safe_echo", arguments=arguments)
    assert changed.artifact_hash != catalog.artifact_hash
    assert "secret_access" in changed.decision.risk_categories
    assert prototype.counters["category_derivations"] == 5
    assert prototype.counters["completed_invocations"] == 5
    assert not hasattr(changed, "risk_facts")
    assert set(prototype.__dict__) == {"counters", "_kernels"}


def test_unbound_capture_failure_is_terminal(tmp_path, monkeypatch, prototype):
    module = importlib.import_module("guard_mcp_per_call_risk_prototype")
    proxy, _messages, _marker = _session(tmp_path)
    original = module.tool_call_binding._own_plain_json
    arguments = {"nested": [False], "text": "original"}
    mutated = []

    def own(value):
        if value is False and not mutated:
            arguments["new"] = True
            mutated.append(True)
        return original(value)

    monkeypatch.setattr(module.tool_call_binding, "_own_plain_json", own)
    with pytest.raises(framing.ProxyIoLimitError, match="tool_call_authority_changed"):
        proxy._resolve_tool_call_authority(tool_name="safe_echo", arguments=arguments)
    assert prototype.counters["unsupported_fallback"] == 0


def test_store_callback_authority_change_does_not_escape_the_invocation(tmp_path, monkeypatch, prototype):
    proxy, messages, marker = _session(tmp_path)
    proxy.config = replace(proxy.config, artifact_actions={})
    original = proxy.store.resolve_policy_decision_lookup_with_memory_pattern
    lookups = []

    def lookup(*args, **kwargs):
        result = original(*args, **kwargs)
        lookups.append(True)
        proxy.config.artifact_actions["changed"] = "block"
        return result

    monkeypatch.setattr(proxy.store, "resolve_policy_decision_lookup_with_memory_pattern", lookup)

    result = proxy.run_session(messages)

    assert lookups == [True]
    assert not marker.exists()
    assert proxy.store.list_receipts(limit=10) == []
    assert result["events"][-1]["reason_code"] == "tool_call_authority_changed"
    assert prototype.counters["completed_invocations"] == 0


def test_unsupported_custom_arguments_preserve_original_callback_order(
    tmp_path, monkeypatch, prototype, original_evaluator
):
    proxy, _messages, _marker = _session(tmp_path)
    trace = []
    original_override = GuardConfig.resolve_action_override

    class ObservedDict(dict):
        def items(self):
            trace.append("custom_items")
            return super().items()

    def override(*args, **kwargs):
        trace.append("policy")
        return original_override(*args, **kwargs)

    monkeypatch.setattr(GuardConfig, "resolve_action_override", override)
    arguments = ObservedDict(text="ordinary")
    # Restore only the explicit adapter for the reference call. No product
    # boundary is bypassed, and the same fallback callbacks execute afterward.
    current_evaluator = runtime_mcp.RuntimeMcpGuardProxy._evaluate_tool_call_authority
    monkeypatch.setattr(runtime_mcp.RuntimeMcpGuardProxy, "_evaluate_tool_call_authority", original_evaluator)
    expected = proxy._resolve_tool_call_authority(tool_name="safe_echo", arguments=arguments)
    expected_trace = list(trace)
    trace.clear()
    monkeypatch.setattr(runtime_mcp.RuntimeMcpGuardProxy, "_evaluate_tool_call_authority", current_evaluator)

    actual = proxy._resolve_tool_call_authority(tool_name="safe_echo", arguments=arguments)

    assert actual == expected
    assert trace == expected_trace
    assert prototype.counters["unsupported_fallback"] == 1
    assert prototype.counters["category_derivations"] == 0


@pytest.mark.parametrize(
    ("before", "after"),
    [(True, 1), (1, 1.0), (0.0, -0.0), ([1], (1,)), ({"a": 1, "b": 2}, {"b": 2, "a": 1})],
)
def test_private_authority_digest_preserves_exact_types_and_order(prototype, before, after):
    module = importlib.import_module("guard_mcp_per_call_risk_prototype")
    assert module._digest(before) != module._digest(after)


def test_private_authority_digest_rejects_custom_callbacks(prototype):
    module = importlib.import_module("guard_mcp_per_call_risk_prototype")
    callbacks = []

    class HostileDict(dict):
        def items(self):
            callbacks.append("items")
            raise AssertionError

    with pytest.raises(module._UnsupportedAuthorityError):
        module._digest(HostileDict(value="private"))
    assert callbacks == []


def test_private_authority_digest_rejects_custom_type_equality(prototype):
    module = importlib.import_module("guard_mcp_per_call_risk_prototype")
    callbacks = []

    class HostileMeta(type):
        def __eq__(cls, other):
            callbacks.append(other)
            return False

    class Hostile(metaclass=HostileMeta):
        pass

    with pytest.raises(module._UnsupportedAuthorityError):
        module._digest(Hostile())
    assert callbacks == []


@pytest.mark.parametrize("catalog_kind", ["dict", "owned_catalog"])
def test_exact_catalog_order_change_aborts_before_saved_lookup(tmp_path, monkeypatch, prototype, catalog_kind):
    proxy, _messages, _marker = _session(tmp_path)
    definition = {"description": "ordinary", "inputSchema": {"type": "object"}}
    if catalog_kind == "dict":
        proxy._tool_catalog = {"safe_echo": definition}
    else:
        proxy._tool_catalog["safe_echo"] = definition
    original_override = GuardConfig.resolve_action_override
    callbacks = []

    def override(config, *args, **kwargs):
        result = original_override(config, *args, **kwargs)
        callbacks.append("policy")
        if len(callbacks) == 1:
            value = proxy._tool_catalog["safe_echo"]
            description = value.pop("description")
            value["description"] = description
            proxy._tool_catalog["safe_echo"] = value
        return result

    def saved_lookup(*args, **kwargs):
        pytest.fail("Changed exact catalog reached saved lookup")

    monkeypatch.setattr(GuardConfig, "resolve_action_override", override)
    monkeypatch.setattr(proxy.store, "resolve_policy_decision_lookup_with_memory_pattern", saved_lookup)
    with pytest.raises(framing.ProxyIoLimitError, match="tool_call_authority_changed"):
        proxy._resolve_tool_call_authority(tool_name="safe_echo", arguments={"text": "ordinary"})
    assert callbacks == ["policy"]
    assert prototype.counters["completed_invocations"] == 0


@pytest.mark.parametrize("workspace_kind", ["implicit_cwd", "relative_path"])
def test_effective_workspace_change_aborts_before_saved_lookup(tmp_path, monkeypatch, prototype, workspace_kind):
    first = tmp_path / "first"
    second = tmp_path / "second"
    first.mkdir()
    second.mkdir()
    monkeypatch.chdir(first)
    proxy, _messages, _marker = _session(tmp_path)
    proxy.context = replace(proxy.context, workspace_dir=None if workspace_kind == "implicit_cwd" else Path("."))
    proxy.config = replace(proxy.config, workspace=None)
    original_override = GuardConfig.resolve_action_override
    callbacks = []

    def override(config, *args, **kwargs):
        result = original_override(config, *args, **kwargs)
        callbacks.append("policy")
        if len(callbacks) == 1:
            monkeypatch.chdir(second)
        return result

    def saved_lookup(*args, **kwargs):
        pytest.fail("Changed effective workspace reached saved lookup with an earlier hash")

    monkeypatch.setattr(GuardConfig, "resolve_action_override", override)
    monkeypatch.setattr(proxy.store, "resolve_policy_decision_lookup_with_memory_pattern", saved_lookup)
    with pytest.raises(framing.ProxyIoLimitError, match="tool_call_authority_changed"):
        proxy._resolve_tool_call_authority(tool_name="safe_echo", arguments={"text": "ordinary"})
    assert callbacks == ["policy"]
    assert prototype.counters["completed_invocations"] == 0


@pytest.mark.parametrize("kernel", ["build_tool_call_hash", "evaluate_tool_call", "private_check"])
@pytest.mark.parametrize("timing", ["before_construction", "after_construction"])
def test_custom_semantic_boundaries_keep_original_trace_before_any_preparation(
    tmp_path, monkeypatch, original_evaluator, kernel, timing
):
    monkeypatch.syspath_prepend(str(Path(__file__).resolve().parents[1] / "scripts"))
    module = importlib.import_module("guard_mcp_per_call_risk_prototype")
    proxy, _messages, _marker = _session(tmp_path)
    candidate = module.PerCallRiskPrototype() if timing == "after_construction" else None
    trace = []
    if kernel == "private_check":
        original = proxy._check_tool_call_preparation

        def observed(*args, **kwargs):
            trace.append(kernel)
            return original(*args, **kwargs)

        monkeypatch.setattr(proxy, "_check_tool_call_preparation", observed)
    else:
        original = getattr(runtime_mcp, kernel)

        def observed(*args, **kwargs):
            trace.append(kernel)
            return original(*args, **kwargs)

        monkeypatch.setattr(runtime_mcp, kernel, observed)
        monkeypatch.setattr(calls, kernel, observed)
    if candidate is None:
        candidate = module.PerCallRiskPrototype()
    assert runtime_mcp.RuntimeMcpGuardProxy._evaluate_tool_call_authority is original_evaluator
    expected = proxy._resolve_tool_call_authority(tool_name="safe_echo", arguments={"text": "ordinary"})
    expected_trace = list(trace)
    trace.clear()
    restore = module.install_adapter(runtime_mcp, candidate)
    try:
        actual = proxy._resolve_tool_call_authority(tool_name="safe_echo", arguments={"text": "ordinary"})
    finally:
        restore()
    assert actual == expected
    assert trace == expected_trace == [kernel] * (3 if kernel == "private_check" else 1)
    assert dict(candidate.counters) == {"compatibility_fallback": 1}


def test_custom_terminal_evaluator_keeps_actual_no_forward(tmp_path, monkeypatch, prototype):
    proxy, messages, marker = _session(tmp_path)
    original = runtime_mcp.evaluate_tool_call
    callbacks = []

    def blocked(*args, **kwargs):
        callbacks.append("custom_terminal_policy")
        return replace(original(*args, **kwargs), action="block", source="custom-terminal-policy")

    monkeypatch.setattr(runtime_mcp, "evaluate_tool_call", blocked)
    result = proxy.run_session(messages)
    assert not marker.exists()
    assert callbacks == ["custom_terminal_policy"]
    assert result["events"][-1]["policy_action"] == "block"
    assert dict(prototype.counters) == {"compatibility_fallback": 1}


def test_default_private_hook_retains_original_policy_interleaving(
    tmp_path, monkeypatch, prototype, original_evaluator
):
    proxy, _messages, _marker = _session(tmp_path)
    current_evaluator = runtime_mcp.RuntimeMcpGuardProxy._evaluate_tool_call_authority
    check_code = runtime_mcp.RuntimeMcpGuardProxy._check_tool_call_preparation.__code__
    original_override = GuardConfig.resolve_action_override
    trace = []

    def override(*args, **kwargs):
        trace.append("policy")
        return original_override(*args, **kwargs)

    def profile(frame, event, _arg):
        if event == "call" and frame.f_code is check_code:
            trace.append("preparation")

    monkeypatch.setattr(GuardConfig, "resolve_action_override", override)
    previous_profile = sys.getprofile()
    try:
        sys.setprofile(profile)
        monkeypatch.setattr(runtime_mcp.RuntimeMcpGuardProxy, "_evaluate_tool_call_authority", original_evaluator)
        expected = proxy._resolve_tool_call_authority(tool_name="safe_echo", arguments={"text": "ordinary"})
        expected_trace = list(trace)
        trace.clear()
        monkeypatch.setattr(runtime_mcp.RuntimeMcpGuardProxy, "_evaluate_tool_call_authority", current_evaluator)
        actual = proxy._resolve_tool_call_authority(tool_name="safe_echo", arguments={"text": "ordinary"})
    finally:
        sys.setprofile(previous_profile)

    assert actual == expected
    assert trace == expected_trace == ["preparation", "policy", "preparation", "policy", "preparation"]
    assert prototype.counters["completed_invocations"] == 1
    assert prototype.counters["compatibility_fallback"] == 0


@pytest.mark.parametrize("constant_index", [0, 1])
def test_substituted_function_constants_do_not_run_equality_during_kernel_selection(
    tmp_path, monkeypatch, constant_index
):
    del tmp_path
    monkeypatch.syspath_prepend(str(Path(__file__).resolve().parents[1] / "scripts"))
    module = importlib.import_module("guard_mcp_per_call_risk_prototype")
    callbacks = []

    class HostileMeta(type):
        def __eq__(cls, other):
            callbacks.append("constant_type_equality")
            return False

    class HostileConstant(metaclass=HostileMeta):
        def __eq__(self, other):
            callbacks.append("constant_equality")
            return False

    function = calls.build_tool_call_hash
    changed_constants = list(function.__code__.co_consts)
    changed_constants[constant_index] = HostileConstant()
    changed_code = function.__code__.replace(co_consts=tuple(changed_constants))
    monkeypatch.setattr(function, "__code__", changed_code)

    candidate = module.PerCallRiskPrototype()

    assert callbacks == []
    assert candidate._kernels[0] is None


@pytest.mark.parametrize("kernel", ["build_tool_call_hash", "evaluate_tool_call", "private_check"])
def test_mid_invocation_semantic_boundary_replacement_aborts(tmp_path, monkeypatch, prototype, kernel):
    proxy, messages, marker = _session(tmp_path)
    original_override = GuardConfig.resolve_action_override
    callbacks = []

    def changed(*args, **kwargs):
        pytest.fail("A replaced semantic boundary ran with earlier prepared facts")

    def override(config, *args, **kwargs):
        result = original_override(config, *args, **kwargs)
        callbacks.append("policy")
        if len(callbacks) == 1:
            if kernel == "private_check":
                monkeypatch.setattr(proxy, "_check_tool_call_preparation", changed)
            else:
                monkeypatch.setattr(runtime_mcp, kernel, changed)
        return result

    monkeypatch.setattr(GuardConfig, "resolve_action_override", override)
    result = proxy.run_session(messages)
    assert not marker.exists()
    assert callbacks == ["policy"]
    assert result["events"][-1]["reason_code"] == "tool_call_authority_changed"
    assert prototype.counters["compatibility_fallback"] == 0
    assert prototype.counters["category_derivations"] == 1
    assert prototype.counters["completed_invocations"] == 0


def test_grant_callback_change_aborts_before_earlier_hash_reaches_saved_lookup(tmp_path, monkeypatch, prototype):
    proxy, messages, marker = _session(tmp_path)
    proxy.config = replace(proxy.config, artifact_actions={})
    original_grant = proxy.store.read_local_mcp_grant
    grants = []
    lookups = []

    def grant(*args, **kwargs):
        result = original_grant(*args, **kwargs)
        grants.append(True)
        proxy.config.artifact_actions["changed-during-grant"] = "block"
        return result

    def saved_lookup(*args, **kwargs):
        lookups.append(kwargs["artifact_hash"])
        pytest.fail("A changed authority reached saved lookup with an earlier prepared hash")

    monkeypatch.setattr(proxy.store, "read_local_mcp_grant", grant)
    monkeypatch.setattr(proxy.store, "resolve_policy_decision_lookup_with_memory_pattern", saved_lookup)
    result = proxy.run_session(messages)
    assert grants == [True]
    assert lookups == []
    assert not marker.exists()
    assert result["events"][-1]["reason_code"] == "tool_call_authority_changed"
    assert prototype.counters["completed_invocations"] == 0
