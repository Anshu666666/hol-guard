"""Explicit per-invocation risk reuse prototype; never imported by production.

Only the default authority evaluator is substituted. The production request
owner, package classifier, notification flow and final writer stay in charge.
"""

from __future__ import annotations

import math
from collections import Counter
from dataclasses import fields, replace
from hashlib import sha256
from inspect import getattr_static
from pathlib import Path, PosixPath, PurePosixPath, PureWindowsPath, WindowsPath
from types import CodeType, FunctionType

from codex_plugin_scanner.guard import mcp_tool_calls as calls
from codex_plugin_scanner.guard.adapters.base import HarnessContext
from codex_plugin_scanner.guard.config import GuardConfig
from codex_plugin_scanner.guard.mcp_authority_binding import current_mcp_authority_check
from codex_plugin_scanner.guard.mdm.contracts import (
    ManagedIntegrityTrust,
    ManagedNetworkPolicy,
    ManagedPolicy,
    ManagedUpdatePolicy,
)
from codex_plugin_scanner.guard.models import GuardArtifact
from codex_plugin_scanner.guard.proxy import framing, runtime_mcp, tool_call_binding
from codex_plugin_scanner.guard.proxy.tool_catalog import ToolCatalog
from codex_plugin_scanner.guard.runtime.mcp_protection import McpServerIdentity

_RECORD_TYPES = (
    GuardArtifact,
    GuardConfig,
    HarnessContext,
    ManagedPolicy,
    ManagedNetworkPolicy,
    ManagedUpdatePolicy,
    ManagedIntegrityTrust,
    McpServerIdentity,
)
_PATH_TYPES = (PosixPath, WindowsPath, PurePosixPath, PureWindowsPath)
_KNOWN_SOURCE_HASHES = {
    calls: "ecfad2ddcfe670918eef18c20e59e519d30b936a69efdce12e33744c750f080f",
    runtime_mcp: "ebcf41ff57896d4f4042fa4e4a8c40951d8b97d0805ef59ef186a0a213a6794d",
}


class _UnsupportedAuthorityError(ValueError):
    """A deliberate unsupported-input decision before category reuse begins."""


def _changed():
    return framing.ProxyIoLimitError(source="per_call_risk", reason="tool_call_authority_changed")


def _digest(value):
    """Hash complete ordered typed values without a second container owner.

    The only record/Path types accepted are exact trusted implementation types.
    Private metadata, key bytes and managed settings are included directly;
    display/redaction projections never enter this private authority binding.
    """

    digest = sha256()

    def part(tag, data=b""):
        digest.update(tag)
        digest.update(len(data).to_bytes(8, "big"))
        digest.update(data)

    def visit(item):
        kind = type(item)
        if item is None:
            part(b"n")
        elif kind is bool:
            part(b"b", b"1" if item else b"0")
        elif kind is str:
            part(b"s", item.encode("utf-8"))
        elif kind is int:
            part(b"i", str(item).encode("ascii"))
        elif kind is float and math.isfinite(item):
            part(b"f", item.hex().encode("ascii"))
        elif kind is bytes:
            part(b"y", item)
        elif kind is list or kind is tuple:
            part(b"l" if kind is list else b"t", len(item).to_bytes(8, "big"))
            for child in item:
                visit(child)
        elif kind is dict:
            part(b"d", len(item).to_bytes(8, "big"))
            for key, child in item.items():
                if type(key) is not str:
                    raise _UnsupportedAuthorityError
                visit(key)
                visit(child)
        elif kind is frozenset:
            if any(type(child) is not str for child in item):
                raise _UnsupportedAuthorityError
            part(b"z", len(item).to_bytes(8, "big"))
            for child in sorted(item):
                visit(child)
        elif any(kind is known for known in _PATH_TYPES):
            part(b"p", kind.__name__.encode("ascii"))
            visit(str(item))
        elif (record_type := next((known for known in _RECORD_TYPES if kind is known), None)) is not None:
            part(b"r", kind.__name__.encode("ascii"))
            for record_field in fields(record_type):
                visit(record_field.name)
                visit(object.__getattribute__(item, record_field.name))
        else:
            raise _UnsupportedAuthorityError

    visit(value)
    return digest.digest()


def _own_artifact(artifact):
    if type(artifact) is not GuardArtifact or type(artifact.args) is not tuple:
        raise _UnsupportedAuthorityError
    if any(type(value) is not str for value in artifact.args):
        raise _UnsupportedAuthorityError
    return replace(
        artifact,
        **{
            item.name: tool_call_binding._own_plain_json(getattr(artifact, item.name))
            for item in fields(GuardArtifact)
            if item.name != "args"
        },
    )


def _authority(proxy, config, *, workspace=None):
    catalog = proxy._tool_catalog
    if type(catalog) is not dict and type(catalog) is not ToolCatalog:
        raise _UnsupportedAuthorityError
    # Bind the exact advertised storage as well as its canonical fingerprint.
    # ToolCatalog replacements retain their encoded definition order; its
    # derived fingerprint cache is not an independent advertised authority.
    raw_catalog = catalog if type(catalog) is dict else object.__getattribute__(catalog, "_definitions")
    raw_catalog_digest = _digest(raw_catalog)
    return (
        (config,) if proxy.config is config else (config, proxy.config),
        proxy.command,
        proxy.context,
        proxy.harness,
        proxy.server_name,
        proxy.source_scope,
        proxy.config_path,
        proxy.transport,
        proxy.server_id,
        proxy.server_env_keys,
        proxy.server_identity,
        proxy._active_executable_identity,
        proxy._active_runtime_launch_identity,
        proxy._active_server_env_values_hash,
        proxy._active_server_identity,
        proxy._tool_catalog_generation,
        proxy._tool_catalog_state,
        raw_catalog_digest,
        runtime_mcp._tool_catalog_fingerprint(catalog, state=proxy._tool_catalog_state),
        _effective_workspace(proxy) if workspace is None else workspace,
    )


def _effective_workspace(proxy):
    return calls._normalized_tool_call_workspace(proxy.context.workspace_dir or Path.cwd())


def _code_at(root, names):
    code = root
    for name in names:
        matching = [item for item in code.co_consts if type(item) is CodeType and item.co_name == name]
        if len(matching) != 1:
            return None
        code = matching[0]
    return code


def _known_function(module, names, expected_defaults):
    """Verify an implementation before retaining its identity for selection.

    Reading and compiling pinned source does not execute it. In particular,
    a public callable substituted before this script is imported cannot become
    a trusted kernel merely because it was the first callable we observed.
    """

    path = Path(module.__file__)
    source = path.read_bytes()
    if sha256(source).hexdigest() != _KNOWN_SOURCE_HASHES[module]:
        return None
    expected_code = _code_at(compile(source, str(path), "exec", dont_inherit=True), names)
    function = module
    for name in names:
        function = getattr_static(function, name)
    if type(function) is not FunctionType:
        return None
    observed_code = function.__code__
    if (
        function.__globals__ is not vars(module)
        or function.__closure__ is not None
        or function.__defaults__ is not None
        or observed_code != expected_code
    ):
        return None
    try:
        if _digest(function.__kwdefaults__) != _digest(expected_defaults):
            return None
    except _UnsupportedAuthorityError:
        return None
    return function, observed_code, _digest(expected_defaults)


def _same_function(function, known):
    if known is None or function is not known[0] or function.__code__ is not known[1]:
        return False
    if function.__defaults__ is not None or function.__closure__ is not None:
        return False
    try:
        return _digest(function.__kwdefaults__) == known[2]
    except (TypeError, ValueError, RecursionError, RuntimeError):
        return False


class PerCallRiskPrototype:
    """Counters survive calls; private owners and facts never do."""

    def __init__(self):
        self.counters = Counter()
        self._kernels = (
            _known_function(calls, ("build_tool_call_hash",), {"workspace": None, "config": None, "risk_facts": None}),
            _known_function(
                calls,
                ("evaluate_tool_call",),
                {"claim_saved_approval": True, "fresh_authority_provider": None, "risk_facts": None},
            ),
            _known_function(runtime_mcp, ("RuntimeMcpGuardProxy", "_check_tool_call_preparation"), None),
        )

    def _compatible(self, proxy):
        known_hash, known_evaluate, known_check = self._kernels
        return (
            _same_function(calls.build_tool_call_hash, known_hash)
            and _same_function(runtime_mcp.build_tool_call_hash, known_hash)
            and _same_function(calls.evaluate_tool_call, known_evaluate)
            and _same_function(runtime_mcp.evaluate_tool_call, known_evaluate)
            and _same_function(getattr_static(proxy, "_check_tool_call_preparation"), known_check)
        )

    def evaluate(self, proxy, *, artifact, arguments, config):
        # Select the original path before extra ownership, classification or
        # callbacks whenever an existing semantic extension point is custom.
        # The original evaluator retains its unconditional request/write guards.
        if not self._compatible(proxy):
            self.counters["compatibility_fallback"] += 1
            return None
        binding = tool_call_binding.current_tool_call_binding()
        # Retain the enclosing security check as an additional guard only.
        # Its presence is never proof of ownership for this invocation; all
        # input and authority captures below remain independently required.
        enclosing_check = current_mcp_authority_check()
        try:
            if type(config) is not GuardConfig:
                raise _UnsupportedAuthorityError
            if binding is not None:
                binding.check()
            if enclosing_check is not None:
                enclosing_check()
            if binding is not None:
                if arguments is not binding.owned_message["params"].get("arguments"):
                    raise _changed()
                owned_arguments = arguments
                self.counters["existing_argument_owner"] += 1
            else:
                owned_arguments = tool_call_binding._own_plain_json(arguments)
                self.counters["new_argument_owner"] += 1
            owned_artifact = _own_artifact(artifact)
            original_input = _digest((artifact, None if binding is not None else arguments))
            owned_input = _digest((owned_artifact, None if binding is not None else owned_arguments))
            if original_input != owned_input:
                raise _changed()
            object_owners = (
                proxy.config,
                proxy.context,
                proxy.store,
                proxy._tool_catalog,
                proxy._current_config_provider,
            )
            workspace = _effective_workspace(proxy)
            authority = _digest(_authority(proxy, config, workspace=workspace))
        except (_UnsupportedAuthorityError, tool_call_binding._UnsupportedPlainJsonError):
            self.counters["unsupported_fallback"] += 1
            return None
        except (TypeError, ValueError, RecursionError, RuntimeError) as error:
            if isinstance(error, framing.ProxyIoLimitError):
                raise
            raise _changed() from error

        def check(*, original_preparation_position=False):
            try:
                if not self._compatible(proxy):
                    raise _changed()
                current_owners = (
                    proxy.config,
                    proxy.context,
                    proxy.store,
                    proxy._tool_catalog,
                    proxy._current_config_provider,
                )
                if any(
                    current is not original for current, original in zip(current_owners, object_owners, strict=True)
                ):
                    raise _changed()
                if original_preparation_position:
                    proxy._check_tool_call_preparation()
                elif binding is not None:
                    binding.check()
                if enclosing_check is not None:
                    enclosing_check()
                if (
                    _digest((artifact, None if binding is not None else arguments)) != original_input
                    or _digest((owned_artifact, None if binding is not None else owned_arguments)) != original_input
                    or _digest(_authority(proxy, config)) != authority
                ):
                    raise _changed()
            except (TypeError, ValueError, RecursionError, RuntimeError) as error:
                if isinstance(error, framing.ProxyIoLimitError):
                    raise
                raise _changed() from error

        # Unsupported admission returns to the unchanged evaluator, which owns
        # all three preparation-hook calls for that path. The selected path
        # starts its first original hook only after admission succeeds.
        proxy._check_tool_call_preparation()
        categories = calls.tool_call_risk_categories(owned_artifact, owned_arguments)
        self.counters["category_derivations"] += 1
        artifact_hash = calls._build_tool_call_hash_for_categories(
            owned_artifact,
            owned_arguments,
            workspace=workspace,
            config=config,
            risk_categories=categories,
        )
        # The first external policy callback occurs at the end of the hash
        # kernel. No prepared hash reaches policy/saved state until this check.
        check(original_preparation_position=True)
        configured_override = config.resolve_action_override(
            owned_artifact.harness, owned_artifact.artifact_id, owned_artifact.publisher
        )
        check()
        current = calls._evaluate_current_tool_call_for_categories(
            config=config,
            artifact=owned_artifact,
            arguments=owned_arguments,
            current_config_action=configured_override if configured_override is not None else config.default_action,
            risk_categories=categories,
        )
        check()
        decision = proxy._disable_saved_allow_without_complete_catalog(
            calls._evaluate_tool_call_with_current(
                store=proxy.store,
                config=config,
                artifact=owned_artifact,
                artifact_hash=artifact_hash,
                arguments=owned_arguments,
                current=current,
                claim_saved_approval=False,
                authority_check=check,
            )
        )
        check(original_preparation_position=True)
        self.counters["completed_invocations"] += 1
        return owned_artifact, artifact_hash, decision


def install_adapter(runtime, prototype):
    """Explicit test-process substitution of the evaluator only."""

    original = runtime.RuntimeMcpGuardProxy._evaluate_tool_call_authority

    def evaluate(proxy, *, artifact, arguments, config):
        prepared = prototype.evaluate(proxy, artifact=artifact, arguments=arguments, config=config)
        if prepared is not None:
            return prepared
        return original(proxy, artifact=artifact, arguments=arguments, config=config)

    runtime.RuntimeMcpGuardProxy._evaluate_tool_call_authority = evaluate

    def restore():
        runtime.RuntimeMcpGuardProxy._evaluate_tool_call_authority = original

    return restore
