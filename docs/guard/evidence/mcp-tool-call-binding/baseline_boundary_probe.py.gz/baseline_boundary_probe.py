"""Finite, synthetic baseline B diagnosis; no pilot or production edit."""

from pathlib import Path
import datetime
import hashlib
import json
import os
import socket
import subprocess
import tempfile

from codex_plugin_scanner.guard import mcp_tool_calls as calls
from codex_plugin_scanner.guard.config import GuardConfig
from tests.test_mcp_owned_preparation_pilot import _session

ROOT = Path('/workspace/scratch/c25672eb4c10/refresh-lease-fix')
OUT = Path('/workspace/scratch/c25672eb4c10/rsp100-review')
SOURCES = ['src/codex_plugin_scanner/guard/mcp_tool_calls.py',
           'src/codex_plugin_scanner/guard/proxy/runtime_mcp.py',
           'src/codex_plugin_scanner/guard/proxy/framing.py',
           'tests/test_mcp_owned_preparation_pilot.py']

def hashes():
    return {p: hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in SOURCES}

def case(boundary):
    with tempfile.TemporaryDirectory(prefix='rsp100-baseline-',dir='/tmp') as name:
        proxy, messages, marker = _session(Path(name))
        proxy.command[-1] = proxy.command[-1].replace(
            "if method=='tools/call':", "if method not in {'initialize', 'tools/list'}:")
        counts = {'category_derivations':0, 'quiet_barriers':0, 'mutations':0}
        original_categories = calls.tool_call_risk_categories
        original_policy = GuardConfig.resolve_action_override
        original_drain = proxy._drain_and_validate_catalog_authority
        def categories(artifact, arguments):
            counts['category_derivations'] += 1
            return original_categories(artifact, arguments)
        def policy(config, *args, **kwargs):
            result = original_policy(config,*args,**kwargs)
            if boundary == 'policy_callback' and counts['mutations'] == 0:
                messages[-1]['method'] = 'ping'
                counts['mutations'] += 1
            return result
        def drain(**kwargs):
            result = original_drain(**kwargs)
            if kwargs.get('quiet_seconds') == 0.005:
                counts['quiet_barriers'] += 1
                if boundary == 'quiet_barrier':
                    messages[-1]['method'] = 'ping'
                    counts['mutations'] += 1
            return result
        calls.tool_call_risk_categories = categories
        GuardConfig.resolve_action_override = policy
        proxy._drain_and_validate_catalog_authority = drain
        try:
            result = proxy.run_session(messages)
        finally:
            calls.tool_call_risk_categories = original_categories
            GuardConfig.resolve_action_override = original_policy
        forwarded = json.loads(marker.read_text()) if marker.exists() else None
        return {'boundary':boundary, **counts,
                'forwarded':forwarded is not None,
                'forwarded_method':forwarded.get('method') if forwarded else None,
                'forwarded_id':forwarded.get('id') if forwarded else None,
                'last_event':result['events'][-1],
                'last_response':result['responses'][-1]}

before = hashes()
results = [case(name) for name in ['unchanged_control','policy_callback','quiet_barrier']]
assert results[0]['category_derivations'] == 2
assert results[0]['forwarded_method'] == 'tools/call'
assert results[0]['quiet_barriers'] == 1
assert results[1]['forwarded_method'] == results[2]['forwarded_method'] == 'ping'
assert results[1]['quiet_barriers'] == 0
assert results[2]['quiet_barriers'] == 1
socket_result = {}
try:
    channel = socket.socket(socket.AF_UNIX,socket.SOCK_STREAM)
except OSError as exc:
    socket_result = {'available':False,'errno':exc.errno,'error':str(exc)}
else:
    channel.close()
    socket_result = {'available':True}
after = hashes()
assert before == after
receipt = {'schema':'guard.rsp100.baseline-boundary-probe.v1',
           'checked_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
           'root':str(ROOT), 'commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
           'source_before':before,'source_after':after,'source_unchanged':before==after,
           'pilot_imported':False,'production_modified':False,'performance_campaign':False,
           'scope':'Three synthetic actual-stdio baseline sessions with only local callback instrumentation; no timing qualification.',
           'unix_stream_socket':socket_result,'cases':results}
(OUT/'baseline-boundary-probe.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
