"""Actual tool-bound forwarding rejects changed request bytes at the final fence."""

from __future__ import annotations

import json

import pytest

from codex_plugin_scanner.guard.config import GuardConfig
from codex_plugin_scanner.guard.proxy import framing

from .test_mcp_owned_preparation_pilot import _session


@pytest.mark.parametrize("boundary", ["policy", "quiet", "hostile_method", "owned_arguments", "encoder"])
def test_changed_tool_call_never_reaches_child(tmp_path, monkeypatch, boundary):
    proxy, messages, marker = _session(tmp_path)
    proxy.command[-1] = proxy.command[-1].replace(
        "if method=='tools/call':", "if method not in {'initialize', 'tools/list'}:"
    )
    callbacks = []

    class HostileMethod(str):
        def __eq__(self, other):
            callbacks.append("equality")
            raise AssertionError

        def __ne__(self, other):
            callbacks.append("inequality")
            raise AssertionError

        def __str__(self):
            callbacks.append("string")
            raise AssertionError

    if boundary == "policy":
        original = GuardConfig.resolve_action_override

        def policy(config, *args, **kwargs):
            result = original(config, *args, **kwargs)
            messages[-1]["method"] = "ping"
            return result

        monkeypatch.setattr(GuardConfig, "resolve_action_override", policy)
    elif boundary == "encoder":
        original = framing.encoded_line

        def encode(payload):
            if payload.get("method") == "tools/call":
                previous = payload["params"]["arguments"]["text"]
                payload["params"]["arguments"]["text"] = "changed wire"
                try:
                    return original(payload)
                finally:
                    payload["params"]["arguments"]["text"] = previous
            return original(payload)

        monkeypatch.setattr(framing, "encoded_line", encode)
    else:
        original = proxy._drain_and_validate_catalog_authority

        def drain(**kwargs):
            result = original(**kwargs)
            if kwargs.get("quiet_seconds") == 0.005:
                if boundary == "owned_arguments":
                    # The selected object can be reached by a faulty local
                    # callback; immutable binding must still reject its change.
                    from codex_plugin_scanner.guard.proxy.tool_call_binding import current_tool_call_binding

                    binding = current_tool_call_binding()
                    assert binding is not None
                    binding.owned_message["params"]["arguments"]["text"] = "changed owned input"
                else:
                    messages[-1]["method"] = HostileMethod("ping") if boundary == "hostile_method" else "ping"
            return result

        monkeypatch.setattr(proxy, "_drain_and_validate_catalog_authority", drain)

    result = proxy.run_session(messages)

    assert callbacks == []
    assert not marker.exists()
    assert result["events"][-1]["reason_code"] == "tool_call_request_changed"
    assert result["events"][-1]["session_terminal"] is True


def test_unchanged_tool_call_keeps_complete_request_and_quiet_fence(tmp_path, monkeypatch):
    proxy, messages, marker = _session(tmp_path)
    expected = json.loads(json.dumps(messages[-1]))
    quiet = []
    original = proxy._drain_and_validate_catalog_authority

    def drain(**kwargs):
        if kwargs.get("quiet_seconds") == 0.005:
            quiet.append(kwargs["quiet_seconds"])
        return original(**kwargs)

    monkeypatch.setattr(proxy, "_drain_and_validate_catalog_authority", drain)

    result = proxy.run_session(messages)

    assert json.loads(marker.read_text()) == expected
    assert quiet == [0.005]
    assert result["responses"][-1]["result"]["content"][0]["text"] == "forwarded"
