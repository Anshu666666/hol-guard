import gzip
import hashlib
import json
from pathlib import Path
import os
import subprocess
import time

root = Path('/workspace/scratch/c25672eb4c10/hol-guard')
out = Path('/workspace/scratch/c25672eb4c10/integration-gates-623a')
out.mkdir(exist_ok=False)
python = '/workspace/scratch/c25672eb4c10/validation-venv/bin/python'
environment = dict(os.environ, PYTHONPATH=str(root / 'src') + ':' + str(root), PYTHONDONTWRITEBYTECODE='1')
head = subprocess.check_output(['git', '-C', str(root), 'rev-parse', 'HEAD']).decode().strip()
assert head == '623a6e058b2c4b650021e3c359d8e58b1be6ea05'
paths = subprocess.check_output(['git', '-C', str(root), 'ls-files', '-z', 'src', 'rust', 'scripts', 'tests', '.github']).split(b'\0')
def inventory():
    return {p.decode(): hashlib.sha256((root / p.decode()).read_bytes()).hexdigest() for p in paths if p and (root / p.decode()).is_file()}
before = inventory()
(out / 'source-before.json.gz').write_bytes(gzip.compress((json.dumps(before, sort_keys=True) + '\n').encode(), mtime=0))
commands = [
    ('native-authority', [python, 'scripts/ci/rust_authority_ownership_gate.py', '--root', str(root)]),
    ('python-semantic', [python, 'scripts/ci/python_hook_semantic_callgraph_gate.py', '--root', str(root)]),
    ('io-ownership', [python, 'scripts/ci/rust_io_ownership_gate.py', '--root', str(root)]),
    ('workflow-permissions', [python, '-m', 'pytest', '-q', '-p', 'no:cacheprovider', 'tests/test_workflow_token_permissions.py']),
]
receipts = []
for name, command in commands:
    start = time.monotonic()
    with (out / (name + '.log')).open('wb') as log:
        result = subprocess.run(['flock', '--close', '-w', '180', '/workspace/scratch/c25672eb4c10/validation.lock', *command], cwd=root, env=environment, stdout=log, stderr=subprocess.STDOUT)
    raw = (out / (name + '.log')).read_bytes()
    receipt = {'name': name, 'command': command, 'exit_code': result.returncode, 'seconds_including_lock': round(time.monotonic() - start, 3), 'log_bytes': len(raw), 'log_sha256': hashlib.sha256(raw).hexdigest()}
    receipts.append(receipt)
    (out / (name + '.json')).write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps(receipt), flush=True)
after = inventory()
(out / 'source-after.json.gz').write_bytes(gzip.compress((json.dumps(after, sort_keys=True) + '\n').encode(), mtime=0))
summary = {'source_commit': head, 'source_files': len(before), 'source_unchanged': before == after, 'results': receipts, 'qualification_complete': False}
(out / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
assert before == after and all(r['exit_code'] == 0 for r in receipts), 'Integration gate failure retained'
