"""Independently verify declared stored/decoded evidence bytes, read-only."""
import argparse
import gzip
import hashlib
import json
from pathlib import Path


def check_bytes(data, record, label):
    assert len(data) == record['bytes'], (label, 'bytes')
    assert hashlib.sha256(data).hexdigest() == record['sha256'], (label, 'sha256')


def verify(folder):
    manifest_data = (folder / 'manifest.json').read_bytes()
    manifest = json.loads(manifest_data)
    records = manifest.get('files', manifest.get('artifacts'))
    if isinstance(records, dict):
        records = [dict(v, path=k) for k, v in records.items()]
    assert isinstance(records, list) and records
    decoded_count = 0
    for record in records:
        p = folder / record['path']
        assert p.resolve().is_relative_to(folder.resolve()), p
        data = p.read_bytes()
        check_bytes(data, record, p)
        decoded = record.get('decoded')
        if decoded is None:
            for prefix in ('decoded', 'uncompressed'):
                if prefix + '_sha256' in record:
                    decoded = {'bytes': record[prefix + '_bytes'], 'sha256': record[prefix + '_sha256']}
                    break
        if decoded is not None:
            check_bytes(gzip.decompress(data), decoded, (p, 'decoded'))
            decoded_count += 1
    for k in ('file_count', 'artifact_count'):
        if k in manifest:
            assert len(records) == manifest[k], k
    total = sum(r['bytes'] for r in records)
    for k in ('total_bytes', 'total_artifact_bytes'):
        if k in manifest:
            assert total == manifest[k], k
    original_count = 0
    if 'original_manifest_path' in manifest:
        original_data = (folder / manifest['original_manifest_path']).read_bytes()
        assert hashlib.sha256(original_data).hexdigest() == manifest['original_manifest_sha256']
        original = json.loads(original_data)
        mapping = manifest.get('original_path_mapping', {})
        for record in original['files']:
            name = record['path']
            data = (folder / mapping.get(name, name)).read_bytes()
            if name in mapping:
                data = gzip.decompress(data)
            check_bytes(data, record, ('original', name))
            if 'uncompressed_sha256' in record:
                check_bytes(gzip.decompress(data), {
                    'bytes': record['uncompressed_bytes'], 'sha256': record['uncompressed_sha256']
                }, ('original decoded', name))
            original_count += 1
        assert original_count == original['file_count']
        assert sum(r['bytes'] for r in original['files']) == original['total_bytes']
    return dict(folder=str(folder), manifest_sha256=hashlib.sha256(manifest_data).hexdigest(),
                records=len(records), stored_bytes=total, decoded_records=decoded_count,
                original_records=original_count, passed=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('folders', type=Path, nargs='+')
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    result = {'verifier_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              'results': [verify(p) for p in args.folders]}
    encoded = json.dumps(result, indent=2) + '\n'
    if args.output:
        args.output.write_text(encoded)
    print(encoded, end='')
