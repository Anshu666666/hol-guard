"""Recheck only the affected ownership gates and corrected interpreter selection."""
from datetime import datetime, timezone
import gzip
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

root=Path('/workspace/scratch/c25672eb4c10/hol-guard')
out=Path('/workspace/scratch/c25672eb4c10/integration-gates-69a09')
python='/workspace/scratch/c25672eb4c10/validation-venv/bin/python'
def git(*args):
    return subprocess.check_output(['git','-C',str(root),*args])
head=git('rev-parse','HEAD').decode().strip()
assert head.startswith('69a09bc9') and not git('status','--porcelain')
out.mkdir(exist_ok=False)
paths=[p.decode() for p in git('ls-files','-z','src','rust','scripts','tests','ci','.github','docs/guard/contracts').split(b'\0') if p]
def inventory():
    return {name:hashlib.sha256((root/name).readlink().as_posix().encode() if (root/name).is_symlink() else (root/name).read_bytes()).hexdigest() for name in paths}
before=inventory()
(out/'source-before.json.gz').write_bytes(gzip.compress((json.dumps(before,sort_keys=True)+'\n').encode(),mtime=0))
environment=dict(os.environ,PYTHONPATH=str(root/'src')+':'+str(root),PYTHONDONTWRITEBYTECODE='1')
commands=[
    ('native-authority',[python,'scripts/ci/rust_authority_ownership_gate.py','--root',str(root)]),
    ('ownership-contract-tests',[python,'-m','pytest','-q','--tb=short','tests/test_hook_data_plane_ownership_gate.py']),
    ('production-types',[python,'-m','basedpyright','--pythonpath',python,'--level','error']),
    ('io-ownership',[python,'scripts/ci/rust_io_ownership_gate.py','--root',str(root)]),
]
results=[]
for name,command in commands:
    started=datetime.now(timezone.utc).isoformat();begin=time.monotonic()
    with (out/(name+'.log')).open('wb') as log:
        completed=subprocess.run(['flock','--close','-w','180','/workspace/scratch/c25672eb4c10/validation.lock',*command],cwd=root,env=environment,stdout=log,stderr=subprocess.STDOUT)
    data=(out/(name+'.log')).read_bytes()
    result=dict(name=name,command=command,exit_code=completed.returncode,started_at=started,seconds_including_lock=round(time.monotonic()-begin,3),log_bytes=len(data),log_sha256=hashlib.sha256(data).hexdigest())
    results.append(result);(out/(name+'.json')).write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
after=inventory()
(out/'source-after.json.gz').write_bytes(gzip.compress((json.dumps(after,sort_keys=True)+'\n').encode(),mtime=0))
summary=dict(source_commit=head,source_tree=git('rev-parse','HEAD^{tree}').decode().strip(),source_files=len(before),source_unchanged=before==after,clean_after=not bool(git('status','--porcelain')),results=results,qualification_complete=False,performance_campaign=False,runner_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
assert before==after and summary['clean_after'] and all(r['exit_code']==0 for r in results), 'Follow-up integration failure retained'
