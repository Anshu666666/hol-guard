"""Validate an exact integrated source without running a performance cohort."""
import argparse
from datetime import datetime, timezone
import gzip
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--root', type=Path, required=True)
parser.add_argument('--head', required=True)
parser.add_argument('--out', type=Path, required=True)
args = parser.parse_args()
root = args.root.resolve()
out = args.out.resolve()
python = '/workspace/scratch/c25672eb4c10/validation-venv/bin/python'
environment = dict(os.environ, PYTHONPATH=str(root/'src')+':'+str(root), PYTHONDONTWRITEBYTECODE='1')

def git(*argv):
    return subprocess.check_output(['git','-C',str(root),*argv])

assert git('rev-parse','HEAD').decode().strip() == args.head
assert not git('status','--porcelain')
out.mkdir(exist_ok=False)
paths = [p.decode() for p in git('ls-files','-z','src','rust','scripts','tests','ci','.github').split(b'\0') if p]

def inventory():
    result = {}
    for name in paths:
        p = root/name
        data = p.readlink().as_posix().encode() if p.is_symlink() else p.read_bytes()
        result[name] = hashlib.sha256(data).hexdigest()
    return result

before = inventory()
(out/'source-before.json.gz').write_bytes(gzip.compress((json.dumps(before,sort_keys=True)+'\n').encode(),mtime=0))
transition_tests = [
    'tests/test_installed_transition_observer.py',
    'tests/test_installed_transition_interpreter.py',
    'tests/test_installed_artifact_transitions.py',
    'tests/test_installed_transition_acceptance.py',
    'tests/test_installed_transition_recovery.py',
    'tests/test_macos_qualification_interpreter.py',
]
assert all((root/p).is_file() for p in transition_tests)
commands = [
    ('native-authority',[python,'scripts/ci/rust_authority_ownership_gate.py','--root',str(root)]),
    ('python-semantic',[python,'scripts/ci/python_hook_semantic_callgraph_gate.py','--root',str(root)]),
    ('io-ownership',[python,'scripts/ci/rust_io_ownership_gate.py','--root',str(root)]),
    ('production-ruff',[python,'-m','ruff','check','src']),
    ('production-types',[python,'-m','basedpyright','--level','error']),
    ('combined-transition-tests',[python,'-m','pytest','-q','--tb=short',*transition_tests]),
]
receipts=[]
for name,command in commands:
    started=datetime.now(timezone.utc).isoformat()
    begin=time.monotonic()
    with (out/(name+'.log')).open('wb') as log:
        result=subprocess.run(['flock','--close','-w','180','/workspace/scratch/c25672eb4c10/validation.lock',*command],
                              cwd=root,env=environment,stdout=log,stderr=subprocess.STDOUT)
    raw=(out/(name+'.log')).read_bytes()
    receipt=dict(name=name,command=command,exit_code=result.returncode,started_at=started,
                 seconds_including_lock=round(time.monotonic()-begin,3),
                 log_bytes=len(raw),log_sha256=hashlib.sha256(raw).hexdigest())
    receipts.append(receipt)
    (out/(name+'.json')).write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps(receipt),flush=True)
after=inventory()
(out/'source-after.json.gz').write_bytes(gzip.compress((json.dumps(after,sort_keys=True)+'\n').encode(),mtime=0))
summary=dict(source_commit=args.head,source_tree=git('rev-parse','HEAD^{tree}').decode().strip(),
             source_files=len(before),source_unchanged=before==after,results=receipts,
             qualification_complete=False,performance_campaign=False,
             clean_after=not bool(git('status','--porcelain')),
             runner_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
assert before==after and summary['clean_after'] and all(r['exit_code']==0 for r in receipts), 'Integration failure retained'
