"""Finite independent negative controls for the extracted installed-mode proof."""

from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import sys
import tempfile
from pathlib import Path


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    root = args.root.resolve()
    gate_path = root / "scripts/ci/native_receipt_persistence_gate.py"
    sys.path.insert(0, str(root))
    spec = importlib.util.spec_from_file_location("receipt_gate_review_target", gate_path)
    assert spec is not None and spec.loader is not None
    gate = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(gate)
    probe = (root / "ci/native_runtime/probe_native_default_auto.py").read_text()
    routes = (root / "ci/native_runtime/default_auto_routes.py").read_text()
    marker = "        mode_invariants = _exercise_mode_invariants(daemon, guard_home, workspace)"
    assert marker in probe
    cases = {
        "unchanged": (True, probe),
        "disconnected_nested_function": (
            False,
            probe.replace(marker, "        def never_called():\n    " + marker),
        ),
        "unreachable_if_false": (
            False,
            probe.replace(marker, "        if False:\n    " + marker),
        ),
    }
    results = []
    with tempfile.TemporaryDirectory(prefix="receipt-gate-independent-") as temporary:
        fixture_root = Path(temporary)
        helper = fixture_root / "ci/native_runtime/default_auto_routes.py"
        helper.parent.mkdir(parents=True)
        helper.write_text(routes)
        for name, (expected, candidate_probe) in cases.items():
            try:
                gate._validate_installed_mode_proof(fixture_root, candidate_probe)
            except RuntimeError as error:
                outcome = {"accepted": False, "error": str(error)}
            else:
                outcome = {"accepted": True}
            results.append(
                {
                    "case": name,
                    "expected_acceptance": expected,
                    "probe_sha256": hashlib.sha256(candidate_probe.encode()).hexdigest(),
                    **outcome,
                    "passed": outcome["accepted"] is expected,
                }
            )
    report = {
        "scope": "finite AST connectivity controls; no probe/runtime execution",
        "source_sha256": {
            relative: hashlib.sha256((root / relative).read_bytes()).hexdigest()
            for relative in (
                "scripts/ci/native_receipt_persistence_gate.py",
                "tests/test_native_receipt_persistence_gate.py",
            )
        },
        "results": results,
        "passed": all(row["passed"] for row in results),
    }
    args.output.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
