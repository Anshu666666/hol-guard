# Hosted evidence recovered for PR 2974, source 0200

This collection is read-only. No workflow was rerun, dispatched, or cancelled, and no review, branch, approval, or security alert was changed.

The captured source is `0200f80ab9e6bae73705f3e9ba78c8001c88f2d1`. Its hosted test merge is `96bcd2b961342a10ff210bd009dac56b956ef3a0`, whose tree is `1b4c6f6712e7fe67424b8a7fef9a0fede0e44281`. The merge has ordered parents `4b89e0d2d496a85f04922b2e019a4aea15326bb9` and 0200. A final PR readback still showed this source, open and not draft.

All 31 workflow runs are terminal, each on attempt 1: 26 succeeded and 5 failed. Their 183 jobs contain 153 successes, 22 skips, and 8 failures. All 186 check records contain 156 successes, 22 skips, and 8 failures. The three additional checks are two Gitar successes and one CodeQL success. No Greptile check was present in this complete source-specific check collection. CodeRabbit's sole commit status is success with an explicit message that reviews are disabled for this base branch.

Pagination is complete: 31 workflow records, 32 job-list pages, 2 check-list pages, and 32 artifact-list pages. Every page total and every source identity was checked, with no duplicated job, check, or artifact IDs. There are 214 artifact metadata records. Six artifacts were downloaded and their ZIP hashes match GitHub's SHA256 metadata: all four native wheels, the pytest shard plan, and the authority ownership report. The other 208 artifacts were inventoried but not downloaded.

## Failures that require source work

| Workflow / job | Observed failure |
| --- | --- |
| CI shard 38, job 105718716724 | `test_native_receipt_persistence_gate_emits_exact_head_evidence` raises at `native_receipt_persistence_gate.py:157`, because the probe no longer contains the literal `for mode in ("off", "shadow")`. The shard has 1 failure and 232 passes. |
| Rust authority ownership, job 105718276680 | The same source-contract assertion fails before later authority checks. |
| Rust runtime Windows resident, job 105718276604 | Clippy rejects a descendant spawn at `managed_resident_windows_wait_tests.rs:219` because not every path waits for it. The command then continues to cargo tests, where `source_read_obeys_denied_read_acl_without_repairing_it` fails `assertion failed: unchanged` at `source_files_tests.rs:146`; 29 other tests in that crate pass. |
| Rust daemon edge, Windows job 105718274682 | The same Clippy descendant-retirement assertion fails. |
| Native wheel Linux 105718285738, Mac ARM 105718286797, Mac Intel 105718286847 | Installed SLO measurement stops during imports: `bench_guard_native_installed_slo.py:32` loads the default-auto probe, whose import of `ci.native_runtime.default_auto_failure` raises `ModuleNotFoundError: No module named 'ci.native_runtime'`. No SLO timings were collected, and the Linux soak was skipped. |
| CI aggregate 105721660859 | It faithfully fails because `TESTS_RESULT` is failure; the other listed dependencies are success. |

All four native wheels were built and installed successfully before their later job outcomes. The archived binary bytes match each runtime manifest and installed-identity report. Each actual runtime capabilities response in the corresponding job log reports the test merge SHA above. The byte-level checks and reports are in `wheel-verification.json`.

Each platform's default-auto report records 21 resident decisions, zero fail-safe decisions, accepted and processed counts of 21, and zero dropped or pending receipts. Linux and both Macs have zero recorded receipt failures. **Windows has one recorded receipt persistence failure despite its green wheel job**. Its safe diagnostic categories are `command_activity_persistence/os_code_unavailable: 1` and `receipt_persistence/os_code_unavailable: 1`; the native-only map also records the receipt failure. No exact underlying OS error is established here. No separate default-auto failure artifact exists because that command exited successfully.

Linux and both Macs separately record four real generated Pi/OMP extension cases through the installed native resident, including empty, long, Unicode/CRLF, and ordinary output, plus seven malformed-output controls. These observations do not replace the failed SLO import or establish full qualification.

The current Gitleaks job 105718288860 reports 1,284 scanned commits and no leaks found. The CodeQL analysis workflow and external CodeQL check both succeeded; this collection did not access or mutate alert records.

## Evidence and limits

`summary.json`, `jobs.json`, `checks.json`, and `artifacts.json` contain the reconciled results. `raw/` preserves API metadata and the ten selected job logs. `decoded/` contains reports from the six verified artifact ZIPs; `archives/` retains the original ZIP bytes locally. Temporary signed download URLs were omitted from saved download receipts. An ordinary urllib client received a Cloudflare 403/1010 when accessing the artifact file reference; curl downloaded the same authorized file references successfully, with matching artifact hashes.

`verification-first-attempt.json` preserves a failed collector assumption: the optimized Windows executable need not contain its full source SHA as one contiguous ASCII string. Verification instead checks binary hashes against the manifest and installed identity, plus the actual runtime capabilities output. No artifact bytes were altered.

Results remain specific to this source and hosted cohort. They do not establish performance qualification, future-source CI results, zero Windows receipt failures, or final review readiness. The older D104 read is isolated in the sibling directory and is not pooled into these results.
