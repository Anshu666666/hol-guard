from pathlib import Path
import hashlib
import io
import json
import os
import subprocess
import sys
import tarfile

root = Path('/workspace/scratch/c25672eb4c10/installed-import-0200')
out = root.parent / 'installed-import-0200-evidence'
baseline = '2e672d2d950c6ec471005ddba46e49bba16dc23b'
materialized = out / 'frozen-baseline'
materialized.mkdir(exist_ok=True)
archive = subprocess.check_output(['git', 'archive', baseline, 'src', 'contracts'], cwd=root)
with tarfile.open(fileobj=io.BytesIO(archive), mode='r:') as stream:
    stream.extractall(materialized, filter='data')
package = materialized / 'src/codex_plugin_scanner'
assert not (package / 'guard/daemon/runtime_hook_evidence_diagnostics.py').exists()
source_files = sorted(path for path in materialized.rglob('*') if path.is_file())
source_hashes = {str(path.relative_to(materialized)): hashlib.sha256(path.read_bytes()).hexdigest() for path in source_files}
environment = dict(os.environ)
environment['PYTHONPATH'] = str(materialized / 'src')
environment['PYTHONDONTWRITEBYTECODE'] = '1'
python = str(root.parent / 'validation-recovered/bin/python')
script = root / 'scripts/bench_guard_native_installed_slo.py'
original = out / 'original/bench_guard_native_installed_slo.py'
entry = '''
import sys
from pathlib import Path
script, source = (Path(value) for value in sys.argv[1:3])
sys.path[0] = str(script.parent)
sys.argv = [str(script), '--help']
exec(compile(source.read_bytes(), str(script), 'exec'), {'__name__':'__main__', '__file__':str(script)})
'''
qualification = '''
import sys
from pathlib import Path
root = Path(sys.argv[1])
sys.path[0] = str(root / 'scripts')
sys.path.append(str(root))
import codex_plugin_scanner
from scripts.native_slo_qualification_run import run_block
assert callable(run_block)
print(codex_plugin_scanner.__file__)
print('qualification_import_boundary_complete')
'''
commands = {
    'baseline-package-identity': [python, '-c', 'import codex_plugin_scanner; print(codex_plugin_scanner.__file__)'],
    'original-baseline-cli': [python, '-c', entry, str(script), str(original)],
    'fixed-baseline-cli': [python, str(script), '--help'],
    'fixed-baseline-qualification-import': [python, '-c', qualification, str(root)],
}
results = []
for name, command in commands.items():
    completed = subprocess.run(command, cwd=materialized, env=environment, capture_output=True, timeout=30, check=False)
    for suffix, value in [('stdout', completed.stdout), ('stderr', completed.stderr)]:
        (out / 'fixed' / (name + '.' + suffix)).write_bytes(value)
    results.append({'name':name, 'command':command, 'returncode':completed.returncode, 'stdout_sha256':hashlib.sha256(completed.stdout).hexdigest(), 'stderr_sha256':hashlib.sha256(completed.stderr).hexdigest()})
    print(name, completed.returncode, completed.stderr.decode('utf-8', errors='replace')[-500:])
assert all(hashlib.sha256((materialized / rel).read_bytes()).hexdigest() == digest for rel, digest in source_hashes.items())
receipt = {'baseline_commit':baseline, 'baseline_package_source_unchanged':True, 'source_files':len(source_hashes), 'source_inventory_sha256':hashlib.sha256(json.dumps(source_hashes,sort_keys=True).encode()).hexdigest(), 'diagnostics_module_absent':True, 'scope':'Exact frozen baseline package source import checks; dependencies come from locked validation environment. No installed-wheel runtime or performance claim.', 'results':results}
(out / 'fixed/frozen-baseline-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
assert [row['returncode'] for row in results] == [0, 1, 0, 0]
assert b"ModuleNotFoundError: No module named 'ci.native_runtime'" in (out / 'fixed/original-baseline-cli.stderr').read_bytes()
assert '--runtime' in (out / 'fixed/fixed-baseline-cli.stdout').read_text()
assert str(package) in (out / 'fixed/baseline-package-identity.stdout').read_text()
assert str(package) in (out / 'fixed/fixed-baseline-qualification-import.stdout').read_text()
