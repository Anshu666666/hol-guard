# Native resident request fallback removal

Commit `360984be8586b32ca9e829485e9bf1214bd47c13` removes the old one-shot request branch selected when tests replace the shutdown process runner. It changes one production file and two test files, on parent `0200f80ab9e6bae73705f3e9ba78c8001c88f2d1`.

The public request now always uses the persistent stream. The request signature, validation, payload/response limits, absolute deadline, pool ownership, native admission, shared-resident cleanup and shutdown runner are preserved. AST comparison proves every retained function/class is unchanged except removal of that single request-routing conditional. No native policy source, native stream source or ownership contract changed.

The old tests passed 14 cases through the old seam. Two frozen routing controls then showed the defect for both raw-hook flag values. A new suite on unchanged production source passed 16 real-stdio controls and failed exactly those two routing controls. After the narrow production deletion, the final suite passed 41 cases in 1.25 seconds: 39 repository tests and the two unchanged external counterexample controls.

The new tests run actual child processes and pipe frames through the real Python pool, request, frame-writing, response-reading and cleanup code. Their launcher redirects to a small framed Python worker. They verify resident-client-stream arguments, environment filtering, process reuse, deadlines, startup failure, stderr privacy, malformed/oversized/empty responses, request limits and child retirement. They do not execute an installed Rust binary and do not establish performance qualification.

The old one-shot stderr and process-result classifications were never the ordinary persistent production behavior. Their original tests and passing result remain in the evidence; replacements assert the current transport's static failure codes and stderr suppression. The current production failure behavior did not change.

Ruff and formatter checks passed. The final three-file type result has zero errors and 48 warnings, with no suppression. Two pre-existing test fixture inference errors were fixed using an explicit dictionary annotation. The initial failing type outputs remain beside the final result. Authority, I/O ownership, semantic callgraph and privacy gates passed on the exact final production bytes.

PR 2974 review thread `PRRT_kwDORzZri86jehad` has not been replied to or resolved by this review. No remote changes or security alert actions were performed. Independent review is tracked separately by the parent.
