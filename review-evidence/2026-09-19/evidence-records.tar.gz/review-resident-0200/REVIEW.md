# PR 2974 review recovery

Reviewed source `0200f80ab9e6bae73705f3e9ba78c8001c88f2d1` and tree `1b4c6f6712e7fe67424b8a7fef9a0fede0e44281`. Read-only snapshot: 28 inline threads, 15 resolved (6 Greptile, 9 Qodo), 13 unresolved. REST pages independently confirm all 34 inline comments, 8 review submissions, and 7 issue comments; second pages are empty.

All eight review submissions are COMMENTED. The two bot submissions refer to b5d2359b; the six author submissions refer to f8bae764. There is no approval on any source and no genuine independent approval for the current push. CODEOWNERS includes kantorcodes, deep-purple-boots and zerocodefast; deep-purple-boots remains requested. The only Greptile summary is the old 0/5 score.

## Remaining findings

| Finding | Current nonblank lines | Base nonblank lines | Disposition |
| --- | ---: | ---: | --- |
| [src/codex_plugin_scanner/guard/daemon/server.py](https://github.com/hashgraph-online/hol-guard/pull/2974#discussion_r4039987561) | 8440 | 8352 | Valid existing size-rule finding; still unresolved. Cohesive extraction required to satisfy the rule; not a new behavioral regression. No waiver or thread mutation made. |
| [src/codex_plugin_scanner/guard/runtime/runner.py](https://github.com/hashgraph-online/hol-guard/pull/2974#discussion_r4039987569) | 6043 | 5965 | Valid existing size-rule finding; still unresolved. Cohesive extraction required to satisfy the rule; not a new behavioral regression. No waiver or thread mutation made. |
| [src/codex_plugin_scanner/guard/daemon/manager.py](https://github.com/hashgraph-online/hol-guard/pull/2974#discussion_r4039987581) | 2850 | 2819 | Valid existing size-rule finding; still unresolved. Cohesive extraction required to satisfy the rule; not a new behavioral regression. No waiver or thread mutation made. |
| [tests/test_guard_cli.py](https://github.com/hashgraph-online/hol-guard/pull/2974#discussion_r4039987591) | 9093 | 9092 | Valid existing size-rule finding; still unresolved. Cohesive extraction required to satisfy the rule; not a new behavioral regression. No waiver or thread mutation made. |
| [tests/test_guard_approvals.py](https://github.com/hashgraph-online/hol-guard/pull/2974#discussion_r4039987600) | 3621 | 3633 | Valid existing size-rule finding; still unresolved. Cohesive extraction required to satisfy the rule; not a new behavioral regression. No waiver or thread mutation made. |
| [tests/test_guard_approval_gate.py](https://github.com/hashgraph-online/hol-guard/pull/2974#discussion_r4039987608) | 1895 | 1894 | Valid existing size-rule finding; still unresolved. Cohesive extraction required to satisfy the rule; not a new behavioral regression. No waiver or thread mutation made. |
| [dashboard/src/home-dashboard.tsx](https://github.com/hashgraph-online/hol-guard/pull/2974#discussion_r4039987619) | 1085 | 1082 | Valid existing size-rule finding; still unresolved. Cohesive extraction required to satisfy the rule; not a new behavioral regression. No waiver or thread mutation made. |
| [dashboard/src/app.tsx](https://github.com/hashgraph-online/hol-guard/pull/2974#discussion_r4039987624) | 1006 | 1000 | Valid existing size-rule finding; still unresolved. Cohesive extraction required to satisfy the rule; not a new behavioral regression. No waiver or thread mutation made. |
| [src/codex_plugin_scanner/guard/runtime/actions.py](https://github.com/hashgraph-online/hol-guard/pull/2974#discussion_r4039987635) | 1028 | 1026 | Valid existing size-rule finding; still unresolved. Cohesive extraction required to satisfy the rule; not a new behavioral regression. No waiver or thread mutation made. |
| [src/codex_plugin_scanner/guard/daemon/hook_process_runner.py](https://github.com/hashgraph-online/hol-guard/pull/2974#discussion_r4039987644) | 563 | 569 | Valid existing size-rule finding; still unresolved. Cohesive extraction required to satisfy the rule; not a new behavioral regression. No waiver or thread mutation made. |
| [src/codex_plugin_scanner/guard/runtime/command_dns_extensions.py](https://github.com/hashgraph-online/hol-guard/pull/2974#discussion_r4039987713) | 439 | n/a | Active aggregate-to-provider control migration preserves disabled state and duplicate rejection. Removing it without transactional persisted migration would change existing enforcement. Implement equivalent migration before removing runtime expansion; do not merely delete compatibility. |
| [src/codex_plugin_scanner/guard/adapters/pi_extension_source.py](https://github.com/hashgraph-online/hol-guard/pull/2974#discussion_r4039987722) | 921 | n/a | Exact-byte ownership recognizer is used by update migration and uninstall, not acceptance of arbitrary old extension runtime output. Removing it would strand previously managed installations or prevent cleanup. Retain migration semantics; can extract migration-only source generation into a focused module if desired. |
| [src/codex_plugin_scanner/guard/native_resident_client.py](https://github.com/hashgraph-online/hol-guard/pull/2974#discussion_r4039987733) | 353 | n/a | Valid active test-only production fallback. Parent authorized isolated removal and migration of old-runner tests to actual persistent-stream controls. Not fixed in reviewed 0200 source. |

## Already fixed source

- AWS catalog: command_storage_extensions.py imports and aggregates AWS_S3 rules/specs; the stale `_aws` call is absent.
- Dashboard: app.tsx has one focusVisibleDashboardSearch declaration at line 118, and main.tsx imports and mounts PresentationModeProvider at lines 5 and 20.
- Built-in catalog: Common CLI and repo2nb coexist at command_builtin_extension_catalog.py lines 52–53.
- Approval explanation queries attach live explanations on list, summary, page, single-item and next-pending reads.
- Publisher responsibility extraction leaves native_policy_snapshot_publisher.py at 483 physical lines.
- The four nested conditional findings are now explicit branches in Cloud connect, fleet actions and protection error updates.
- Package mapping delegates input validation to payload_coercion.object_map. Presentation mode coercion accepts only everyday/technical.
- Windows secure reads now dispatch to windows.read_bounded via lib.rs lines 26–33; the old secure_open non-Unix fallback is not compiled on Windows. This establishes source dispatch, not that the current Windows ACL test passes.
- First-use tracking records executable/state identities before directory creation at native_resident_client.py lines 231–235; cleanup preserves other Guard homes.
- native_resident_stream.py lines 177–232 keep the original caller deadline before and after startup, through frame writes and response waits.

No remote comments, reviewer requests, resolutions, approvals, code changes or security-alert actions were performed for this snapshot. Native legacy-fallback repair is a separate authorized follow-on, not credited here.
