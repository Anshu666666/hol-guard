from pathlib import Path
from types import SimpleNamespace

import pytest

from codex_plugin_scanner.guard import native_resident_client as client
from codex_plugin_scanner.guard.codex_hook_launch_runtime import BoundedHookProcessResult


@pytest.mark.parametrize("raw_hook_envelope", [False, True])
def test_stop_runner_replacement_must_not_select_retired_request_route(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch, raw_hook_envelope: bool
) -> None:
    calls: list[str] = []

    def old_runner(*_args, **_kwargs):
        calls.append("one-shot")
        return BoundedHookProcessResult(0, "old", False, False)

    def persistent_request(*_args, **_kwargs):
        calls.append("persistent")
        return b"persistent"

    monkeypatch.setattr(client, "run_isolated_hook_process", old_runner)
    monkeypatch.setattr(client, "_client_pool_for", lambda *_args: SimpleNamespace(request=persistent_request))
    result = client.native_resident_client_request(
        executable=tmp_path / "runtime",
        guard_home=tmp_path / "guard",
        environment={},
        payload=b"{}",
        timeout_seconds=0.5,
        raw_hook_envelope=raw_hook_envelope,
    )
    assert (result, calls) == (b"persistent", ["persistent"])
