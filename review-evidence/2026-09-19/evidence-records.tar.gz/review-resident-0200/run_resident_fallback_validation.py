from pathlib import Path
import datetime, hashlib, json, os, subprocess, time
root=Path("/workspace/scratch/c25672eb4c10/review-resident-stream-0200")
out=Path("/workspace/scratch/c25672eb4c10/recovered-review/resident-fallback-validation");out.mkdir(exist_ok=True)
python="/workspace/scratch/c25672eb4c10/validation-recovered/bin/python"
paths=["src/codex_plugin_scanner/guard/native_resident_client.py","tests/test_native_hook_edge.py","tests/test_native_resident_request_transport.py"]
env={**os.environ,"PYTHONPATH":str(root/"src")+":"+str(root)}
commands={
"ruff":[python,"-m","ruff","check",*paths],
"format":[python,"-m","ruff","format","--check",*paths],
"types":[python,"-m","basedpyright","--pythonpath",python,"--outputjson",*paths],
"io_ownership":[python,"scripts/ci/rust_io_ownership_gate.py"],
"semantic":[python,"scripts/ci/python_hook_semantic_callgraph_gate.py"],
"authority":[python,"scripts/ci/rust_authority_ownership_gate.py"],
"privacy":[python,"scripts/ci/rust_io_privacy_gate.py"],
}
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
before={p:sha(root/p) for p in paths}
records=[]
for name,command in commands.items():
 started=time.monotonic()
 with (out/(name+".log")).open("w") as f:
  try:result=subprocess.run(command,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=180);status=result.returncode
  except subprocess.TimeoutExpired:status="timeout"
 record={"name":name,"command":command,"status":status,"elapsed_seconds":time.monotonic()-started,"log_sha256":sha(out/(name+".log"))}
 if name=="types":
  try:record["summary"]=json.loads((out/(name+".log")).read_text())["summary"]
  except (ValueError,KeyError):pass
 records.append(record);print(json.dumps(record),flush=True)
receipt={"source_base":"0200f80ab9e6bae73705f3e9ba78c8001c88f2d1","completed_at":datetime.datetime.now(datetime.timezone.utc).isoformat(),"commands":records,"source_sha256":before,"source_unchanged_after_commands":all(sha(root/p)==v for p,v in before.items())}
(out/"receipt.json").write_text(json.dumps(receipt,indent=2)+"\n")
