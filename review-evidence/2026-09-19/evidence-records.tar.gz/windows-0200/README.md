# Windows resident fixture repair at 0200f80a

Source commit: `0200f80ab9e6bae73705f3e9ba78c8001c88f2d1`.

Repair commit: `ce89f36ca710b35d419ca2b836ce9c55259abfa7`.

The repair changes only two Windows test files. It changes no production source,
workflow, ACL policy, timing budget, or required result.

## Observed failures

Both retained hosted logs report Rust Clippy's `zombie_processes` error for the
`normal-root` return in `managed_timeout_child_probe`. That fixture deliberately
leaves a live descendant for the outer Job to retire, but its `Child` handle had
no explicit waiter on that return path.

The resident job also reports 29 passing tests and one failed ACL test. The
`SourceFile::open` PermissionDenied assertion passed. The subsequent `unchanged`
assertion failed: it compared a descriptor parsed from requested SDDL with the
stored descriptor after applying the DACL and attempting the read. The log does
not retain either descriptor value. It therefore does not prove which flag or
representation differed, nor that the source open modified the descriptor.

## Changes

The normal-root fixture transfers its child into a detached thread that waits
for that child. It returns normally without joining or killing the descendant.
The original 30-second descendant fallback and outer Job assertions are intact.
There is no lint suppression.

The denied-read test now snapshots stored `Owner | Group | Dacl` state on the
same retained security handle both before and after attempting the source open.
It compares those snapshots exactly, without removing or normalizing SDDL flags.
An ordinary `File::open` must independently return PermissionDenied under the
installed ACL, and the original SourceFile PermissionDenied assertion remains.
The fixture restores its original DACL before asserting these outcomes.

## Validation

- Rust 1.88.0 rustfmt checks both changed files successfully.
- Actual Windows GNU target Clippy checks every target in the
  `guard-runtime-windows-process` crate with locked dependencies and `-D warnings`.
  It passes. This compiles the changed ACL test but does not execute Windows APIs.
- A literal extraction of the original std::process branch reproduces the same
  Clippy error on Rust 1.88.0. The corresponding fixed extraction compiles cleanly.
- Portable Linux process controls exercise the fixed normal-root branch and
  verify successful root exit while the descendant remains alive. A joined
  waiter and an early descendant kill both fail that required condition. The
  observer reaps all owned descendants, using pidfds for descendant termination.
- An independent agent reviewed the final diff, the source hashes, the Clippy
  receipts, and the completed process controls. It found no blocking issue.
- `git diff --check` passes, and the repair commit contains exactly the two
  intended test files. All production files remain byte-identical to the parent.

The first portable observer draft encountered ProcessLookupError when its
intentional early-kill control had already removed the process before pidfd_open.
That observer failure and original observer source are retained. The completed
second run accepts that condition only in the early-kill negative control;
production source, budgets, and the successful-case requirement did not change.

Actual Windows Job retirement and ACL runtime validation is still pending the
next natural hosted run. The recorded Linux controls and Windows target
compilation do not qualify native performance or establish Windows runtime pass.

## API basis

[GetSecurityInfo](https://learn.microsoft.com/en-us/windows/win32/api/aclapi/nf-aclapi-getsecurityinfo)
returns a separate copy of an object's security descriptor. The existing
READ_CONTROL handle supports reading its owner, primary group, and DACL.

[SetSecurityInfo](https://learn.microsoft.com/en-us/windows/win32/api/aclapi/nf-aclapi-setsecurityinfo)
sets the requested security components on the object. A requested descriptor is
not a snapshot captured after this operation.

[The SDDL format](https://learn.microsoft.com/en-us/windows/win32/secauthz/security-descriptor-string-format)
includes DACL control flags as well as ACEs. This repair retains their exact
before/after comparison; it does not guess the original mismatch's flag.

[Rust thread spawning](https://doc.rust-lang.org/std/thread/fn.spawn.html)
documents detachment when its JoinHandle is dropped. The
[threading model](https://doc.rust-lang.org/std/thread/index.html) describes
process shutdown when its main thread finishes, and
[Child::wait](https://doc.rust-lang.org/std/process/struct.Child.html#method.wait)
waits for exit without terminating the child.

[Windows process termination](https://learn.microsoft.com/en-us/windows/win32/procthread/terminating-a-process)
does not itself terminate child processes. The existing supervisor tests must
continue proving their Job cleanup behavior on Windows.

## Artifact scope

The manifest covers original/fixed sources, original hosted logs, commands,
source hashes, textual witnesses, reviews, and results. Locally built portable
executables and toolchain downloads are reproducible intermediate files and are
not publication artifacts. This evidence belongs outside the release PR.
