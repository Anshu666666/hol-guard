use std::env;
use std::fs;
use std::io;
use std::path::Path;
use std::process::{Command, Stdio};
use std::thread;
use std::time::{Duration, Instant};
const TIMEOUT_MODE_ENV: &str = "HOL_GUARD_TEST_SUPERVISOR_TIMEOUT_MODE";
fn exact_probe_name(name: &str) -> String { name.to_owned() }
fn wait_for_file(path: &Path) -> io::Result<()> {
    let deadline = Instant::now() + Duration::from_secs(5);
    while !path.exists() {
        if Instant::now() >= deadline {
            return Err(io::Error::new(
                io::ErrorKind::TimedOut,
                "probe did not start",
            ));
        }
        thread::sleep(Duration::from_millis(10));
    }
    Ok(())
}

fn main() {
    let directory = env::temp_dir();
    let mut descendant = Command::new(env::current_exe().unwrap())
        .args([
            "--exact",
            &exact_probe_name("managed_timeout_descendant_probe"),
            "--nocapture",
        ])
        .stdin(Stdio::null())
        .stdout(Stdio::null())
        .stderr(Stdio::null())
        .spawn()
        .unwrap();
    wait_for_file(&directory.join("descendant")).unwrap();
    fs::write(directory.join("started"), b"ready").unwrap();
    if env::var(TIMEOUT_MODE_ENV).as_deref() == Ok("normal-root") {
        // Keep an explicit waiter without joining it: this root must return
        // successfully while its live descendant still needs outer Job cleanup.
        drop(thread::spawn(move || {
            let _ = descendant.wait();
        }));
        return;
    }
    thread::sleep(Duration::from_secs(30));
    // Bound a failing regression test independently of the production cleanup.
    let _ = descendant.kill();
    let _ = descendant.wait();
}
