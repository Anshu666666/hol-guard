"""Exercise the exact std::process fixture branch, without claiming Win32 coverage."""

from __future__ import annotations

import ctypes
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import time


ROOT = Path('/workspace/scratch/c25672eb4c10/windows-0200-repairs')
OUT = Path('/workspace/scratch/c25672eb4c10/windows-0200-evidence')
RUSTC = Path('/workspace/scratch/bf9d480f98a6/core-toolchain-restored/rustup/toolchains/1.88.0-x86_64-unknown-linux-gnu/bin/rustc')
SOURCE = ROOT / 'rust/crates/guard-runtime/src/managed_resident_windows_wait_tests.rs'


def process_state(pid: int) -> str | None:
    try:
        return Path(f'/proc/{pid}/stat').read_text().rsplit(')', 1)[1].split()[0]
    except FileNotFoundError:
        return None


def main() -> None:
    # Adopt only this observer's descendants, so the intentionally orphaned
    # probe is reaped by its owner after the bounded lifetime observation.
    libc = ctypes.CDLL(None, use_errno=True)
    if libc.prctl(36, 1, 0, 0, 0) != 0:  # PR_SET_CHILD_SUBREAPER
        raise OSError(ctypes.get_errno(), 'subreaper control unavailable')
    source = SOURCE.read_text()
    tail = source[source.index('    let mut descendant = Command::new'):source.index('\n#[test]\nfn managed_timeout_descendant_probe')]
    helper = source[source.index('fn wait_for_file('):source.index('\n#[test]\nfn supervisor_wait_failures_terminate')]
    prefix = '''use std::env;
use std::fs;
use std::io;
use std::path::Path;
use std::process::{Command, Stdio};
use std::thread;
use std::time::{Duration, Instant};
const TIMEOUT_MODE_ENV: &str = "HOL_GUARD_TEST_SUPERVISOR_TIMEOUT_MODE";
fn exact_probe_name(name: &str) -> String { name.to_owned() }
'''
    entry = '''
fn main() {
    let directory = std::path::PathBuf::from(env::var_os("HOL_GUARD_TEST_SUPERVISOR_TIMEOUT_DIRECTORY").unwrap());
    if env::args().any(|argument| argument == "managed_timeout_descendant_probe") {
        fs::write(directory.join("descendant"), std::process::id().to_string()).unwrap();
        thread::sleep(Duration::from_secs(30));
        return;
    }
'''
    waiter = '''drop(thread::spawn(move || {
            let _ = descendant.wait();
        }));'''
    assert tail.count(waiter) == 1
    variants = {
        'fixed': tail,
        'joined-waiter-negative-control': tail.replace(waiter, '''thread::spawn(move || {
            let _ = descendant.wait();
        }).join().unwrap();'''),
        'early-kill-negative-control': tail.replace(waiter, '''descendant.kill().unwrap();
        descendant.wait().unwrap();'''),
    }
    records = []
    for label, body in variants.items():
        file = OUT / f'portable-lifetime-{label}.rs'
        binary = OUT / f'portable-lifetime-{label}'
        file.write_text(prefix + helper + entry + body)
        compile_command = [str(RUSTC), '--edition=2021', str(file), '-o', str(binary)]
        compiled = subprocess.run(compile_command, capture_output=True, text=True)
        (OUT / f'portable-lifetime-{label}-compile.log').write_text(compiled.stdout + compiled.stderr)
        compiled.check_returncode()
        directory = OUT / f'portable-lifetime-{label}-state'
        directory.mkdir()
        environment = os.environ.copy()
        environment['HOL_GUARD_TEST_SUPERVISOR_TIMEOUT_DIRECTORY'] = str(directory)
        environment['HOL_GUARD_TEST_SUPERVISOR_TIMEOUT_MODE'] = 'normal-root'
        worker = subprocess.Popen([str(binary)], env=environment, stdin=subprocess.DEVNULL,
                                  stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                                  start_new_session=True)
        started = time.monotonic()
        descendant = None
        descendant_handle = None
        timed_out = False
        try:
            while not (directory / 'started').exists():
                if worker.poll() is not None or time.monotonic() - started >= 5:
                    raise AssertionError('owned fixture failed its existing five-second readiness budget')
                time.sleep(0.01)
            descendant = int((directory / 'descendant').read_text())
            descendant_handle = os.pidfd_open(descendant)
            try:
                worker.wait(timeout=5)
            except subprocess.TimeoutExpired:
                timed_out = True
            state = process_state(descendant)
            root_exited_successfully = not timed_out and worker.returncode == 0
            descendant_alive = state not in (None, 'Z', 'X')
            accepted = root_exited_successfully and descendant_alive
            records.append({
                'case': label, 'source_sha256': hashlib.sha256(source.encode()).hexdigest(),
                'exact_original_body': label == 'fixed',
                'body_sha256': hashlib.sha256(body.encode()).hexdigest(),
                'compile_command': compile_command, 'compile_exit': compiled.returncode,
                'root_pid': worker.pid, 'descendant_pid': descendant,
                'root_exit': worker.returncode, 'root_wait_timed_out': timed_out,
                'descendant_state_at_observation': state,
                'root_exited_successfully_while_descendant_alive': accepted,
                'elapsed_seconds': time.monotonic() - started,
                'scope': 'Linux std::process lifetime control only; no Windows Job or ACL API execution',
            })
        finally:
            # Kill the direct child through its Popen handle and the descendant
            # through its pidfd. Never signal an unowned process group or PID.
            if worker.poll() is None:
                worker.kill()
            worker.wait(timeout=5)
            if descendant_handle is not None:
                try:
                    signal.pidfd_send_signal(descendant_handle, signal.SIGKILL)
                except ProcessLookupError:
                    pass
                finally:
                    os.close(descendant_handle)
            if descendant is not None:
                deadline = time.monotonic() + 5
                while True:
                    try:
                        reaped, status = os.waitpid(descendant, os.WNOHANG)
                    except ChildProcessError:
                        # Early-kill control was already reaped by its root.
                        if process_state(descendant) is not None:
                            raise
                        reaped, status = descendant, None
                    if reaped == descendant:
                        records[-1]['descendant_cleanup_reaped'] = True
                        records[-1]['descendant_wait_status'] = status
                        break
                    if time.monotonic() >= deadline:
                        raise AssertionError('owned descendant was not reaped within cleanup budget')
                    time.sleep(0.01)
    (OUT / 'portable-lifetime-receipt.json').write_text(json.dumps(records, indent=2) + '\n')
    assert [r['root_exited_successfully_while_descendant_alive'] for r in records] == [True, False, False]
    print(json.dumps(records, indent=2))


if __name__ == '__main__':
    main()
